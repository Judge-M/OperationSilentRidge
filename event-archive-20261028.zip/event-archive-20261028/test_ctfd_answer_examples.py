"""Regression coverage for participant-visible CTFd answer examples."""
import re
import tempfile
import unittest
from pathlib import Path

from expanded.author import answer_format_example, build
from ridge.state import State
from ridge.web import PAGE


class AnswerExampleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tickets = build()
        cls.questions = {question['id']: question
                         for ticket in cls.tickets
                         for question in ticket['questions']}

    def test_every_static_and_released_question_has_a_non_spoiler_example(self):
        self.assertEqual(80, len(self.questions))
        for question in self.questions.values():
            example = question.get('format_example')
            self.assertIsInstance(example, str, question['id'])
            self.assertTrue(example.strip(), question['id'])
            answer = question['answer'].strip().casefold()
            rendered = example.casefold()
            self.assertNotEqual(rendered, answer, question['id'])
            if answer not in ('yes', 'no'):
                self.assertNotIn(answer, rendered, question['id'])
                self.assertNotIn(rendered, answer, question['id'])

    def test_examples_do_not_repeat_any_question_answer(self):
        answers = {question['answer'].strip().casefold()
                   for question in self.questions.values()
                   if question['answer'].strip().casefold() not in ('yes', 'no')
                   and len(question['answer'].strip()) >= 3}
        for question in self.questions.values():
            example = question['format_example'].casefold()
            leaked = sorted(answer for answer in answers if answer in example)
            self.assertEqual([], leaked, question['id'])

    def test_examples_communicate_common_answer_shapes(self):
        expected = {
            'T01-Q1': 'host-##',
            'T01-Q2': 'req-##',
            'T01-Q4': '192.0.2.10',
            'T02-Q1': 'host.example',
            'T02-Q2': '192.0.2.10',
            'T03-Q1': 'HH:MM:SS',
            'T03-Q2': 'example.ext',
            'T03-Q3': 'host.example',
            'T03-Q4': 'C:/Example/path',
            'T04-Q2': 'example.ext',
            'T04-Q3': 'trigger event',
            'T05-Q4': 'WORD',
            'T06-Q1': 'user.name',
            'T07-Q3': 'S-##',
            'T07-Q4': 'action name',
            'T08-Q1': 'object-name',
            'T08-Q2': '200',
            'T09-Q2': 'SECTOR',
            'T09-Q3': 'HH:MM-HH:MMZ',
            'T10-Q2': 'Publisher Name',
            'T13-Q1': '1234',
            'T16-Q3': '8080',
            'T16-Q4': 'yes or no',
            'T18-Q2': 'returned text',
            'T20-Q1': '#',
        }
        for question_id, example in expected.items():
            self.assertEqual(example, self.questions[question_id]['format_example'])

    def test_hash_example_is_lowercase_hex_of_the_expected_length(self):
        example = answer_format_example('What is the SHA-256 hash?', 'A' * 64)
        self.assertEqual(64, len(example))
        self.assertIsNotNone(re.fullmatch(r'[0-9a-f]{64}', example))

    def test_t03_q1_opens_the_prepared_case_before_the_csv(self):
        question = self.questions['T03-Q1']
        route = '\n'.join(question['steps'])
        self.assertIn('~/Cases/WS17/WS17.aut', route)
        self.assertIn('Do not select /evidence/browser/downloads.csv as a case or new data source.', route)
        self.assertIn('Data Sources > LogicalFileSet1 > browser > downloads.csv', route)
        self.assertIn('Text or Table view', route)
        self.assertIn('Text or Table view', question['hints'][1])

    def test_dynamically_released_questions_keep_their_examples(self):
        with tempfile.TemporaryDirectory() as temp:
            state = State(Path(temp) / 'state.sqlite', retry_delay=0)
            state.initialize([{'id': 'team-01', 'iris': '1', 'ctfd': 1, 'name': 'Team One'}],
                             self.tickets)
            state.provision('test')
            state.mode('test', 'running')
            answered = set()
            for _ in range(len(self.tickets) + 1):
                progress = False
                for ticket in self.tickets:
                    status = state.ticket_state(ticket['id'], 'team-01')['status']
                    if status not in ('available', 'active'):
                        continue
                    for question in ticket['questions']:
                        if question['id'] in answered:
                            continue
                        result = state.answer('team-01', question['id'], question['answer'])
                        self.assertTrue(result['correct'], question['id'])
                        answered.add(question['id'])
                        progress = True
                if not progress:
                    break
            self.assertEqual(80, len(answered))
            visible = {question['id']: question for question in state.questions('team-01')}
            self.assertEqual(80, len(visible))
            for question_id, question in visible.items():
                self.assertEqual(self.questions[question_id]['format_example'],
                                 question['format_example'], question_id)

    def test_ctfd_plugin_renders_the_shared_question_page(self):
        plugin = (Path(__file__).resolve().parents[1] /
                  'integrations/ctfd_silent_ridge/__init__.py').read_text(encoding='utf-8')
        self.assertIn('from ridge.web import PAGE', plugin)

    def test_format_example_renders_before_the_answer_submission(self):
        macro = PAGE[PAGE.index('{% macro render_question'):
                     PAGE.index('{% endmacro %}', PAGE.index('{% macro render_question'))]
        markup = '<strong>Format example:</strong> <code>{{q.format_example}}</code>'
        self.assertIn(markup, macro)
        self.assertLess(macro.index(markup),
                        macro.index('name="action" value="answer"'))


if __name__ == '__main__':
    unittest.main()
