--
-- PostgreSQL database dump
--

-- Dumped from database version 12.22
-- Dumped by pg_dump version 12.22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: iris
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO iris;

--
-- Name: alert_assets_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_assets_association (
    alert_id bigint NOT NULL,
    asset_id bigint NOT NULL
);


ALTER TABLE public.alert_assets_association OWNER TO postgres;

--
-- Name: alert_case_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_case_association (
    alert_id bigint NOT NULL,
    case_id bigint NOT NULL
);


ALTER TABLE public.alert_case_association OWNER TO postgres;

--
-- Name: alert_iocs_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_iocs_association (
    alert_id bigint NOT NULL,
    ioc_id bigint NOT NULL
);


ALTER TABLE public.alert_iocs_association OWNER TO postgres;

--
-- Name: alert_resolution_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_resolution_status (
    resolution_status_id integer NOT NULL,
    resolution_status_name text NOT NULL,
    resolution_status_description text
);


ALTER TABLE public.alert_resolution_status OWNER TO postgres;

--
-- Name: alert_resolution_status_resolution_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_resolution_status_resolution_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_resolution_status_resolution_status_id_seq OWNER TO postgres;

--
-- Name: alert_resolution_status_resolution_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_resolution_status_resolution_status_id_seq OWNED BY public.alert_resolution_status.resolution_status_id;


--
-- Name: alert_similarity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_similarity (
    id bigint NOT NULL,
    alert_id bigint NOT NULL,
    similar_alert_id bigint NOT NULL,
    similarity_type character varying(255),
    matching_asset_id bigint,
    matching_ioc_id bigint
);


ALTER TABLE public.alert_similarity OWNER TO postgres;

--
-- Name: alert_similarity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_similarity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_similarity_id_seq OWNER TO postgres;

--
-- Name: alert_similarity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_similarity_id_seq OWNED BY public.alert_similarity.id;


--
-- Name: alert_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_status (
    status_id integer NOT NULL,
    status_name text NOT NULL,
    status_description text
);


ALTER TABLE public.alert_status OWNER TO postgres;

--
-- Name: alert_status_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_status_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_status_status_id_seq OWNER TO postgres;

--
-- Name: alert_status_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_status_status_id_seq OWNED BY public.alert_status.status_id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alerts (
    alert_id bigint NOT NULL,
    alert_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    alert_title text NOT NULL,
    alert_description text,
    alert_source text,
    alert_source_ref text,
    alert_source_link text,
    alert_source_content json,
    alert_severity_id integer NOT NULL,
    alert_status_id integer NOT NULL,
    alert_context json,
    alert_source_event_time timestamp without time zone DEFAULT now() NOT NULL,
    alert_creation_time timestamp without time zone DEFAULT now() NOT NULL,
    alert_note text,
    alert_tags text,
    alert_owner_id bigint,
    modification_history json,
    alert_customer_id bigint NOT NULL,
    alert_classification_id integer,
    alert_resolution_status_id integer
);


ALTER TABLE public.alerts OWNER TO postgres;

--
-- Name: alerts_alert_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alerts_alert_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alerts_alert_id_seq OWNER TO postgres;

--
-- Name: alerts_alert_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alerts_alert_id_seq OWNED BY public.alerts.alert_id;


--
-- Name: analysis_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analysis_status (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.analysis_status OWNER TO postgres;

--
-- Name: analysis_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analysis_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.analysis_status_id_seq OWNER TO postgres;

--
-- Name: analysis_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analysis_status_id_seq OWNED BY public.analysis_status.id;


--
-- Name: asset_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.asset_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_asset_id bigint
);


ALTER TABLE public.asset_comments OWNER TO postgres;

--
-- Name: asset_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.asset_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_comments_id_seq OWNER TO postgres;

--
-- Name: asset_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.asset_comments_id_seq OWNED BY public.asset_comments.id;


--
-- Name: assets_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assets_type (
    asset_id integer NOT NULL,
    asset_name character varying(155),
    asset_description character varying(255),
    asset_icon_not_compromised character varying(255),
    asset_icon_compromised character varying(255)
);


ALTER TABLE public.assets_type OWNER TO postgres;

--
-- Name: assets_type_asset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assets_type_asset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assets_type_asset_id_seq OWNER TO postgres;

--
-- Name: assets_type_asset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.assets_type_asset_id_seq OWNED BY public.assets_type.asset_id;


--
-- Name: case_assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_assets (
    asset_id bigint NOT NULL,
    asset_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    asset_name text,
    asset_description text,
    asset_domain text,
    asset_ip text,
    asset_info text,
    asset_compromise_status_id integer,
    asset_type_id integer,
    asset_tags text,
    case_id bigint,
    date_added timestamp without time zone,
    date_update timestamp without time zone,
    user_id bigint,
    analysis_status_id integer,
    custom_attributes json,
    asset_enrichment jsonb,
    modification_history json
);


ALTER TABLE public.case_assets OWNER TO postgres;

--
-- Name: case_assets_asset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_assets_asset_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_assets_asset_id_seq OWNER TO postgres;

--
-- Name: case_assets_asset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_assets_asset_id_seq OWNED BY public.case_assets.asset_id;


--
-- Name: case_classification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_classification (
    id integer NOT NULL,
    name text,
    name_expanded text,
    description text,
    creation_date timestamp without time zone DEFAULT now(),
    created_by_id bigint
);


ALTER TABLE public.case_classification OWNER TO postgres;

--
-- Name: case_classification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_classification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_classification_id_seq OWNER TO postgres;

--
-- Name: case_classification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_classification_id_seq OWNED BY public.case_classification.id;


--
-- Name: case_events_assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_events_assets (
    id bigint NOT NULL,
    event_id bigint,
    asset_id bigint,
    case_id bigint
);


ALTER TABLE public.case_events_assets OWNER TO postgres;

--
-- Name: case_events_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_events_assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_events_assets_id_seq OWNER TO postgres;

--
-- Name: case_events_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_events_assets_id_seq OWNED BY public.case_events_assets.id;


--
-- Name: case_events_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_events_category (
    id integer NOT NULL,
    event_id bigint,
    category_id integer
);


ALTER TABLE public.case_events_category OWNER TO postgres;

--
-- Name: case_events_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_events_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_events_category_id_seq OWNER TO postgres;

--
-- Name: case_events_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_events_category_id_seq OWNED BY public.case_events_category.id;


--
-- Name: case_events_ioc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_events_ioc (
    id bigint NOT NULL,
    event_id bigint,
    ioc_id bigint,
    case_id bigint
);


ALTER TABLE public.case_events_ioc OWNER TO postgres;

--
-- Name: case_events_ioc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_events_ioc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_events_ioc_id_seq OWNER TO postgres;

--
-- Name: case_events_ioc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_events_ioc_id_seq OWNED BY public.case_events_ioc.id;


--
-- Name: case_graph_assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_graph_assets (
    id integer NOT NULL,
    case_id bigint,
    asset_id integer,
    asset_type_id integer
);


ALTER TABLE public.case_graph_assets OWNER TO postgres;

--
-- Name: case_graph_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_graph_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_graph_assets_id_seq OWNER TO postgres;

--
-- Name: case_graph_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_graph_assets_id_seq OWNED BY public.case_graph_assets.id;


--
-- Name: case_graph_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_graph_links (
    id integer NOT NULL,
    case_id bigint,
    source_id integer,
    dest_id integer
);


ALTER TABLE public.case_graph_links OWNER TO postgres;

--
-- Name: case_graph_links_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_graph_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_graph_links_id_seq OWNER TO postgres;

--
-- Name: case_graph_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_graph_links_id_seq OWNED BY public.case_graph_links.id;


--
-- Name: case_kanban; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_kanban (
    case_id bigint NOT NULL,
    kanban_data text
);


ALTER TABLE public.case_kanban OWNER TO postgres;

--
-- Name: case_protagonist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_protagonist (
    id integer NOT NULL,
    case_id bigint,
    user_id bigint,
    name text,
    contact text,
    role text
);


ALTER TABLE public.case_protagonist OWNER TO postgres;

--
-- Name: case_protagonist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_protagonist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_protagonist_id_seq OWNER TO postgres;

--
-- Name: case_protagonist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_protagonist_id_seq OWNED BY public.case_protagonist.id;


--
-- Name: case_received_file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_received_file (
    id bigint NOT NULL,
    file_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    filename text,
    date_added timestamp without time zone,
    acquisition_date timestamp without time zone,
    file_hash text,
    file_description text,
    file_size bigint,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    case_id bigint,
    user_id bigint,
    type_id integer,
    custom_attributes json,
    chain_of_custody json,
    modification_history json
);


ALTER TABLE public.case_received_file OWNER TO postgres;

--
-- Name: case_received_file_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_received_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_received_file_id_seq OWNER TO postgres;

--
-- Name: case_received_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_received_file_id_seq OWNED BY public.case_received_file.id;


--
-- Name: case_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_state (
    state_id integer NOT NULL,
    state_name text NOT NULL,
    state_description text,
    protected boolean
);


ALTER TABLE public.case_state OWNER TO postgres;

--
-- Name: case_state_state_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_state_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_state_state_id_seq OWNER TO postgres;

--
-- Name: case_state_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_state_state_id_seq OWNED BY public.case_state.state_id;


--
-- Name: case_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_tags (
    case_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.case_tags OWNER TO postgres;

--
-- Name: case_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_tasks (
    id bigint NOT NULL,
    task_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    task_title text,
    task_description text,
    task_tags text,
    task_open_date timestamp without time zone,
    task_close_date timestamp without time zone,
    task_last_update timestamp without time zone,
    task_userid_open bigint,
    task_userid_close bigint,
    task_userid_update bigint,
    task_status_id integer,
    task_case_id bigint,
    custom_attributes json,
    modification_history json
);


ALTER TABLE public.case_tasks OWNER TO postgres;

--
-- Name: case_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_tasks_id_seq OWNER TO postgres;

--
-- Name: case_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_tasks_id_seq OWNED BY public.case_tasks.id;


--
-- Name: case_template; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_template (
    id integer NOT NULL,
    created_by_user_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone,
    name character varying NOT NULL,
    display_name character varying,
    description text,
    author character varying,
    title_prefix character varying,
    summary character varying,
    tags json,
    tasks json,
    note_directories json,
    classification character varying
);


ALTER TABLE public.case_template OWNER TO postgres;

--
-- Name: case_template_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_template_id_seq OWNER TO postgres;

--
-- Name: case_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_template_id_seq OWNED BY public.case_template.id;


--
-- Name: case_template_report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.case_template_report (
    id integer NOT NULL,
    name character varying,
    description character varying,
    internal_reference character varying,
    naming_format character varying,
    created_by_user_id integer,
    date_created timestamp without time zone,
    language_id integer,
    report_type_id integer
);


ALTER TABLE public.case_template_report OWNER TO postgres;

--
-- Name: case_template_report_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.case_template_report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_template_report_id_seq OWNER TO postgres;

--
-- Name: case_template_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.case_template_report_id_seq OWNED BY public.case_template_report.id;


--
-- Name: cases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cases (
    case_id bigint NOT NULL,
    soc_id character varying(256),
    client_id bigint NOT NULL,
    name character varying(256),
    description text,
    open_date date,
    close_date date,
    initial_date timestamp without time zone DEFAULT now() NOT NULL,
    closing_note text,
    user_id bigint,
    owner_id bigint,
    status_id integer DEFAULT 0 NOT NULL,
    state_id integer,
    custom_attributes json,
    case_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    classification_id integer,
    reviewer_id bigint,
    review_status_id integer,
    severity_id integer,
    modification_history json
);


ALTER TABLE public.cases OWNER TO postgres;

--
-- Name: cases_assets_ext; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cases_assets_ext (
    asset_id integer NOT NULL,
    type_id integer,
    case_id bigint,
    asset_content text
);


ALTER TABLE public.cases_assets_ext OWNER TO postgres;

--
-- Name: cases_assets_ext_asset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cases_assets_ext_asset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cases_assets_ext_asset_id_seq OWNER TO postgres;

--
-- Name: cases_assets_ext_asset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cases_assets_ext_asset_id_seq OWNED BY public.cases_assets_ext.asset_id;


--
-- Name: cases_case_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cases_case_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cases_case_id_seq OWNER TO postgres;

--
-- Name: cases_case_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cases_case_id_seq OWNED BY public.cases.case_id;


--
-- Name: cases_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cases_events (
    event_id bigint NOT NULL,
    parent_event_id bigint,
    event_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    case_id bigint,
    event_title text,
    event_source text,
    event_content text,
    event_raw text,
    event_date timestamp without time zone,
    event_added timestamp without time zone,
    event_in_graph boolean,
    event_in_summary boolean,
    user_id bigint,
    modification_history jsonb,
    event_color text,
    event_tags text,
    event_tz text,
    event_date_wtz timestamp without time zone,
    event_is_flagged boolean,
    custom_attributes jsonb,
    CONSTRAINT check_different_ids CHECK ((event_id <> parent_event_id))
);


ALTER TABLE public.cases_events OWNER TO postgres;

--
-- Name: cases_events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cases_events_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cases_events_event_id_seq OWNER TO postgres;

--
-- Name: cases_events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cases_events_event_id_seq OWNED BY public.cases_events.event_id;


--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    client_id bigint NOT NULL,
    client_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name text,
    description text,
    sla text,
    creation_date timestamp without time zone DEFAULT now(),
    created_by bigint,
    last_update_date timestamp without time zone DEFAULT now(),
    custom_attributes json
);


ALTER TABLE public.client OWNER TO postgres;

--
-- Name: client_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.client_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_client_id_seq OWNER TO postgres;

--
-- Name: client_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.client_client_id_seq OWNED BY public.client.client_id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    comment_id bigint NOT NULL,
    comment_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    comment_text text,
    comment_date timestamp without time zone,
    comment_update_date timestamp without time zone,
    comment_user_id bigint,
    comment_case_id bigint,
    comment_alert_id bigint
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comments_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_comment_id_seq OWNER TO postgres;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comments_comment_id_seq OWNED BY public.comments.comment_id;


--
-- Name: contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact (
    id bigint NOT NULL,
    contact_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    contact_name text,
    contact_email text,
    contact_role text,
    contact_note text,
    contact_work_phone text,
    contact_mobile_phone text,
    custom_attributes json,
    client_id bigint
);


ALTER TABLE public.contact OWNER TO postgres;

--
-- Name: contact_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_id_seq OWNER TO postgres;

--
-- Name: contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_id_seq OWNED BY public.contact.id;


--
-- Name: custom_attribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_attribute (
    attribute_id integer NOT NULL,
    attribute_display_name text,
    attribute_description text,
    attribute_for text,
    attribute_content json
);


ALTER TABLE public.custom_attribute OWNER TO postgres;

--
-- Name: custom_attribute_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_attribute_attribute_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_attribute_attribute_id_seq OWNER TO postgres;

--
-- Name: custom_attribute_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_attribute_attribute_id_seq OWNED BY public.custom_attribute.attribute_id;


--
-- Name: data_store_file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_store_file (
    file_id bigint NOT NULL,
    file_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    file_original_name text NOT NULL,
    file_local_name text NOT NULL,
    file_description text,
    file_date_added timestamp without time zone,
    file_tags text,
    file_size bigint,
    file_is_ioc boolean,
    file_is_evidence boolean,
    file_password text,
    file_parent_id bigint NOT NULL,
    file_sha256 text,
    added_by_user_id bigint NOT NULL,
    modification_history json,
    file_case_id bigint NOT NULL
);


ALTER TABLE public.data_store_file OWNER TO postgres;

--
-- Name: data_store_file_file_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.data_store_file_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_store_file_file_id_seq OWNER TO postgres;

--
-- Name: data_store_file_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.data_store_file_file_id_seq OWNED BY public.data_store_file.file_id;


--
-- Name: data_store_path; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_store_path (
    path_id bigint NOT NULL,
    path_uuid uuid,
    path_name text NOT NULL,
    path_parent_id bigint,
    path_is_root boolean,
    path_case_id bigint NOT NULL
);


ALTER TABLE public.data_store_path OWNER TO postgres;

--
-- Name: data_store_path_path_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.data_store_path_path_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_store_path_path_id_seq OWNER TO postgres;

--
-- Name: data_store_path_path_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.data_store_path_path_id_seq OWNED BY public.data_store_path.path_id;


--
-- Name: event_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_category (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.event_category OWNER TO postgres;

--
-- Name: event_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_category_id_seq OWNER TO postgres;

--
-- Name: event_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_category_id_seq OWNED BY public.event_category.id;


--
-- Name: event_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_event_id bigint
);


ALTER TABLE public.event_comments OWNER TO postgres;

--
-- Name: event_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_comments_id_seq OWNER TO postgres;

--
-- Name: event_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_comments_id_seq OWNED BY public.event_comments.id;


--
-- Name: evidence_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.evidence_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_evidence_id bigint
);


ALTER TABLE public.evidence_comments OWNER TO postgres;

--
-- Name: evidence_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.evidence_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.evidence_comments_id_seq OWNER TO postgres;

--
-- Name: evidence_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.evidence_comments_id_seq OWNED BY public.evidence_comments.id;


--
-- Name: evidence_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.evidence_type (
    id integer NOT NULL,
    name text,
    description text,
    creation_date timestamp without time zone DEFAULT now(),
    created_by_id bigint
);


ALTER TABLE public.evidence_type OWNER TO postgres;

--
-- Name: evidence_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.evidence_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.evidence_type_id_seq OWNER TO postgres;

--
-- Name: evidence_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.evidence_type_id_seq OWNED BY public.evidence_type.id;


--
-- Name: global_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.global_tasks (
    id bigint NOT NULL,
    task_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    task_title text,
    task_description text,
    task_tags text,
    task_open_date timestamp without time zone,
    task_close_date timestamp without time zone,
    task_last_update timestamp without time zone,
    task_userid_open bigint,
    task_userid_close bigint,
    task_userid_update bigint,
    task_assignee_id bigint,
    task_status_id integer
);


ALTER TABLE public.global_tasks OWNER TO postgres;

--
-- Name: global_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.global_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.global_tasks_id_seq OWNER TO postgres;

--
-- Name: global_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.global_tasks_id_seq OWNED BY public.global_tasks.id;


--
-- Name: group_case_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_case_access (
    id bigint NOT NULL,
    group_id bigint NOT NULL,
    case_id bigint NOT NULL,
    access_level bigint NOT NULL
);


ALTER TABLE public.group_case_access OWNER TO postgres;

--
-- Name: group_case_access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.group_case_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_case_access_id_seq OWNER TO postgres;

--
-- Name: group_case_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.group_case_access_id_seq OWNED BY public.group_case_access.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    group_id bigint NOT NULL,
    group_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    group_name text NOT NULL,
    group_description text,
    group_permissions bigint NOT NULL,
    group_auto_follow boolean NOT NULL,
    group_auto_follow_access_level bigint NOT NULL
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: groups_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.groups_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_group_id_seq OWNER TO postgres;

--
-- Name: groups_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.groups_group_id_seq OWNED BY public.groups.group_id;


--
-- Name: ioc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ioc (
    ioc_id bigint NOT NULL,
    ioc_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    ioc_value text,
    ioc_type_id integer,
    ioc_description text,
    ioc_tags character varying(512),
    user_id bigint,
    ioc_misp text,
    ioc_tlp_id integer,
    custom_attributes json,
    ioc_enrichment jsonb,
    modification_history json
);


ALTER TABLE public.ioc OWNER TO postgres;

--
-- Name: ioc_asset_link; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ioc_asset_link (
    ioc_asset_link_id integer NOT NULL,
    ioc_id bigint NOT NULL,
    asset_id bigint NOT NULL
);


ALTER TABLE public.ioc_asset_link OWNER TO postgres;

--
-- Name: ioc_asset_link_ioc_asset_link_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ioc_asset_link_ioc_asset_link_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ioc_asset_link_ioc_asset_link_id_seq OWNER TO postgres;

--
-- Name: ioc_asset_link_ioc_asset_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ioc_asset_link_ioc_asset_link_id_seq OWNED BY public.ioc_asset_link.ioc_asset_link_id;


--
-- Name: ioc_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ioc_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_ioc_id bigint
);


ALTER TABLE public.ioc_comments OWNER TO postgres;

--
-- Name: ioc_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ioc_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ioc_comments_id_seq OWNER TO postgres;

--
-- Name: ioc_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ioc_comments_id_seq OWNED BY public.ioc_comments.id;


--
-- Name: ioc_ioc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ioc_ioc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ioc_ioc_id_seq OWNER TO postgres;

--
-- Name: ioc_ioc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ioc_ioc_id_seq OWNED BY public.ioc.ioc_id;


--
-- Name: ioc_link; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ioc_link (
    ioc_link_id integer NOT NULL,
    ioc_id bigint,
    case_id bigint NOT NULL
);


ALTER TABLE public.ioc_link OWNER TO postgres;

--
-- Name: ioc_link_ioc_link_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ioc_link_ioc_link_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ioc_link_ioc_link_id_seq OWNER TO postgres;

--
-- Name: ioc_link_ioc_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ioc_link_ioc_link_id_seq OWNED BY public.ioc_link.ioc_link_id;


--
-- Name: ioc_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ioc_type (
    type_id integer NOT NULL,
    type_name text,
    type_description text,
    type_taxonomy text,
    type_validation_regex text,
    type_validation_expect text
);


ALTER TABLE public.ioc_type OWNER TO postgres;

--
-- Name: ioc_type_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ioc_type_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ioc_type_type_id_seq OWNER TO postgres;

--
-- Name: ioc_type_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ioc_type_type_id_seq OWNED BY public.ioc_type.type_id;


--
-- Name: iris_hooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_hooks (
    id integer NOT NULL,
    hook_name text,
    hook_description text
);


ALTER TABLE public.iris_hooks OWNER TO postgres;

--
-- Name: iris_hooks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.iris_hooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.iris_hooks_id_seq OWNER TO postgres;

--
-- Name: iris_hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.iris_hooks_id_seq OWNED BY public.iris_hooks.id;


--
-- Name: iris_module; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_module (
    id integer NOT NULL,
    added_by_id bigint NOT NULL,
    module_human_name text,
    module_name text,
    module_description text,
    module_version text,
    interface_version text,
    date_added timestamp without time zone,
    is_active boolean,
    has_pipeline boolean,
    pipeline_args json,
    module_config json,
    module_type text
);


ALTER TABLE public.iris_module OWNER TO postgres;

--
-- Name: iris_module_hooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_module_hooks (
    id bigint NOT NULL,
    module_id integer NOT NULL,
    hook_id integer NOT NULL,
    is_manual_hook boolean,
    manual_hook_ui_name text,
    retry_on_fail boolean,
    max_retry integer,
    run_asynchronously boolean,
    wait_till_return boolean
);


ALTER TABLE public.iris_module_hooks OWNER TO postgres;

--
-- Name: iris_module_hooks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.iris_module_hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.iris_module_hooks_id_seq OWNER TO postgres;

--
-- Name: iris_module_hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.iris_module_hooks_id_seq OWNED BY public.iris_module_hooks.id;


--
-- Name: iris_module_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.iris_module_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.iris_module_id_seq OWNER TO postgres;

--
-- Name: iris_module_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.iris_module_id_seq OWNED BY public.iris_module.id;


--
-- Name: iris_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_reports (
    report_id integer NOT NULL,
    case_id bigint NOT NULL,
    report_title character varying(155),
    report_date timestamp without time zone,
    report_content json,
    user_id bigint
);


ALTER TABLE public.iris_reports OWNER TO postgres;

--
-- Name: iris_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.iris_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.iris_reports_id_seq OWNER TO postgres;

--
-- Name: languages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.languages (
    id integer NOT NULL,
    name character varying,
    code character varying
);


ALTER TABLE public.languages OWNER TO postgres;

--
-- Name: languages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.languages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.languages_id_seq OWNER TO postgres;

--
-- Name: languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.languages_id_seq OWNED BY public.languages.id;


--
-- Name: note_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.note_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_note_id bigint
);


ALTER TABLE public.note_comments OWNER TO postgres;

--
-- Name: note_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.note_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.note_comments_id_seq OWNER TO postgres;

--
-- Name: note_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.note_comments_id_seq OWNED BY public.note_comments.id;


--
-- Name: note_directory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.note_directory (
    id bigint NOT NULL,
    name text NOT NULL,
    parent_id bigint,
    case_id bigint NOT NULL
);


ALTER TABLE public.note_directory OWNER TO postgres;

--
-- Name: note_directory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.note_directory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.note_directory_id_seq OWNER TO postgres;

--
-- Name: note_directory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.note_directory_id_seq OWNED BY public.note_directory.id;


--
-- Name: note_revisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.note_revisions (
    revision_id bigint NOT NULL,
    note_id bigint NOT NULL,
    revision_number integer NOT NULL,
    note_title character varying(155),
    note_content text,
    note_user bigint,
    revision_timestamp timestamp without time zone
);


ALTER TABLE public.note_revisions OWNER TO postgres;

--
-- Name: note_revisions_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.note_revisions_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.note_revisions_revision_id_seq OWNER TO postgres;

--
-- Name: note_revisions_revision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.note_revisions_revision_id_seq OWNED BY public.note_revisions.revision_id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notes (
    note_id bigint NOT NULL,
    note_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    note_title character varying(155),
    note_content text,
    note_user bigint,
    note_creationdate timestamp without time zone,
    note_lastupdate timestamp without time zone,
    note_case_id bigint,
    custom_attributes json,
    directory_id bigint,
    modification_history json
);


ALTER TABLE public.notes OWNER TO postgres;

--
-- Name: notes_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notes_group (
    group_id bigint NOT NULL,
    group_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    group_title character varying(155),
    group_user bigint,
    group_creationdate timestamp without time zone,
    group_lastupdate timestamp without time zone,
    group_case_id bigint
);


ALTER TABLE public.notes_group OWNER TO postgres;

--
-- Name: notes_group_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notes_group_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notes_group_group_id_seq OWNER TO postgres;

--
-- Name: notes_group_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notes_group_group_id_seq OWNED BY public.notes_group.group_id;


--
-- Name: notes_group_link; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notes_group_link (
    link_id bigint NOT NULL,
    group_id bigint,
    note_id bigint,
    case_id bigint
);


ALTER TABLE public.notes_group_link OWNER TO postgres;

--
-- Name: notes_group_link_link_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notes_group_link_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notes_group_link_link_id_seq OWNER TO postgres;

--
-- Name: notes_group_link_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notes_group_link_link_id_seq OWNED BY public.notes_group_link.link_id;


--
-- Name: notes_note_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notes_note_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notes_note_id_seq OWNER TO postgres;

--
-- Name: notes_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notes_note_id_seq OWNED BY public.notes.note_id;


--
-- Name: object_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.object_state (
    object_id bigint NOT NULL,
    object_case_id bigint,
    object_updated_by_id integer,
    object_name text,
    object_state bigint,
    object_last_update timestamp without time zone
);


ALTER TABLE public.object_state OWNER TO postgres;

--
-- Name: object_state_object_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.object_state_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.object_state_object_id_seq OWNER TO postgres;

--
-- Name: object_state_object_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.object_state_object_id_seq OWNED BY public.object_state.object_id;


--
-- Name: organisation_case_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organisation_case_access (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    case_id bigint NOT NULL,
    access_level bigint NOT NULL
);


ALTER TABLE public.organisation_case_access OWNER TO postgres;

--
-- Name: organisation_case_access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organisation_case_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisation_case_access_id_seq OWNER TO postgres;

--
-- Name: organisation_case_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organisation_case_access_id_seq OWNED BY public.organisation_case_access.id;


--
-- Name: organisations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organisations (
    org_id bigint NOT NULL,
    org_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    org_name text NOT NULL,
    org_description text,
    org_url text,
    org_logo text,
    org_email text,
    org_nationality text,
    org_sector text,
    org_type text
);


ALTER TABLE public.organisations OWNER TO postgres;

--
-- Name: organisations_org_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organisations_org_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisations_org_id_seq OWNER TO postgres;

--
-- Name: organisations_org_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organisations_org_id_seq OWNED BY public.organisations.org_id;


--
-- Name: os_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.os_type (
    type_id integer NOT NULL,
    type_name character varying(155)
);


ALTER TABLE public.os_type OWNER TO postgres;

--
-- Name: os_type_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.os_type_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.os_type_type_id_seq OWNER TO postgres;

--
-- Name: os_type_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.os_type_type_id_seq OWNED BY public.os_type.type_id;


--
-- Name: report_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_type (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.report_type OWNER TO postgres;

--
-- Name: report_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_type_id_seq OWNER TO postgres;

--
-- Name: report_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_type_id_seq OWNED BY public.report_type.id;


--
-- Name: review_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_status (
    id integer NOT NULL,
    status_name text NOT NULL
);


ALTER TABLE public.review_status OWNER TO postgres;

--
-- Name: review_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_status_id_seq OWNER TO postgres;

--
-- Name: review_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.review_status_id_seq OWNED BY public.review_status.id;


--
-- Name: saved_filters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saved_filters (
    filter_id bigint NOT NULL,
    created_by bigint NOT NULL,
    filter_name text NOT NULL,
    filter_description text,
    filter_data json NOT NULL,
    filter_is_private boolean NOT NULL,
    filter_type text NOT NULL
);


ALTER TABLE public.saved_filters OWNER TO postgres;

--
-- Name: saved_filters_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.saved_filters_filter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.saved_filters_filter_id_seq OWNER TO postgres;

--
-- Name: saved_filters_filter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.saved_filters_filter_id_seq OWNED BY public.saved_filters.filter_id;


--
-- Name: server_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.server_settings (
    id integer NOT NULL,
    https_proxy text,
    http_proxy text,
    prevent_post_mod_repush boolean,
    prevent_post_objects_repush boolean,
    has_updates_available boolean,
    enable_updates_check boolean,
    password_policy_min_length integer,
    password_policy_upper_case boolean,
    password_policy_lower_case boolean,
    password_policy_digit boolean,
    password_policy_special_chars text,
    enforce_mfa boolean
);


ALTER TABLE public.server_settings OWNER TO postgres;

--
-- Name: server_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.server_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.server_settings_id_seq OWNER TO postgres;

--
-- Name: server_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.server_settings_id_seq OWNED BY public.server_settings.id;


--
-- Name: severities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.severities (
    severity_id integer NOT NULL,
    severity_name text NOT NULL,
    severity_description text
);


ALTER TABLE public.severities OWNER TO postgres;

--
-- Name: severities_severity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.severities_severity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.severities_severity_id_seq OWNER TO postgres;

--
-- Name: severities_severity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.severities_severity_id_seq OWNED BY public.severities.severity_id;


--
-- Name: silent_ridge_receipts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.silent_ridge_receipts (
    key character varying(200) NOT NULL,
    remote bigint NOT NULL
);


ALTER TABLE public.silent_ridge_receipts OWNER TO postgres;

--
-- Name: silent_ridge_work_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.silent_ridge_work_status (
    user_id bigint NOT NULL,
    ticket character varying(16) NOT NULL,
    status character varying(24) NOT NULL
);


ALTER TABLE public.silent_ridge_work_status OWNER TO postgres;

--
-- Name: similar_alerts_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.similar_alerts_cache (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    asset_name text,
    ioc_value text,
    alert_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    asset_type_id integer,
    ioc_type_id integer
);


ALTER TABLE public.similar_alerts_cache OWNER TO postgres;

--
-- Name: similar_alerts_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.similar_alerts_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.similar_alerts_cache_id_seq OWNER TO postgres;

--
-- Name: similar_alerts_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.similar_alerts_cache_id_seq OWNED BY public.similar_alerts_cache.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    tag_title text,
    tag_creation_date timestamp without time zone,
    tag_namespace text
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO postgres;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: task_assignee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_assignee (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint NOT NULL
);


ALTER TABLE public.task_assignee OWNER TO postgres;

--
-- Name: task_assignee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_assignee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_assignee_id_seq OWNER TO postgres;

--
-- Name: task_assignee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_assignee_id_seq OWNED BY public.task_assignee.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_task_id bigint
);


ALTER TABLE public.task_comments OWNER TO postgres;

--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_comments_id_seq OWNER TO postgres;

--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: task_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_status (
    id integer NOT NULL,
    status_name text,
    status_description text,
    status_bscolor text
);


ALTER TABLE public.task_status OWNER TO postgres;

--
-- Name: task_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_status_id_seq OWNER TO postgres;

--
-- Name: task_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_status_id_seq OWNED BY public.task_status.id;


--
-- Name: tlp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tlp (
    tlp_id integer NOT NULL,
    tlp_name text,
    tlp_bscolor text
);


ALTER TABLE public.tlp OWNER TO postgres;

--
-- Name: tlp_tlp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tlp_tlp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tlp_tlp_id_seq OWNER TO postgres;

--
-- Name: tlp_tlp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tlp_tlp_id_seq OWNED BY public.tlp.tlp_id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id bigint NOT NULL,
    "user" character varying(64),
    name character varying(64),
    email character varying(120),
    uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    password character varying(500),
    ctx_case integer,
    ctx_human_case character varying(256),
    active boolean,
    api_key text,
    external_id text,
    in_dark_mode boolean,
    has_mini_sidebar boolean,
    has_deletion_confirmation boolean,
    is_service_account boolean,
    mfa_secrets text,
    webauthn_credentials json,
    mfa_setup_complete boolean
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_activity (
    id bigint NOT NULL,
    user_id bigint,
    case_id bigint,
    activity_date timestamp without time zone,
    activity_desc text,
    user_input boolean,
    is_from_api boolean,
    display_in_ui boolean
);


ALTER TABLE public.user_activity OWNER TO postgres;

--
-- Name: user_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_activity_id_seq OWNER TO postgres;

--
-- Name: user_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_activity_id_seq OWNED BY public.user_activity.id;


--
-- Name: user_case_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_case_access (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    case_id bigint NOT NULL,
    access_level bigint NOT NULL
);


ALTER TABLE public.user_case_access OWNER TO postgres;

--
-- Name: user_case_access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_case_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_case_access_id_seq OWNER TO postgres;

--
-- Name: user_case_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_case_access_id_seq OWNED BY public.user_case_access.id;


--
-- Name: user_case_effective_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_case_effective_access (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    case_id bigint NOT NULL,
    access_level bigint NOT NULL
);


ALTER TABLE public.user_case_effective_access OWNER TO postgres;

--
-- Name: user_case_effective_access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_case_effective_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_case_effective_access_id_seq OWNER TO postgres;

--
-- Name: user_case_effective_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_case_effective_access_id_seq OWNED BY public.user_case_effective_access.id;


--
-- Name: user_client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_client (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    client_id bigint NOT NULL,
    access_level bigint NOT NULL,
    allow_alerts boolean NOT NULL
);


ALTER TABLE public.user_client OWNER TO postgres;

--
-- Name: user_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_client_id_seq OWNER TO postgres;

--
-- Name: user_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_client_id_seq OWNED BY public.user_client.id;


--
-- Name: user_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_group (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id bigint NOT NULL
);


ALTER TABLE public.user_group OWNER TO postgres;

--
-- Name: user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_group_id_seq OWNER TO postgres;

--
-- Name: user_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_group_id_seq OWNED BY public.user_group.id;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_organisation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_organisation (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    org_id bigint NOT NULL,
    is_primary_org boolean NOT NULL
);


ALTER TABLE public.user_organisation OWNER TO postgres;

--
-- Name: user_organisation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_organisation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_organisation_id_seq OWNER TO postgres;

--
-- Name: user_organisation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_organisation_id_seq OWNED BY public.user_organisation.id;


--
-- Name: alert_resolution_status resolution_status_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_resolution_status ALTER COLUMN resolution_status_id SET DEFAULT nextval('public.alert_resolution_status_resolution_status_id_seq'::regclass);


--
-- Name: alert_similarity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_similarity ALTER COLUMN id SET DEFAULT nextval('public.alert_similarity_id_seq'::regclass);


--
-- Name: alert_status status_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_status ALTER COLUMN status_id SET DEFAULT nextval('public.alert_status_status_id_seq'::regclass);


--
-- Name: alerts alert_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts ALTER COLUMN alert_id SET DEFAULT nextval('public.alerts_alert_id_seq'::regclass);


--
-- Name: analysis_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analysis_status ALTER COLUMN id SET DEFAULT nextval('public.analysis_status_id_seq'::regclass);


--
-- Name: asset_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asset_comments ALTER COLUMN id SET DEFAULT nextval('public.asset_comments_id_seq'::regclass);


--
-- Name: assets_type asset_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets_type ALTER COLUMN asset_id SET DEFAULT nextval('public.assets_type_asset_id_seq'::regclass);


--
-- Name: case_assets asset_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_assets ALTER COLUMN asset_id SET DEFAULT nextval('public.case_assets_asset_id_seq'::regclass);


--
-- Name: case_classification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_classification ALTER COLUMN id SET DEFAULT nextval('public.case_classification_id_seq'::regclass);


--
-- Name: case_events_assets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_assets ALTER COLUMN id SET DEFAULT nextval('public.case_events_assets_id_seq'::regclass);


--
-- Name: case_events_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_category ALTER COLUMN id SET DEFAULT nextval('public.case_events_category_id_seq'::regclass);


--
-- Name: case_events_ioc id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_ioc ALTER COLUMN id SET DEFAULT nextval('public.case_events_ioc_id_seq'::regclass);


--
-- Name: case_graph_assets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_assets ALTER COLUMN id SET DEFAULT nextval('public.case_graph_assets_id_seq'::regclass);


--
-- Name: case_graph_links id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_links ALTER COLUMN id SET DEFAULT nextval('public.case_graph_links_id_seq'::regclass);


--
-- Name: case_protagonist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_protagonist ALTER COLUMN id SET DEFAULT nextval('public.case_protagonist_id_seq'::regclass);


--
-- Name: case_received_file id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_received_file ALTER COLUMN id SET DEFAULT nextval('public.case_received_file_id_seq'::regclass);


--
-- Name: case_state state_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_state ALTER COLUMN state_id SET DEFAULT nextval('public.case_state_state_id_seq'::regclass);


--
-- Name: case_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tasks ALTER COLUMN id SET DEFAULT nextval('public.case_tasks_id_seq'::regclass);


--
-- Name: case_template id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template ALTER COLUMN id SET DEFAULT nextval('public.case_template_id_seq'::regclass);


--
-- Name: case_template_report id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template_report ALTER COLUMN id SET DEFAULT nextval('public.case_template_report_id_seq'::regclass);


--
-- Name: cases case_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases ALTER COLUMN case_id SET DEFAULT nextval('public.cases_case_id_seq'::regclass);


--
-- Name: cases_assets_ext asset_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_assets_ext ALTER COLUMN asset_id SET DEFAULT nextval('public.cases_assets_ext_asset_id_seq'::regclass);


--
-- Name: cases_events event_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_events ALTER COLUMN event_id SET DEFAULT nextval('public.cases_events_event_id_seq'::regclass);


--
-- Name: client client_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client ALTER COLUMN client_id SET DEFAULT nextval('public.client_client_id_seq'::regclass);


--
-- Name: comments comment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments ALTER COLUMN comment_id SET DEFAULT nextval('public.comments_comment_id_seq'::regclass);


--
-- Name: contact id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact ALTER COLUMN id SET DEFAULT nextval('public.contact_id_seq'::regclass);


--
-- Name: custom_attribute attribute_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_attribute ALTER COLUMN attribute_id SET DEFAULT nextval('public.custom_attribute_attribute_id_seq'::regclass);


--
-- Name: data_store_file file_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_file ALTER COLUMN file_id SET DEFAULT nextval('public.data_store_file_file_id_seq'::regclass);


--
-- Name: data_store_path path_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_path ALTER COLUMN path_id SET DEFAULT nextval('public.data_store_path_path_id_seq'::regclass);


--
-- Name: event_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_category ALTER COLUMN id SET DEFAULT nextval('public.event_category_id_seq'::regclass);


--
-- Name: event_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_comments ALTER COLUMN id SET DEFAULT nextval('public.event_comments_id_seq'::regclass);


--
-- Name: evidence_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence_comments ALTER COLUMN id SET DEFAULT nextval('public.evidence_comments_id_seq'::regclass);


--
-- Name: evidence_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence_type ALTER COLUMN id SET DEFAULT nextval('public.evidence_type_id_seq'::regclass);


--
-- Name: global_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.global_tasks ALTER COLUMN id SET DEFAULT nextval('public.global_tasks_id_seq'::regclass);


--
-- Name: group_case_access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_case_access ALTER COLUMN id SET DEFAULT nextval('public.group_case_access_id_seq'::regclass);


--
-- Name: groups group_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups ALTER COLUMN group_id SET DEFAULT nextval('public.groups_group_id_seq'::regclass);


--
-- Name: ioc ioc_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc ALTER COLUMN ioc_id SET DEFAULT nextval('public.ioc_ioc_id_seq'::regclass);


--
-- Name: ioc_asset_link ioc_asset_link_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_asset_link ALTER COLUMN ioc_asset_link_id SET DEFAULT nextval('public.ioc_asset_link_ioc_asset_link_id_seq'::regclass);


--
-- Name: ioc_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_comments ALTER COLUMN id SET DEFAULT nextval('public.ioc_comments_id_seq'::regclass);


--
-- Name: ioc_link ioc_link_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_link ALTER COLUMN ioc_link_id SET DEFAULT nextval('public.ioc_link_ioc_link_id_seq'::regclass);


--
-- Name: ioc_type type_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_type ALTER COLUMN type_id SET DEFAULT nextval('public.ioc_type_type_id_seq'::regclass);


--
-- Name: iris_hooks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_hooks ALTER COLUMN id SET DEFAULT nextval('public.iris_hooks_id_seq'::regclass);


--
-- Name: iris_module id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_module ALTER COLUMN id SET DEFAULT nextval('public.iris_module_id_seq'::regclass);


--
-- Name: iris_module_hooks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_module_hooks ALTER COLUMN id SET DEFAULT nextval('public.iris_module_hooks_id_seq'::regclass);


--
-- Name: languages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.languages ALTER COLUMN id SET DEFAULT nextval('public.languages_id_seq'::regclass);


--
-- Name: note_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_comments ALTER COLUMN id SET DEFAULT nextval('public.note_comments_id_seq'::regclass);


--
-- Name: note_directory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_directory ALTER COLUMN id SET DEFAULT nextval('public.note_directory_id_seq'::regclass);


--
-- Name: note_revisions revision_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_revisions ALTER COLUMN revision_id SET DEFAULT nextval('public.note_revisions_revision_id_seq'::regclass);


--
-- Name: notes note_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes ALTER COLUMN note_id SET DEFAULT nextval('public.notes_note_id_seq'::regclass);


--
-- Name: notes_group group_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group ALTER COLUMN group_id SET DEFAULT nextval('public.notes_group_group_id_seq'::regclass);


--
-- Name: notes_group_link link_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group_link ALTER COLUMN link_id SET DEFAULT nextval('public.notes_group_link_link_id_seq'::regclass);


--
-- Name: object_state object_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.object_state ALTER COLUMN object_id SET DEFAULT nextval('public.object_state_object_id_seq'::regclass);


--
-- Name: organisation_case_access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organisation_case_access ALTER COLUMN id SET DEFAULT nextval('public.organisation_case_access_id_seq'::regclass);


--
-- Name: organisations org_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organisations ALTER COLUMN org_id SET DEFAULT nextval('public.organisations_org_id_seq'::regclass);


--
-- Name: os_type type_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.os_type ALTER COLUMN type_id SET DEFAULT nextval('public.os_type_type_id_seq'::regclass);


--
-- Name: report_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_type ALTER COLUMN id SET DEFAULT nextval('public.report_type_id_seq'::regclass);


--
-- Name: review_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_status ALTER COLUMN id SET DEFAULT nextval('public.review_status_id_seq'::regclass);


--
-- Name: saved_filters filter_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_filters ALTER COLUMN filter_id SET DEFAULT nextval('public.saved_filters_filter_id_seq'::regclass);


--
-- Name: server_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.server_settings ALTER COLUMN id SET DEFAULT nextval('public.server_settings_id_seq'::regclass);


--
-- Name: severities severity_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.severities ALTER COLUMN severity_id SET DEFAULT nextval('public.severities_severity_id_seq'::regclass);


--
-- Name: similar_alerts_cache id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.similar_alerts_cache ALTER COLUMN id SET DEFAULT nextval('public.similar_alerts_cache_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: task_assignee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignee ALTER COLUMN id SET DEFAULT nextval('public.task_assignee_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: task_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_status ALTER COLUMN id SET DEFAULT nextval('public.task_status_id_seq'::regclass);


--
-- Name: tlp tlp_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tlp ALTER COLUMN tlp_id SET DEFAULT nextval('public.tlp_tlp_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_activity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity ALTER COLUMN id SET DEFAULT nextval('public.user_activity_id_seq'::regclass);


--
-- Name: user_case_access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_case_access ALTER COLUMN id SET DEFAULT nextval('public.user_case_access_id_seq'::regclass);


--
-- Name: user_case_effective_access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_case_effective_access ALTER COLUMN id SET DEFAULT nextval('public.user_case_effective_access_id_seq'::regclass);


--
-- Name: user_client id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_client ALTER COLUMN id SET DEFAULT nextval('public.user_client_id_seq'::regclass);


--
-- Name: user_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_group ALTER COLUMN id SET DEFAULT nextval('public.user_group_id_seq'::regclass);


--
-- Name: user_organisation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_organisation ALTER COLUMN id SET DEFAULT nextval('public.user_organisation_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: iris
--

COPY public.alembic_version (version_num) FROM stdin;
d5a720d1b99b
\.


--
-- Data for Name: alert_assets_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_assets_association (alert_id, asset_id) FROM stdin;
\.


--
-- Data for Name: alert_case_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_case_association (alert_id, case_id) FROM stdin;
\.


--
-- Data for Name: alert_iocs_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_iocs_association (alert_id, ioc_id) FROM stdin;
\.


--
-- Data for Name: alert_resolution_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_resolution_status (resolution_status_id, resolution_status_name, resolution_status_description) FROM stdin;
1	False Positive	The alert was a false positive
2	True Positive With Impact	The alert was a true positive and had an impact
3	True Positive Without Impact	The alert was a true positive but had no impact
4	Not Applicable	The alert is not applicable
5	Unknown	Unknown resolution status
6	Legitimate	The alert is acceptable and expected
\.


--
-- Data for Name: alert_similarity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_similarity (id, alert_id, similar_alert_id, similarity_type, matching_asset_id, matching_ioc_id) FROM stdin;
\.


--
-- Data for Name: alert_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_status (status_id, status_name, status_description) FROM stdin;
1	Unspecified	Unspecified
2	New	Alert is new and unassigned
3	Assigned	Alert is assigned to a user and pending investigation
4	In progress	Alert is being investigated
5	Pending	Alert is in a pending state
6	Closed	Alert closed, no action taken
7	Merged	Alert merged into an existing case
8	Escalated	Alert converted to a new case
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alerts (alert_id, alert_uuid, alert_title, alert_description, alert_source, alert_source_ref, alert_source_link, alert_source_content, alert_severity_id, alert_status_id, alert_context, alert_source_event_time, alert_creation_time, alert_note, alert_tags, alert_owner_id, modification_history, alert_customer_id, alert_classification_id, alert_resolution_status_id) FROM stdin;
\.


--
-- Data for Name: analysis_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analysis_status (id, name) FROM stdin;
1	Unspecified
2	To be done
3	Started
4	Pending
5	Canceled
6	Done
\.


--
-- Data for Name: asset_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.asset_comments (id, comment_id, comment_asset_id) FROM stdin;
\.


--
-- Data for Name: assets_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assets_type (asset_id, asset_name, asset_description, asset_icon_not_compromised, asset_icon_compromised) FROM stdin;
1	Account	Generic Account	user.png	ioc_user.png
2	Firewall	Firewall	firewall.png	ioc_firewall.png
3	Linux - Server	Linux server	server.png	ioc_server.png
4	Linux - Computer	Linux computer	desktop.png	ioc_desktop.png
5	Linux Account	Linux Account	user.png	ioc_user.png
6	Mac - Computer	Mac computer	desktop.png	ioc_desktop.png
7	Phone - Android	Android Phone	phone.png	ioc_phone.png
8	Phone - IOS	Apple Phone	phone.png	ioc_phone.png
9	Windows - Computer	Standard Windows Computer	windows_desktop.png	ioc_windows_desktop.png
10	Windows - Server	Standard Windows Server	windows_server.png	ioc_windows_server.png
11	Windows - DC	Domain Controller	windows_server.png	ioc_windows_server.png
12	Router	Router	router.png	ioc_router.png
13	Switch	Switch	switch.png	ioc_switch.png
14	VPN	VPN	vpn.png	ioc_vpn.png
15	WAF	WAF	firewall.png	ioc_firewall.png
16	Windows Account - Local	Windows Account - Local	user.png	ioc_user.png
17	Windows Account - Local - Admin	Windows Account - Local - Admin	user.png	ioc_user.png
18	Windows Account - AD	Windows Account - AD	user.png	ioc_user.png
19	Windows Account - AD - Admin	Windows Account - AD - Admin	user.png	ioc_user.png
20	Windows Account - AD - krbtgt	Windows Account - AD - krbtgt	user.png	ioc_user.png
21	Windows Account - AD - Service	Windows Account - AD - krbtgt	user.png	ioc_user.png
\.


--
-- Data for Name: case_assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_assets (asset_id, asset_uuid, asset_name, asset_description, asset_domain, asset_ip, asset_info, asset_compromise_status_id, asset_type_id, asset_tags, case_id, date_added, date_update, user_id, analysis_status_id, custom_attributes, asset_enrichment, modification_history) FROM stdin;
\.


--
-- Data for Name: case_classification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_classification (id, name, name_expanded, description, creation_date, created_by_id) FROM stdin;
1	abusive-content:spam	Abusive-Content: spam	Spam or ‘unsolicited bulk e-mail’, meaning that the recipient has not granted verifiable permission for the message to be sent and that the message is sent as part of a larger collection of messages, all having identical content.	2026-10-27 21:39:38.001331	\N
2	abusive-content:harmful-speech	Abusive-Content: Harmful Speech	Discretization or discrimination of somebody (e.g. cyber stalking, racism and threats against one or more individuals) May be found on a forum, email, tweet etc…	2026-10-27 21:39:38.004738	\N
3	abusive-content:violence	Abusive-Content: Child/Sexual/Violence/...	Any Child pornography, glorification of violence, may be found on a website, forum, email, tweet etc…	2026-10-27 21:39:38.007306	\N
4	malicious-code:virus	Malicious-Code: Virus	Malicious code that replicate itself and infects the computer and files;	2026-10-27 21:39:38.009301	\N
5	malicious-code:worm	Malicious-Code: Worm	Malware that self-replicates and spread itself to other computers in the network without any user interaction;	2026-10-27 21:39:38.011314	\N
6	malicious-code:ransomware	Malicious-Code: Ransomware	Ransomware is a type of malicious software from cryptovirology that blocks access to the victim's data or threatens to publish it until a ransom is paid.	2026-10-27 21:39:38.013452	\N
7	malicious-code:trojan-malware	Malicious-Code: Trojan/Malware	This category regroups many common malware types (Banking, POS, Mining malware).	2026-10-27 21:39:38.015491	\N
8	malicious-code:spyware-rat	Malicious-Code: Spyware/Rat	This category regroups malware types and tools that may have a bigger impact on the breached infrastructure and usually need further investigations (Common Spyware/Rat, State sponsored malwares, StealersHacking tool).	2026-10-27 21:39:38.017512	\N
9	malicious-code:dialer	Malicious-Code: Dialer	Computer program used to identify the phone numbers that can successfully make a connection with a computer modem. Use this category to classify overpriced SMS sent by malicious mobile application. 	2026-10-27 21:39:38.019445	\N
10	malicious-code:rootkit	Malicious-Code: Rootkit	Malware, which alter the standard functionality of an operating system in order to do its malicious actions in a stealthy way. In practice, Rootkits hijacks systems functions in order to alter the returning values to hide themselves from simple analysis tools.	2026-10-27 21:39:38.021305	\N
11	information-gathering:scanner	Information-Gathering: Scanning	Attacks that send requests to a system to discover weak points. This also includes some kinds of testing processes to gather information about hosts, services and accounts. Examples: fingerd, DNS querying, ICMP, SMTP (EXPN, RCPT,).	2026-10-27 21:39:38.023134	\N
12	information-gathering:sniffing	Information-Gathering: Sniffing	Observing and recording network traffic (wiretapping).	2026-10-27 21:39:38.024978	\N
13	information-gathering:social-engineering	Information-Gathering: Social Engineering	Gathering information from a human being in a non-technical way (eg, lies, tricks, bribes, or threats).	2026-10-27 21:39:38.026841	\N
14	intrusion-attempts:exploit-known-vuln	Intrusion-Attempts: Exploiting known vulnerabilities	An attempt to compromise a system or to disrupt any service by exploiting vulnerabilities with a standardised identifier such as CVE name (eg, buffer overflow, backdoors, cross side scripting, etc).	2026-10-27 21:39:38.028753	\N
15	intrusion-attempts:login-attempts	Intrusion-Attempts: Login attempts	Multiple login attempts (guessing / cracking of passwords, brute force).	2026-10-27 21:39:38.030561	\N
16	intrusion-attempts:new-attack-signature	Intrusion-Attempts: New attack signature	An attempt using an unknown exploit.	2026-10-27 21:39:38.032407	\N
17	intrusion:privileged-account-compromise	Intrusion: Privileged Account Compromise	A successful full compromise of a system or application (service). This can have been caused remotely by a known or new vulnerability, but also by an unauthorized local access.	2026-10-27 21:39:38.034347	\N
18	intrusion:unprivileged-account-compromise	Intrusion: Unprivileged Account Compromise	A successful compromise of a system or application (service). This can have been caused remotely by a known or new vulnerability, but also by an unauthorized local access. The intruded did not achieve to escale his privileges locally. 	2026-10-27 21:39:38.036206	\N
19	intrusion:botnet-member	Intrusion: Botnet member	The compromised asset is also being part of a botnet. This is reserved mainly for public web servers. See malicious code in priority for workstations or internal server’s compromise. For example, phpmailer, etc…	2026-10-27 21:39:38.038092	\N
20	intrusion:domain-compromise	Intrusion: Domain Compromise	The whole domain is compromised; this is commonly used for active directory and detected by a 'pass the ticket' attack or a discovery of 'ad dumps' files.	2026-10-27 21:39:38.040007	\N
21	intrusion:application-compromise	Intrusion: Application Compromise	An application is compromised; the attacker possess an uncontrolled access to data, server, and assets used by this application (CMDB, DB, Backend services, etc.).	2026-10-27 21:39:38.041888	\N
22	availability:dos	Availability: DoS	An attacker attempts to prevent legitimate users from accessing information or services.	2026-10-27 21:39:38.04376	\N
23	availability:ddos	Availability: DDoS	Form of electronic attack involving multiple computers, which send repeated requests (HTTP requests, pings, TCP or UDP Flood) to a server to load it down and render the service inaccessible for a period of time. 	2026-10-27 21:39:38.045626	\N
24	availability:sabotage	Availability: Sabotage	Deliberate and malicious acts that result in the disruption of the normal processes and functions or the destruction or damage of equipment or information.	2026-10-27 21:39:38.047468	\N
25	availability:outage	Availability: Outage (no malice)	Unavailability of the system but done with no malice.	2026-10-27 21:39:38.049463	\N
26	information-content-security:Unauthorised-information-access	Information-Content-Security: Unauthorised access to information	Any access to unauthorized data. It may be access of data on improperly restricted server share or database exfiltered by using a SQLi.	2026-10-27 21:39:38.051304	\N
27	information-content-security:Unauthorised-information-modification	Information-Content-Security: Unauthorised modification of information	Unauthorized tampering of data on files, documents or database.	2026-10-27 21:39:38.053203	\N
28	fraud:copyright	Fraud: Copyright	Selling or installing copies of unlicensed commercial software or other copyright protected materials (Warez).	2026-10-27 21:39:38.05504	\N
29	fraud:masquerade	Fraud: Masquerade	Types of attacks in which one entity illegitimately assumes the identity of another in order to benefit from it. This attack may be used for president fraud requesting transactions.	2026-10-27 21:39:38.057021	\N
30	fraud:phishing	Fraud: Phishing	Masquerading as another entity in order to persuade the user to reveal a private credential.	2026-10-27 21:39:38.058911	\N
31	vulnerable:vulnerable-service	Vulnerable: Open for abuse	Open resolvers, world readable printers, vulnerability apparent from Nessus etc scans, virus, signatures not up to date, etc. This includes for example default SNMP community or default password on any application.	2026-10-27 21:39:38.060801	\N
32	conformity:regulator	Conformity: Regulator	All lack about regulator rules (CSSF, GDPR, etc.).	2026-10-27 21:39:38.062704	\N
33	conformity:standard	Conformity: Standard	All lack about standards certification of the company (ISO27000, NIS, ISAE3402, etc.).	2026-10-27 21:39:38.065413	\N
34	conformity:security-policy	Conformity: Security policy	All lack about the internal security policy of the company.	2026-10-27 21:39:38.069314	\N
35	conformity:other-conformity	Conformity: Other	All lack that do not fit in one of previous categories should be put on this class.	2026-10-27 21:39:38.07232	\N
36	other:other	Other: other	All incidents that do not fit in one of the given categories should be put into this class. If the number of incidents in this category increases, it is an indicator that the classification scheme must be revised.	2026-10-27 21:39:38.07531	\N
\.


--
-- Data for Name: case_events_assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_events_assets (id, event_id, asset_id, case_id) FROM stdin;
\.


--
-- Data for Name: case_events_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_events_category (id, event_id, category_id) FROM stdin;
\.


--
-- Data for Name: case_events_ioc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_events_ioc (id, event_id, ioc_id, case_id) FROM stdin;
\.


--
-- Data for Name: case_graph_assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_graph_assets (id, case_id, asset_id, asset_type_id) FROM stdin;
\.


--
-- Data for Name: case_graph_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_graph_links (id, case_id, source_id, dest_id) FROM stdin;
\.


--
-- Data for Name: case_kanban; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_kanban (case_id, kanban_data) FROM stdin;
\.


--
-- Data for Name: case_protagonist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_protagonist (id, case_id, user_id, name, contact, role) FROM stdin;
\.


--
-- Data for Name: case_received_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_received_file (id, file_uuid, filename, date_added, acquisition_date, file_hash, file_description, file_size, start_date, end_date, case_id, user_id, type_id, custom_attributes, chain_of_custody, modification_history) FROM stdin;
\.


--
-- Data for Name: case_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_state (state_id, state_name, state_description, protected) FROM stdin;
1	Unspecified	Unspecified	t
2	In progress	Case is being investigated	f
3	Open	Case is open	t
4	Containment	Containment is in progress	f
5	Eradication	Eradication is in progress	f
6	Recovery	Recovery is in progress	f
7	Post-Incident	Post-incident phase	f
8	Reporting	Reporting is in progress	f
9	Closed	Case is closed	t
\.


--
-- Data for Name: case_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_tags (case_id, tag_id) FROM stdin;
\.


--
-- Data for Name: case_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_tasks (id, task_uuid, task_title, task_description, task_tags, task_open_date, task_close_date, task_last_update, task_userid_open, task_userid_close, task_userid_update, task_status_id, task_case_id, custom_attributes, modification_history) FROM stdin;
6	b7dc49b8-6884-47b1-8e57-c32b64acfd6b	T06 · Separate password and session authentication	Phase 2 — Test identity and access explanations\nSeparate session activity from password authentication, audit access, compare superseding information, and test a benign look-alike.\nWhy now: Avoid blaming an account or host from a name match when the authentication and access records say something narrower.\nHandoff: Record the surviving session, denied access, superseding brief, and benign comparator before scoping other hosts.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-27 21:40:28.976801	\N	2026-10-28 15:23:26.042832	2	\N	2	1	2	{}	{}
7	5bf35d94-4940-4b71-b391-52e6817e6401	T08 · Audit document and roster access	Phase 2 — Test identity and access explanations\nSeparate session activity from password authentication, audit access, compare superseding information, and test a benign look-alike.\nWhy now: Avoid blaming an account or host from a name match when the authentication and access records say something narrower.\nHandoff: Record the surviving session, denied access, superseding brief, and benign comparator before scoping other hosts.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-27 21:40:29.126531	\N	2026-10-28 15:33:14.113631	2	\N	2	1	2	{}	{}
11	07d11832-6741-41a6-bed9-e29e9097f678	T11 · Investigate the unresolved host lead	Phase 3 — Define scope and collection limits\nExamine the unresolved host lead, coverage gaps, normalized process and task records, and prepared memory process tree.\nWhy now: Collection gaps and clock corrections can change the conclusion; apply each correction once and keep unresolved systems unresolved.\nHandoff: Carry documented gaps, corrected timestamps, process ancestry, and remaining uncertainty into final correlation.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:28:53.667852	\N	2026-10-28 16:33:47.935669	2	\N	2	1	2	{}	{}
10	45b345ee-6f41-4f73-b5d3-9bafddf1cba5	T09 · Compare superseding movement information	Phase 2 — Test identity and access explanations\nSeparate session activity from password authentication, audit access, compare superseding information, and test a benign look-alike.\nWhy now: Avoid blaming an account or host from a name match when the authentication and access records say something narrower.\nHandoff: Record the surviving session, denied access, superseding brief, and benign comparator before scoping other hosts.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:18:22.970107	\N	2026-10-28 15:35:13.64152	2	\N	2	1	2	{}	{}
5	074a2dad-182f-4418-848d-fd5ea1046db0	T05 · Recover and compare cached content	Phase 1 — Establish the disclosure path\nReconstruct the document request, destination, download, persistence record, and recovered cached brief.\nWhy now: Confirm which movement brief is actually supported before broader identity or intent claims are made.\nHandoff: Carry the request identifiers, destination, file version, and corrected times into the identity review.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-27 21:40:28.786052	\N	2026-10-28 15:24:58.006855	2	\N	2	1	2	{}	{}
8	f7fdd2b0-ddc6-46e0-8b9b-e5d13a1ca8bd	T10 · Test a benign comparator	Phase 2 — Test identity and access explanations\nSeparate session activity from password authentication, audit access, compare superseding information, and test a benign look-alike.\nWhy now: Avoid blaming an account or host from a name match when the authentication and access records say something narrower.\nHandoff: Record the surviving session, denied access, superseding brief, and benign comparator before scoping other hosts.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-27 21:40:29.263561	\N	2026-10-28 15:19:32.548678	2	\N	2	1	2	{}	{}
3	82b754e1-963d-4466-9109-3af06e5e3548	T03 · Reconstruct the viewer download	Phase 1 — Establish the disclosure path\nReconstruct the document request, destination, download, persistence record, and recovered cached brief.\nWhy now: Confirm which movement brief is actually supported before broader identity or intent claims are made.\nHandoff: Carry the request identifiers, destination, file version, and corrected times into the identity review.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-27 21:40:28.491002	\N	2026-10-28 15:12:33.083366	2	\N	2	1	2	{}	{}
1	a25c8efb-1dd4-4bd8-9dae-d545952701b3	T01 · Trace document traffic	Phase 1 — Establish the disclosure path\nReconstruct the document request, destination, download, persistence record, and recovered cached brief.\nWhy now: Confirm which movement brief is actually supported before broader identity or intent claims are made.\nHandoff: Carry the request identifiers, destination, file version, and corrected times into the identity review.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-27 21:40:28.192126	\N	2026-10-28 14:15:57.970887	2	\N	2	1	2	{}	{}
4	7fb9401f-8e0b-4fd3-9d5f-02ba2c6d8c1f	T04 · Investigate persistence	Phase 1 — Establish the disclosure path\nReconstruct the document request, destination, download, persistence record, and recovered cached brief.\nWhy now: Confirm which movement brief is actually supported before broader identity or intent claims are made.\nHandoff: Carry the request identifiers, destination, file version, and corrected times into the identity review.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-27 21:40:28.633308	\N	2026-10-28 15:24:25.178812	2	\N	2	1	2	{}	{}
2	eac5d4b1-0277-4ae2-a410-7eb925db3e42	T02 · Resolve names and compare conversations	Phase 1 — Establish the disclosure path\nReconstruct the document request, destination, download, persistence record, and recovered cached brief.\nWhy now: Confirm which movement brief is actually supported before broader identity or intent claims are made.\nHandoff: Carry the request identifiers, destination, file version, and corrected times into the identity review.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-27 21:40:28.341621	\N	2026-10-28 14:32:49.281532	2	\N	2	1	2	{}	{}
9	7119a944-46db-4884-a7fa-c6aa2eedf8ab	T07 · Test the effect of the password reset	Phase 2 — Test identity and access explanations\nSeparate session activity from password authentication, audit access, compare superseding information, and test a benign look-alike.\nWhy now: Avoid blaming an account or host from a name match when the authentication and access records say something narrower.\nHandoff: Record the surviving session, denied access, superseding brief, and benign comparator before scoping other hosts.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:17:01.129118	\N	2026-10-28 15:29:59.531451	2	\N	2	1	2	{}	{}
13	148bed2e-2e7a-41d5-8841-7afee7ea5a6f	T13 · Inspect acquired process-log records	Phase 3 — Define scope and collection limits\nExamine the unresolved host lead, coverage gaps, normalized process and task records, and prepared memory process tree.\nWhy now: Collection gaps and clock corrections can change the conclusion; apply each correction once and keep unresolved systems unresolved.\nHandoff: Carry documented gaps, corrected timestamps, process ancestry, and remaining uncertainty into final correlation.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:28:53.871582	\N	2026-10-28 16:37:52.957714	2	\N	2	1	2	{}	{}
12	9ecb9340-f1e0-4621-8d3f-a4b3fc406221	T12 · Map collection coverage	Phase 3 — Define scope and collection limits\nExamine the unresolved host lead, coverage gaps, normalized process and task records, and prepared memory process tree.\nWhy now: Collection gaps and clock corrections can change the conclusion; apply each correction once and keep unresolved systems unresolved.\nHandoff: Carry documented gaps, corrected timestamps, process ancestry, and remaining uncertainty into final correlation.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:28:53.774277	\N	2026-10-28 16:12:32.900365	2	\N	2	1	2	{}	{}
14	8f852480-2dbe-42a2-b8fe-29d817c426ed	T14 · Inspect acquired task-log records	Phase 3 — Define scope and collection limits\nExamine the unresolved host lead, coverage gaps, normalized process and task records, and prepared memory process tree.\nWhy now: Collection gaps and clock corrections can change the conclusion; apply each correction once and keep unresolved systems unresolved.\nHandoff: Carry documented gaps, corrected timestamps, process ancestry, and remaining uncertainty into final correlation.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:28:54.002684	\N	2026-10-28 16:17:44.704417	2	\N	2	1	2	{}	{}
18	7100e1a9-3924-4beb-a1bd-333531d4f66c	T18 · Follow a small static code example	Phase 4 — Correlate and state the defensible conclusion\nCorrelate connections, static configuration, a harmless code example, payload metadata, and the limits of the overall exposure conclusion.\nWhy now: A network connection or acknowledgment supports transmission, not human receipt, intent, or complete compromise scope.\nHandoff: Publish the supported disclosure finding, list the denied or unproven claims, and name the collection still required.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:37:50.421964	\N	2026-10-28 17:06:42.801759	2	\N	2	1	2	{}	{}
15	a9acda23-a9c1-4030-a14f-e05f3db98725	T15 · Inspect the prepared memory process tree	Phase 3 — Define scope and collection limits\nExamine the unresolved host lead, coverage gaps, normalized process and task records, and prepared memory process tree.\nWhy now: Collection gaps and clock corrections can change the conclusion; apply each correction once and keep unresolved systems unresolved.\nHandoff: Carry documented gaps, corrected timestamps, process ancestry, and remaining uncertainty into final correlation.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:28:54.150707	\N	2026-10-28 16:21:58.626173	2	\N	2	1	2	{}	{}
20	94cd66ae-a3f6-4c6a-a1b0-c8b64496c5c7	T20 · Test the limits of the overall exposure conclusion	Phase 4 — Correlate and state the defensible conclusion\nCorrelate connections, static configuration, a harmless code example, payload metadata, and the limits of the overall exposure conclusion.\nWhy now: A network connection or acknowledgment supports transmission, not human receipt, intent, or complete compromise scope.\nHandoff: Publish the supported disclosure finding, list the denied or unproven claims, and name the collection still required.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:42:00.494771	\N	2026-10-28 17:05:52.951218	2	\N	2	1	2	{}	{}
17	962c699e-6fcb-42be-ad90-db21f0da7a60	T17 · Inspect the harmless training binary configuration	Phase 4 — Correlate and state the defensible conclusion\nCorrelate connections, static configuration, a harmless code example, payload metadata, and the limits of the overall exposure conclusion.\nWhy now: A network connection or acknowledgment supports transmission, not human receipt, intent, or complete compromise scope.\nHandoff: Publish the supported disclosure finding, list the denied or unproven claims, and name the collection still required.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:37:50.276586	\N	2026-10-28 17:04:06.177981	2	\N	2	1	2	{}	{}
16	f80f5938-27e5-44c3-a2ff-19900e4f9c53	T16 · Correlate the acquired connection snapshot	Phase 4 — Correlate and state the defensible conclusion\nCorrelate connections, static configuration, a harmless code example, payload metadata, and the limits of the overall exposure conclusion.\nWhy now: A network connection or acknowledgment supports transmission, not human receipt, intent, or complete compromise scope.\nHandoff: Publish the supported disclosure finding, list the denied or unproven claims, and name the collection still required.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:37:50.117714	\N	2026-10-28 16:57:45.084384	2	\N	2	1	2	{}	{}
19	89decb32-2187-427b-8ef5-5e2419719bad	T19 · Verify the transmitted payload	Phase 4 — Correlate and state the defensible conclusion\nCorrelate connections, static configuration, a harmless code example, payload metadata, and the limits of the overall exposure conclusion.\nWhy now: A network connection or acknowledgment supports transmission, not human receipt, intent, or complete compromise scope.\nHandoff: Publish the supported disclosure finding, list the denied or unproven claims, and name the collection still required.\nClaim ownership through /silent-ridge. Correct answers publish cited findings automatically.	Silent Ridge	2026-10-28 12:37:50.643295	\N	2026-10-28 16:54:43.489351	2	\N	2	1	2	{}	{}
\.


--
-- Data for Name: case_template; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_template (id, created_by_user_id, created_at, updated_at, name, display_name, description, author, title_prefix, summary, tags, tasks, note_directories, classification) FROM stdin;
\.


--
-- Data for Name: case_template_report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.case_template_report (id, name, description, internal_reference, naming_format, created_by_user_id, date_created, language_id, report_type_id) FROM stdin;
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cases (case_id, soc_id, client_id, name, description, open_date, close_date, initial_date, closing_note, user_id, owner_id, status_id, state_id, custom_attributes, case_uuid, classification_id, reviewer_id, review_status_id, severity_id, modification_history) FROM stdin;
1	soc_id_demo	1	#1 - Initial Demo	This is a demonstration.	2026-10-27	\N	2026-10-27 21:39:39.172336	\N	1	1	0	\N	null	fcc41485-6c89-4292-9452-88297f7ee80a	\N	\N	\N	\N	\N
2	\N	2	Operation Silent Ridge	Cooperative incident-response exercise case. All content fictional.	2026-10-27	\N	2026-10-27 21:39:54.250238	\N	2	2	0	\N	{}	87bfed72-66d8-4ac5-a3b2-62ba20a37ea5	\N	\N	\N	\N	\N
\.


--
-- Data for Name: cases_assets_ext; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cases_assets_ext (asset_id, type_id, case_id, asset_content) FROM stdin;
\.


--
-- Data for Name: cases_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cases_events (event_id, parent_event_id, event_uuid, case_id, event_title, event_source, event_content, event_raw, event_date, event_added, event_in_graph, event_in_summary, user_id, modification_history, event_color, event_tags, event_tz, event_date_wtz, event_is_flagged, custom_attributes) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (client_id, client_uuid, name, description, sla, creation_date, created_by, last_update_date, custom_attributes) FROM stdin;
1	e31f7e89-0947-4777-ba76-cf293b4f0b14	IrisInitialClient	\N	\N	2026-10-27 21:39:39.165312	\N	2026-10-27 21:39:39.165312	\N
2	502bd16b-e06e-4751-bdf1-a14bb5a34677	Operation Silent Ridge	\N	\N	2026-10-27 21:39:54.021163	\N	2026-10-27 21:39:54.021163	\N
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (comment_id, comment_uuid, comment_text, comment_date, comment_update_date, comment_user_id, comment_case_id, comment_alert_id) FROM stdin;
1	333bdd79-b0b4-485a-bd02-69a5543a9ae0	The identity record assigns session S-41 to m.ellis.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:16:28.347221+00:00\nAnswer event: 533d10d6-f443-4f44-ba5c-31153d1d6366	2026-10-28 12:16:29.254441	2026-10-28 12:16:29.254441	2	2	\N
2	201e49f0-3670-4925-9db4-1e213e0ff1ca	The external S-41 refresh is timestamped 09:03:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:16:41.681315+00:00\nAnswer event: ffddfb11-b84f-4794-b8f2-b83d7f128033	2026-10-28 12:16:42.691819	2026-10-28 12:16:42.691819	2	2	\N
3	032f3232-99d3-43c0-9d83-589b75651646	The refresh carries previous_claim, rather than a newly challenged MFA result.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:16:51.676878+00:00\nAnswer event: bf192868-8739-47c8-a09b-5ba0e3216471	2026-10-28 12:16:52.191185	2026-10-28 12:16:52.191185	2	2	\N
4	2822e687-f108-436d-8a68-b162eed7fc5e	The separate password-login attempt at 09:05 failed; it must not be conflated with session refresh success.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:16:59.921445+00:00\nAnswer event: 81c5fbd0-a8fc-4fc5-a5c2-c7e629efbede	2026-10-28 12:17:00.720418	2026-10-28 12:17:00.720418	2	2	\N
5	6b75133d-7fef-4e37-8d63-d62ab4f68f1c	WS-22 has a similarly named approved task; its name alone is not a compromise indicator.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:17:10.663373+00:00\nAnswer event: e181bad1-cef3-41a3-9d9e-cd1a83a67fd2	2026-10-28 12:17:11.818222	2026-10-28 12:17:11.818222	2	2	\N
6	916f9e2e-02b1-47e6-bd0e-c8de3f8a016c	The WS-22 inventory identifies Exercise IT as publisher.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:17:20.419081+00:00\nAnswer event: 43c370f0-e811-49f6-915a-f7ea8a299d70	2026-10-28 12:17:20.576996	2026-10-28 12:17:20.576996	2	2	\N
7	0acad3c7-d950-4d91-ab5c-0d4910ff3939	The approved WS-22 application path is C:/Program Files/Approved/briefsync.exe.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:17:30.511213+00:00\nAnswer event: 63438147-3176-480c-90b7-26affea4ea7d	2026-10-28 12:17:31.439728	2026-10-28 12:17:31.439728	2	2	\N
8	2727b4b9-2fe1-4082-9b63-fa63d5618d7b	The server audit records r.chen as the planner reading v4.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:17:39.148317+00:00\nAnswer event: a15fdb0e-284b-4b25-b0e7-199a61b5fb31	2026-10-28 12:17:39.985372	2026-10-28 12:17:39.985372	2	2	\N
9	4abd659c-ddae-4ab7-8add-4cdacfcb3273	Request req-71 returned plan-v3.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:17:47.804259+00:00\nAnswer event: 9295a1a8-a6a8-49e1-9866-760ed3999a27	2026-10-28 12:17:48.470019	2026-10-28 12:17:48.470019	2	2	\N
10	acda2999-66bd-4d54-8aad-0387b6bfaa45	The roster request returned HTTP 403.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:18:06.103816+00:00\nAnswer event: 28299af5-bcea-4c0e-8b8f-db028d5c173a	2026-10-28 12:18:06.381487	2026-10-28 12:18:06.381487	2	2	\N
11	3267874b-b87c-4484-93f7-bc6b414a322c	The denied roster request returned zero body bytes.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:18:14.464342+00:00\nAnswer event: 6ca6cee4-607f-4394-8fdf-15bdd8746465	2026-10-28 12:18:15.107287	2026-10-28 12:18:15.107287	2	2	\N
12	16169bcc-585f-4742-9dc1-e94fa29ed4c3	WS-17 is the workstation associated with the plan-v3 request.\nEvidence: endpoint/events.csv (account correlated from requester address)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:18:18.743892+00:00\nAnswer event: 55b90e7f-1b75-4594-bb94-16bfe26f135e	2026-10-28 12:18:19.50163	2026-10-28 12:18:19.50163	2	2	\N
13	c7de93e7-36f3-4974-81ed-3917406d822e	Request req-75 identifies the denied roster access, not a successful disclosure.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:18:22.462063+00:00\nAnswer event: 6b93bd4b-69a2-427a-a30a-37a82d396677	2026-10-28 12:18:22.76614	2026-10-28 12:18:22.76614	2	2	\N
14	6c851a0a-338c-4702-b6df-c8823f27a0d5	The registered task is named BriefSync.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:18:31.855775+00:00\nAnswer event: 28c80775-de01-4e25-b622-a853743f5bcb	2026-10-28 12:18:32.438353	2026-10-28 12:18:32.438353	2	2	\N
15	9803adb6-d351-4884-b878-419b9d35efa6	The task-registration record names brief-viewer.exe as the registering process.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:18:42.061038+00:00\nAnswer event: 9e038df3-1201-43cf-9324-95b4eac841c4	2026-10-28 12:18:43.024311	2026-10-28 12:18:43.024311	2	2	\N
16	47fe0b75-b71e-4067-a765-fcadb04b853f	The recorded task trigger is user logon.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:19:24.202828+00:00\nAnswer event: ffa0a3c0-480c-4715-aeb7-3fc6f8788461	2026-10-28 12:19:24.731894	2026-10-28 12:19:24.731894	2	2	\N
17	982aafe3-1273-4c81-889f-6bdc7d5bd97f	After subtracting the documented 120-second device offset, task registration occurred at 09:08:00 UTC.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:19:58.215781+00:00\nAnswer event: f29553b5-a279-425c-8e1c-f82d81c68882	2026-10-28 12:19:58.970354	2026-10-28 12:19:58.970354	2	2	\N
18	5c26448c-4221-449c-9cb2-561374290745	WS-17 is the workstation associated with the plan-v3 request.\nEvidence: endpoint/events.csv (account correlated from requester address)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:21:14.326527+00:00\nAnswer event: 93430919-525f-4ca0-85cd-a6621ba45cbf	2026-10-28 12:21:14.876202	2026-10-28 12:21:14.876202	2	2	\N
21	cecffa8f-437c-45fd-adb4-c977190d569d	The upload record identifies 198.51.100.77 as its external destination.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:21:46.022060+00:00\nAnswer event: 75a6ce55-921e-47d3-b724-bba2f731ba24	2026-10-28 12:21:46.704112	2026-10-28 12:21:46.704112	2	2	\N
25	b2b902cb-6f65-47e6-8d15-128fd0c509f1	The DNS response records a 60-second TTL.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:22:32.799718+00:00\nAnswer event: ca8bc95c-3884-48fa-b711-3fbfb7b48900	2026-10-28 12:22:33.610864	2026-10-28 12:22:33.610864	2	2	\N
28	ed58ddcb-c7d3-4925-b400-a884c1ac53be	The download URL names briefs.helpdesk.example; this does not establish the original delivery mechanism.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:23:04.673452+00:00\nAnswer event: 62a762c0-c8e8-43a1-93b6-50b4696c1e60	2026-10-28 12:23:05.414162	2026-10-28 12:23:05.414162	2	2	\N
34	2b668b5c-72ab-411b-bddb-aa2978f2573d	The supplied identity policy treats explicit session revocation separately from a password reset. No containment change was performed by participants.\nEvidence: identity/policy.txt (issued-session invalidation policy)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:26:59.120660+00:00\nAnswer event: 77d6dfc5-ae76-4b1f-89a9-5cdf378ff85d	2026-10-28 12:26:59.433075	2026-10-28 12:26:59.433075	2	2	\N
35	1cad6f1c-c98e-4f49-b32a-a3eca6f731aa	The recovered cache names fictional patrol LANTERN.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:27:14.535519+00:00\nAnswer event: 474f8ff4-c98a-44da-97ae-019d6a9ff6b1	2026-10-28 12:27:15.211968	2026-10-28 12:27:15.211968	2	2	\N
39	3cb86c4b-fd95-44d7-9699-cf3ea050d731	The supplied version history records v4 superseding v3 at 09:10:00 UTC.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:28:11.637314+00:00\nAnswer event: cb3b4b73-0e33-450d-9ca7-68dbeddefd92	2026-10-28 12:28:12.556186	2026-10-28 12:28:12.556186	2	2	\N
40	fa30bce5-fdf6-4a60-b53a-3a52eadbff28	Version 4 specifies sector BLUE.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:28:23.054356+00:00\nAnswer event: 521588b7-08f9-4cef-958b-5dac1932490a	2026-10-28 12:28:24.059988	2026-10-28 12:28:24.059988	2	2	\N
42	209d79bd-60c1-453a-a0a2-f5992500321d	Version 4 specifies the 10:30–11:30Z movement window.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:28:36.131804+00:00\nAnswer event: e910cf05-d3b2-45c6-bfc3-ef633cb2a9b0	2026-10-28 12:28:36.801385	2026-10-28 12:28:36.801385	2	2	\N
44	2e03cad9-8129-4a97-ba49-77cf4673d956	The plan download is correlated by request identifier req-71.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T12:29:48.888820+00:00\nAnswer event: 4479a22e-08b0-4c74-bc5a-88ea12dacb22	2026-10-28 12:29:49.712559	2026-10-28 12:29:49.712559	2	2	\N
47	f30c74c8-068a-409c-8a24-52a0cb84f363	WS-31 endpoint collection stopped at 08:50:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:33:38.338203+00:00\nAnswer event: 48ae530c-a9d9-431e-a831-b8307b11dbcf	2026-10-28 12:33:39.271361	2026-10-28 12:33:39.271361	2	2	\N
48	d1c7e8d5-0811-4561-b71e-a4829c41d51a	Task inventory alone does not establish execution on WS-31. Further collection would be required.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:33:51.641955+00:00\nAnswer event: 89672e91-c8b2-4a3d-859e-22ee756c32cc	2026-10-28 12:33:51.859696	2026-10-28 12:33:51.859696	2	2	\N
51	f442a7aa-f071-40da-8963-cd896eb01b36	DOCS-1 audit collection resumes at 09:18:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:34:35.761761+00:00\nAnswer event: 64f6b36f-4085-4619-a4d1-98faea1c994b	2026-10-28 12:34:36.622156	2026-10-28 12:34:36.622156	2	2	\N
52	90f9497a-1e8f-4ee7-b08c-4a7036d12c85	The documented WS-17 device offset is 120 seconds fast; normalized records must not receive a second correction.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:34:49.042384+00:00\nAnswer event: 1b0f5726-62ff-4882-bdfd-b46827daa75e	2026-10-28 12:34:50.10452	2026-10-28 12:34:50.10452	2	2	\N
54	437cffa2-4633-4d0d-ade4-908f86040a53	The native process event names browser.exe as the parent training surrogate.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:35:14.933239+00:00\nAnswer event: a1586145-22b9-488c-bf76-c81d1c447bb1	2026-10-28 12:35:15.115172	2026-10-28 12:35:15.115172	2	2	\N
19	f382ddd1-7e8f-4f63-871a-1c79e33a238c	The plan download is correlated by request identifier req-71.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:21:23.855718+00:00\nAnswer event: 35db250f-853d-4e48-a412-cb2d8e055289	2026-10-28 12:21:24.563785	2026-10-28 12:21:24.563785	2	2	\N
22	c29c710a-3c1a-4b90-ad8a-d030114230cc	The DNS record maps relay.archive.example to an address.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:22:00.348543+00:00\nAnswer event: 95517442-3072-4f56-a155-9b6d20d52366	2026-10-28 12:22:00.544086	2026-10-28 12:22:00.544086	2	2	\N
29	015e0222-8535-48c7-90c5-840509ee5d0f	The browser target path places the download in C:/Downloads.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:23:19.034073+00:00\nAnswer event: 883df682-864f-44bb-a728-f029cf258600	2026-10-28 12:23:19.45675	2026-10-28 12:23:19.45675	2	2	\N
31	2fd53d82-f216-44e0-868c-067630250b69	WS-17 is the workstation associated with the plan-v3 request.\nEvidence: endpoint/events.csv (account correlated from requester address)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T12:24:08.489871+00:00\nAnswer event: b2534cd8-6283-47e9-9a7d-f08966ca6169	2026-10-28 12:24:08.975825	2026-10-28 12:24:08.975825	2	2	\N
36	278e7824-5eac-4472-b66b-99f444a73be0	The recovered cache contains movement brief version 3.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:27:33.312739+00:00\nAnswer event: d82dc3d3-84b8-44d2-a600-b3c728b09bf5	2026-10-28 12:27:33.848432	2026-10-28 12:27:33.848432	2	2	\N
37	ade0ee5b-cc26-456e-b3da-886bb7831696	The cached version names sector AMBER.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:27:45.662880+00:00\nAnswer event: a1ee8226-825a-462d-bae2-a1fa3e3e00fb	2026-10-28 12:27:46.33618	2026-10-28 12:27:46.33618	2	2	\N
38	78da06e8-b345-498b-ac6e-d44fb87a3c25	The cached version includes check-in word CEDAR.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:27:59.810389+00:00\nAnswer event: b8ba6244-5b0e-4680-8609-f2de9b640a20	2026-10-28 12:28:00.882631	2026-10-28 12:28:00.882631	2	2	\N
43	2bff07f8-1d35-4309-b6ba-4b8e7e6a3155	CEDAR is unchanged between the supplied v3 and v4 records.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:28:52.299824+00:00\nAnswer event: 4b4e9aa2-8bad-47c2-90e3-c1d35b6ff472	2026-10-28 12:28:53.427892	2026-10-28 12:28:53.427892	2	2	\N
20	9e842577-eb50-46e3-80c5-5ef360658101	Request req-72 identifies the outbound upload.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:21:34.840191+00:00\nAnswer event: d59b5fa4-4fe9-4ea4-b9d3-7158a650ed8e	2026-10-28 12:21:35.120358	2026-10-28 12:21:35.120358	2	2	\N
23	c360d51d-25e9-40d8-812a-bca11da99be1	The DNS answer is 198.51.100.77.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:22:13.191924+00:00\nAnswer event: d8a97405-27ce-4566-8192-5db0c742e58f	2026-10-28 12:22:13.365426	2026-10-28 12:22:13.365426	2	2	\N
26	5abaa2f5-e0dc-4fa5-ad66-d4df7ff54d17	The browser export records the viewer download at 08:57:00 UTC.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:22:43.440215+00:00\nAnswer event: 2163f566-4e3c-44a8-b00a-fea44accc557	2026-10-28 12:22:44.796148	2026-10-28 12:22:44.796148	2	2	\N
53	1f707495-1796-42d4-a373-764a6e8e405e	Native Security record 606 records viewer PID 6364.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:35:01.647924+00:00\nAnswer event: 13df3ccf-31e0-41fa-a692-b37f6a1d71a2	2026-10-28 12:35:02.555386	2026-10-28 12:35:02.555386	2	2	\N
55	4360e0e3-5f53-4ce5-a355-6ce2fe51b077	The plan download is correlated by request identifier req-71.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:35:22.189153+00:00\nAnswer event: c0ce5ad3-1d9b-42ae-86d4-4576d13c3c1a	2026-10-28 12:35:22.556231	2026-10-28 12:35:22.556231	2	2	\N
24	94e62a4e-b6d5-428d-8f9e-296fd9831f0a	The recorded DNS client is WS-17 at 10.26.10.17.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:22:22.429872+00:00\nAnswer event: 5fd5730b-759f-497e-a432-a6bf76fe2cc7	2026-10-28 12:22:22.79877	2026-10-28 12:22:22.79877	2	2	\N
27	6c91a3f4-71ad-483b-b20f-c9bd4258b8d8	The recorded download filename is brief-viewer.exe.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:22:53.367808+00:00\nAnswer event: 682d0725-6304-4c9c-94ed-929320a70906	2026-10-28 12:22:53.681392	2026-10-28 12:22:53.681392	2	2	\N
30	788aae7e-cc25-4b4d-b135-61fe4ce3e440	The password-reset record is timestamped 09:20:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.action:password_reset)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:23:29.325943+00:00\nAnswer event: 43c2c7c7-610a-4369-a5dc-225ac769cb5b	2026-10-28 12:23:30.278857	2026-10-28 12:23:30.278857	2	2	\N
32	b537fd95-f93d-4be2-9200-2a23bdf96139	A later session refresh succeeded at 09:26:00 UTC.\nEvidence: identity/late-auth.csv (action=session_refresh AND result=success)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:24:31.743340+00:00\nAnswer event: 03c079c8-c932-453a-bcf8-d23d7d6dc7ba	2026-10-28 12:24:32.896839	2026-10-28 12:24:32.896839	2	2	\N
33	247a2a66-4421-4586-8840-27e28aed659d	The later successful refresh reused S-41.\nEvidence: wazuh/telemetry.jsonl (data.action:session_refresh)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:24:40.474341+00:00\nAnswer event: e98b59d0-2762-49e6-b4bc-c183a92cac26	2026-10-28 12:24:41.377771	2026-10-28 12:24:41.377771	2	2	\N
41	31bcabb4-1751-492f-b1af-8f5eb5424388	WS-17 is the workstation associated with the plan-v3 request.\nEvidence: endpoint/events.csv (account correlated from requester address)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T12:28:35.499474+00:00\nAnswer event: f02a2aa8-fe82-4885-94d7-00899336b573	2026-10-28 12:28:36.56138	2026-10-28 12:28:36.56138	2	2	\N
45	b9474149-02ab-4001-8ecb-78d050d250c1	WS-31 inventory contains a task named BriefSync, creating an unresolved scope lead.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:31:44.781846+00:00\nAnswer event: 1316037d-3648-4036-93fc-a4a4c526e483	2026-10-28 12:31:44.93869	2026-10-28 12:31:44.93869	2	2	\N
46	acff2fa1-33d2-4781-bf1c-5f57c4697df5	The WS-31 inventory observation is timestamped 08:45:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:32:00.042097+00:00\nAnswer event: 66d34069-b749-4435-be50-cef6ea2798ef	2026-10-28 12:32:00.544241	2026-10-28 12:32:00.544241	2	2	\N
49	37e81222-fae6-4593-8926-6ff89815068a	The coverage record lists no network collection for WS-31.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:34:09.487977+00:00\nAnswer event: 69255792-06b6-42af-aad4-6330a64c86f1	2026-10-28 12:34:10.552367	2026-10-28 12:34:10.552367	2	2	\N
50	6e2cc258-ae1b-4665-961e-9d14c30b8c9c	DOCS-1 audit collection has a gap beginning at 09:14:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:34:22.629759+00:00\nAnswer event: 3ae28fda-d2b5-4416-94fe-dcdf4ec3f606	2026-10-28 12:34:23.006514	2026-10-28 12:34:23.006514	2	2	\N
56	668b61f5-c85b-4a17-99b7-90480478fc02	The acquisition manifest maps this isolated lab reconstruction to WS-17; the original computer name is preserved.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:35:28.277952+00:00\nAnswer event: 0297646d-b3ee-4c68-97f2-d0fac94a23e9	2026-10-28 12:35:28.934634	2026-10-28 12:35:28.934634	2	2	\N
57	0477df88-e7b4-4bf1-87d2-1b5269e6a60e	The reconstructed process was created at 23:22:00 UTC on 2026-09-15; no historic clock correction applies.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:35:41.127786+00:00\nAnswer event: c4f4b06e-884e-4ee6-ba2a-34a9133df561	2026-10-28 12:35:41.453507	2026-10-28 12:35:41.453507	2	2	\N
58	5421b337-068b-4ebd-bc26-a4842ccd198b	Native Security record 607 records the BriefSync task.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:35:54.420113+00:00\nAnswer event: e40779ea-bc2c-4c99-ade7-11dfbf749a8a	2026-10-28 12:35:55.02803	2026-10-28 12:35:55.02803	2	2	\N
59	df144623-b882-4710-a440-1acd47babdd0	The captured task XML targets the harmless brief-viewer.exe training surrogate.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:36:29.834326+00:00\nAnswer event: 40206bf8-09e9-42fe-8e0b-663ef1194685	2026-10-28 12:36:30.02629	2026-10-28 12:36:30.02629	2	2	\N
60	1f90b25e-021a-4285-b9b3-98321a1eb165	Request req-72 identifies the outbound upload.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T12:36:41.342477+00:00\nAnswer event: 282ddbd4-c331-418c-ab9b-4d408cbb081d	2026-10-28 12:36:41.530818	2026-10-28 12:36:41.530818	2	2	\N
61	949faaa2-2747-4c00-b9b4-e3112e0a1701	The reconstructed task was registered at 23:22:01 UTC on 2026-09-15.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:36:43.948701+00:00\nAnswer event: d980dc68-f256-48f7-8e3a-e11be6fb8575	2026-10-28 12:36:44.802785	2026-10-28 12:36:44.802785	2	2	\N
62	b79d98ab-56d2-4eaf-a3e3-f6683f8317b0	Acquisition timestamps describe the lab capture and must not be rewritten as historical incident timestamps.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:36:56.088390+00:00\nAnswer event: a02e3f20-db6a-4369-8797-32fddd347f7b	2026-10-28 12:36:56.330565	2026-10-28 12:36:56.330565	2	2	\N
65	e68186d0-3456-42b8-bddd-dd52d9236961	The recovered parent process name is browser.exe; it is a training surrogate.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:37:34.276297+00:00\nAnswer event: 3baede41-6af0-4c3c-96ed-1aafeaf24290	2026-10-28 12:37:35.34169	2026-10-28 12:37:35.34169	2	2	\N
67	f00d8e7f-3eff-42e1-88a0-487e6f567b96	The guest's native connection snapshot records PID 6364.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:39:19.968999+00:00\nAnswer event: 97c75d41-5609-4aa9-a13f-6bbad41c4ca2	2026-10-28 12:39:20.15681	2026-10-28 12:39:20.15681	2	2	\N
69	0be77582-6255-4dc9-abda-23a772157cc5	The native snapshot records TCP remote port 443.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:39:41.602317+00:00\nAnswer event: 92afd239-cd9c-4762-bb11-a12aa7a7ccf4	2026-10-28 12:39:42.11865	2026-10-28 12:39:42.11865	2	2	\N
72	5db89b55-0078-4065-8654-f595b8494057	The training surrogate contains configuration path /upload.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:40:19.036755+00:00\nAnswer event: e916f246-1810-4b01-8732-be5df3cb6fa0	2026-10-28 12:40:19.871503	2026-10-28 12:40:19.871503	2	2	\N
74	eab4cee4-b67d-4bb3-a0a9-3fbef942503a	The supplied training surrogate performs no network calls; its strings are for static inspection.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:40:41.385304+00:00\nAnswer event: 383f4cab-faef-4c57-805c-07a0515343ee	2026-10-28 12:40:41.833998	2026-10-28 12:40:41.833998	2	2	\N
77	5e9b4262-6b0e-4668-9e08-05c65ef64a33	The other branch returns the text other version.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:41:09.809704+00:00\nAnswer event: c362cb4a-19e5-4ec1-b516-ae57ab5238b9	2026-10-28 12:41:10.179879	2026-10-28 12:41:10.179879	2	2	\N
87	efd7f91b-4dfa-4682-89e8-d948004bad58	The denied roster request does not establish successful roster disclosure.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:43:26.592041+00:00\nAnswer event: b068cac2-70c4-4c8d-84e5-ef1ea11b8726	2026-10-28 12:43:27.67312	2026-10-28 12:43:27.67312	2	2	\N
90	acb7cfc9-0200-49a1-aa49-0e634da95480	FINAL INCIDENT ASSESSMENT — LIMITED DISCLOSURE CONFIRMED. At 09:06 UTC, WS-17 transmitted a payload matching Patrol LANTERN movement brief v3 to 198.51.100.77 in req-72. V4 superseded the route at 09:10 UTC, but CEDAR remained unchanged, leaving an active check-in word exposed. The roster request was denied with HTTP 403 and zero body bytes. Session S-41 survived the password reset, but control of the session and adversary intent are not established. WS-31 remains unresolved because collection ended before execution could be determined. Required actions: rotate CEDAR, revoke S-41, isolate and preserve WS-17, collect WS-31, and monitor or block the external relay indicator.\n\nCompletion event: d80de267-9346-42f3-81c7-7a8805f85c16\nCompleted by: n0_L0g2_N0_Crim3	2026-10-28 12:43:48.880513	2026-10-28 12:43:48.880513	2	2	\N
92	d9a32552-4257-4184-9cbc-f10becb52bbc	The plan download is correlated by request identifier req-71.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T12:46:24.891501+00:00\nAnswer event: 8d39980c-927d-4a4b-a1de-dcc856f81451	2026-10-28 12:46:25.215037	2026-10-28 12:46:25.215037	2	2	\N
94	fa223c57-9875-4f84-9ac0-74c71b5fc244	The DNS answer is 198.51.100.77.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T12:47:06.248902+00:00\nAnswer event: 22631812-8343-4e7f-96c4-fdcdda993118	2026-10-28 12:47:06.570086	2026-10-28 12:47:06.570086	2	2	\N
105	2ab4f067-7250-4007-b86d-b9f6564f7437	The DNS response records a 60-second TTL.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T13:01:48.529745+00:00\nAnswer event: c555c14b-3269-48cc-a6e4-0dde64232ada	2026-10-28 13:01:49.564884	2026-10-28 13:01:49.564884	2	2	\N
63	a4aca328-7d2e-4ea6-a58d-19138835d2cc	Volatility recovered viewer PID 6364 at kernel virtual offset 0xc98352279080.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:37:09.159480+00:00\nAnswer event: 4c851af6-2800-44e3-a823-fa39db47eb4d	2026-10-28 12:37:10.081826	2026-10-28 12:37:10.081826	2	2	\N
76	e877e00f-598c-457d-b6d8-92ce4130290f	The input-3 branch returns the text cached v3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:41:00.643275+00:00\nAnswer event: 66dc4983-eaeb-406a-b0e0-51bc2caa2a60	2026-10-28 12:41:01.80106	2026-10-28 12:41:01.80106	2	2	\N
79	efc4b3df-a127-421b-acf7-03298ef6d893	The DLP metadata links the supplied body to req-72.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:41:30.312067+00:00\nAnswer event: d48a5261-62cb-41c0-ae35-46a4c2ea0f41	2026-10-28 12:41:31.074006	2026-10-28 12:41:31.074006	2	2	\N
81	c7cbb8ff-8aa3-4413-81ff-d927a2ba15ca	The DLP upload timestamp is 09:06:00 UTC.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:41:50.556082+00:00\nAnswer event: 48b728ff-dfdb-4b49-988f-0c16d8e53dcc	2026-10-28 12:41:50.962774	2026-10-28 12:41:50.962774	2	2	\N
83	79c19fd2-5335-4317-85c1-b11e41950abf	Request req-72 identifies the outbound upload.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:42:08.171034+00:00\nAnswer event: 2d1489ea-605b-42c7-8795-30b0bff070a6	2026-10-28 12:42:08.842979	2026-10-28 12:42:08.842979	2	2	\N
85	ccbefd6b-1ebd-43c8-9c7a-2f5c53b446c2	The upload record identifies 198.51.100.77 as its external destination.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T12:42:43.640925+00:00\nAnswer event: 33b7a059-7c7c-4156-9748-fca344fbbd8b	2026-10-28 12:42:44.193819	2026-10-28 12:42:44.193819	2	2	\N
93	ef13abf5-766a-47ba-acf8-2e1d3ac3260b	The DNS record maps relay.archive.example to an address.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T12:46:57.350584+00:00\nAnswer event: cd194113-dde3-43c6-affb-beead6901e15	2026-10-28 12:46:58.167467	2026-10-28 12:46:58.167467	2	2	\N
97	29573fb0-8d08-4631-8d28-992a02ca28dd	The upload record identifies 198.51.100.77 as its external destination.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:50:40.501945+00:00\nAnswer event: 819d2668-64d7-478d-815d-f9429f7b3531	2026-10-28 12:50:41.405067	2026-10-28 12:50:41.405067	2	2	\N
98	8c7b3f53-f055-474b-bc18-6f3dc4d2e8a9	The DNS record maps relay.archive.example to an address.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T12:52:31.214909+00:00\nAnswer event: c36086dc-060d-46f9-9264-19920a264dea	2026-10-28 12:52:31.412549	2026-10-28 12:52:31.412549	2	2	\N
106	e5c3247f-159e-445b-be55-7b88a175dc04	The download URL names briefs.helpdesk.example; this does not establish the original delivery mechanism.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:02:04.142304+00:00\nAnswer event: 31474734-cee4-4a91-a6c8-d6b043a77995	2026-10-28 13:02:05.125493	2026-10-28 13:02:05.125493	2	2	\N
64	f968cc03-8527-426c-b2c9-f5064d790e8e	The recovered viewer process records parent PID 7644.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:37:22.073362+00:00\nAnswer event: f09fce7c-c1fa-4a00-94c2-f178c7c8d28d	2026-10-28 12:37:22.65874	2026-10-28 12:37:22.65874	2	2	\N
66	9a2918bf-5fa7-48e6-a363-470d71f7d098	The memory-derived command line contains cache argument C:/Temp/move-cache.txt.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:37:48.827711+00:00\nAnswer event: fef236f1-3ea7-4df4-a03b-ce1fab149e71	2026-10-28 12:37:50.008941	2026-10-28 12:37:50.008941	2	2	\N
71	fc1c34e3-3ab9-4767-ad66-f437a35355bc	The training surrogate contains destination string 198.51.100.77.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:40:09.669481+00:00\nAnswer event: ed1b3928-d3ad-4a78-b1ba-3ea9049d4d41	2026-10-28 12:40:10.292369	2026-10-28 12:40:10.292369	2	2	\N
82	e5e6200f-8644-4522-b5b8-e93d74599473	An HTTP acknowledgment does not prove a human read the transmitted body.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:42:00.125206+00:00\nAnswer event: 8f3787f9-b610-44cf-90b8-898dd53d62c5	2026-10-28 12:42:00.379853	2026-10-28 12:42:00.379853	2	2	\N
84	d5557e5c-01d3-4618-9688-0192745fd76f	Request req-72 identifies the outbound upload.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T12:42:18.997633+00:00\nAnswer event: d298c221-9b6f-47af-882a-e68068789b68	2026-10-28 12:42:19.436335	2026-10-28 12:42:19.436335	2	2	\N
86	b6719283-4c0d-4afb-8f2f-d8fdf64045e0	The matched payload supports transmission of movement brief v3.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:43:08.988999+00:00\nAnswer event: d870a382-e378-45e0-b91a-f1d3ab09dda3	2026-10-28 12:43:09.927907	2026-10-28 12:43:09.927907	2	2	\N
88	79e8f56a-5595-4418-aa07-27b7a18bab0d	The available inventory and collection gaps cannot clear WS-31.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:43:36.733688+00:00\nAnswer event: da9f274b-bfd1-429d-9ec3-173381b326fc	2026-10-28 12:43:37.212926	2026-10-28 12:43:37.212926	2	2	\N
89	27a86683-0f1f-4707-a8be-f431afd93746	The supplied evidence does not establish adversary intent.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:43:48.012635+00:00\nAnswer event: d80de267-9346-42f3-81c7-7a8805f85c16	2026-10-28 12:43:48.732701	2026-10-28 12:43:48.732701	2	2	\N
95	df1d6929-41ff-48ee-9855-b240098c4287	The DNS record maps relay.archive.example to an address.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:48:04.183514+00:00\nAnswer event: 2840f77a-d862-4b74-bab3-d7629e44699d	2026-10-28 12:48:05.21312	2026-10-28 12:48:05.21312	2	2	\N
99	6d0b997d-b2ce-455d-81bc-2b2fe8370c3c	The DNS answer is 198.51.100.77.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:54:20.661107+00:00\nAnswer event: 9067fab6-1533-4ffc-8854-11e3863ae11c	2026-10-28 12:54:20.905142	2026-10-28 12:54:20.905142	2	2	\N
101	088e8c22-30f4-449b-93e2-8d7135bf127a	The recorded DNS client is WS-17 at 10.26.10.17.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:55:05.140258+00:00\nAnswer event: 653a4a51-4c17-426f-a34a-f1c2aee16401	2026-10-28 12:55:06.281743	2026-10-28 12:55:06.281743	2	2	\N
103	e0296046-b988-435c-8056-09b91b4690df	The browser export records the viewer download at 08:57:00 UTC.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:58:16.382661+00:00\nAnswer event: f93be7a5-9cdf-4fa3-97ec-6d02aab08db7	2026-10-28 12:58:16.52859	2026-10-28 12:58:16.52859	2	2	\N
104	0b29ba5f-ad28-4015-a4fc-958f512338f5	The recorded download filename is brief-viewer.exe.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:00:02.618024+00:00\nAnswer event: 0b7b7cf0-c731-4a61-9a21-99f4aa3c41af	2026-10-28 13:00:02.989518	2026-10-28 13:00:02.989518	2	2	\N
107	a7370c94-1201-41b5-a0b9-45111b308905	The recorded DNS client is WS-17 at 10.26.10.17.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T13:02:30.852002+00:00\nAnswer event: 9a073119-101f-4f31-bc89-375ce3730038	2026-10-28 13:02:31.991654	2026-10-28 13:02:31.991654	2	2	\N
68	1894f3d7-23a6-4262-9cbe-ea5f3d9247e8	198.51.100.77 was a guest-local loopback address in this reconstruction; no Internet traffic occurred.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:39:31.211621+00:00\nAnswer event: 39b45621-c300-4f2b-9850-5b7e92db32df	2026-10-28 12:39:31.638511	2026-10-28 12:39:31.638511	2	2	\N
70	a93594dc-13ec-4717-a99f-55329dd7db13	This is a live acquisition sidecar, not a validated memory connection finding or evidence of human reading.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:39:53.723711+00:00\nAnswer event: 4b66089f-928c-4b2c-b03c-d2c7eeb0fb45	2026-10-28 12:39:54.648244	2026-10-28 12:39:54.648244	2	2	\N
73	7fe0e772-d413-43ff-960f-501e612a6755	The training surrogate contains task-label string BriefSync.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q3\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:40:32.157123+00:00\nAnswer event: cd6c119d-e037-4f2b-890c-0d88e02728b9	2026-10-28 12:40:32.439357	2026-10-28 12:40:32.439357	2	2	\N
75	3258bdfa-8dea-4c19-b856-245e3283453f	The classify_version example compares its input with integer 3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q1\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:40:51.057093+00:00\nAnswer event: 3202a50b-55d1-49ee-af5d-324b42cdd638	2026-10-28 12:40:51.367839	2026-10-28 12:40:51.367839	2	2	\N
78	88274432-8aef-4067-a6dc-d3bd41c3d978	The existence of a static branch does not establish that it executed during the incident.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q4\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:41:20.457361+00:00\nAnswer event: 7c74cedb-03f8-4271-839f-800a3c6503ba	2026-10-28 12:41:20.667498	2026-10-28 12:41:20.667498	2	2	\N
80	446a9162-8667-4a94-9cb3-06c6986e1464	The body hash comparison matches movement brief v3.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q2\nSolved by: n0_L0g2_N0_Crim3\nUTC: 2026-10-28T12:41:39.715824+00:00\nAnswer event: b38b5360-03e8-4c1e-b1ac-8cb41d228684	2026-10-28 12:41:40.516512	2026-10-28 12:41:40.516512	2	2	\N
91	926d4600-4f69-4d64-868f-5256cac58e68	The upload record identifies 198.51.100.77 as its external destination.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T12:43:48.352218+00:00\nAnswer event: b7e9f891-544e-44af-934c-24ee4016d574	2026-10-28 12:43:49.088325	2026-10-28 12:43:49.088325	2	2	\N
96	c3fdd877-d563-455a-afa9-45a8d959fab2	The DNS answer is 198.51.100.77.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T12:48:46.247404+00:00\nAnswer event: ebe5e305-6f25-46f8-8ab0-6bccf40c8676	2026-10-28 12:48:47.38546	2026-10-28 12:48:47.38546	2	2	\N
100	0305d9d9-aaba-4eb0-a3b3-fe66fb8db772	The recorded DNS client is WS-17 at 10.26.10.17.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T12:54:43.969689+00:00\nAnswer event: 3801a954-096a-4657-9dbf-0fdde524411a	2026-10-28 12:54:44.618338	2026-10-28 12:54:44.618338	2	2	\N
102	d57ae8ae-252c-4c25-8ac8-79ca7070a5dc	The DNS response records a 60-second TTL.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T12:55:46.853036+00:00\nAnswer event: 2164ec9c-25a4-4550-a53b-e363e551aa9f	2026-10-28 12:55:47.439657	2026-10-28 12:55:47.439657	2	2	\N
108	817cc9e9-49ad-443d-bce7-e4f67b78032a	The browser target path places the download in C:/Downloads.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:02:40.876167+00:00\nAnswer event: a8f3c88f-7db1-48b0-b7fe-faca3b20a9e1	2026-10-28 13:02:41.488793	2026-10-28 13:02:41.488793	2	2	\N
109	d5c66384-4d1e-41c6-b772-01573731a1e1	The DNS response records a 60-second TTL.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T13:04:35.299450+00:00\nAnswer event: 39449789-c9d7-4319-9521-9f4d9f86ca31	2026-10-28 13:04:35.739286	2026-10-28 13:04:35.739286	2	2	\N
110	9f8adc85-b060-478a-8260-436944af642a	WS-17 is the workstation associated with the plan-v3 request.\nEvidence: endpoint/events.csv (account correlated from requester address)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:05:53.583070+00:00\nAnswer event: 6ca92d3d-2488-4cbd-ab88-8fe7ba323fac	2026-10-28 13:05:54.140897	2026-10-28 13:05:54.140897	2	2	\N
111	8ac6e0cd-ad14-402b-adf9-2b3f75f8f75c	The plan download is correlated by request identifier req-71.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:11:56.817971+00:00\nAnswer event: 6e552c37-d7d6-4068-8f5c-07322eb7d817	2026-10-28 13:11:57.574874	2026-10-28 13:11:57.574874	2	2	\N
112	c794e534-6593-416f-b4b0-c28964539435	The DNS record maps relay.archive.example to an address.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:21:51.378594+00:00\nAnswer event: 6529c2c0-959b-41e7-944d-c01f5d796292	2026-10-28 13:21:52.177478	2026-10-28 13:21:52.177478	2	2	\N
113	def98e17-6ebc-44ec-b961-bbb3041f1135	The DNS answer is 198.51.100.77.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:24:18.586098+00:00\nAnswer event: 538d8917-ab21-4f2f-a759-523d52a87fe7	2026-10-28 13:24:19.565532	2026-10-28 13:24:19.565532	2	2	\N
114	147726fe-ea6b-4d59-bdc5-dc04d174f843	The browser export records the viewer download at 08:57:00 UTC.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T13:25:22.574823+00:00\nAnswer event: 6af05e20-7155-42e4-9bea-763912150d1d	2026-10-28 13:25:23.408272	2026-10-28 13:25:23.408272	2	2	\N
115	b28ae6f3-261d-4eb1-94fc-91031abfa8f7	The recorded download filename is brief-viewer.exe.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T13:26:08.399295+00:00\nAnswer event: 6ce411ed-8990-4280-8404-45689fb0f6f9	2026-10-28 13:26:08.807462	2026-10-28 13:26:08.807462	2	2	\N
119	899bfbd5-eb81-4cea-8bc3-5bf2244f764e	Request req-72 identifies the outbound upload.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q3\nSolved by: BOO\nUTC: 2026-10-28T13:32:08.210503+00:00\nAnswer event: 47835746-ae03-4d62-a884-a111ef7a407a	2026-10-28 13:32:08.455579	2026-10-28 13:32:08.455579	2	2	\N
122	5f9c4c46-31ac-4a56-92e6-b5b27e012a7d	The external S-41 refresh is timestamped 09:03:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T13:34:37.735827+00:00\nAnswer event: 2d45bd3a-691c-4e73-a099-6afca7cb0aac	2026-10-28 13:34:38.636389	2026-10-28 13:34:38.636389	2	2	\N
129	88d171ff-99bb-4452-a129-351e1076a45b	The DNS response records a 60-second TTL.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:39:50.807825+00:00\nAnswer event: cc881095-0fb7-455f-a2cc-336fbd93b0de	2026-10-28 13:39:51.692692	2026-10-28 13:39:51.692692	2	2	\N
132	ebc31d8b-55ab-4ff3-8941-a29db5ab0141	The recorded DNS client is WS-17 at 10.26.10.17.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q3\nSolved by: BOO\nUTC: 2026-10-28T13:41:45.189620+00:00\nAnswer event: 7af954e3-13b0-4b51-aa49-ede8ada6b156	2026-10-28 13:41:46.282264	2026-10-28 13:41:46.282264	2	2	\N
134	398fdfa5-364a-4a47-81ea-cd21fca69ca3	The task-registration record names brief-viewer.exe as the registering process.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:45:50.609109+00:00\nAnswer event: 277d163e-7792-4eb3-8e1a-444c62bc5b7f	2026-10-28 13:45:50.886277	2026-10-28 13:45:50.886277	2	2	\N
136	da354125-cb61-48f8-b540-6d774708f599	The approved WS-22 application path is C:/Program Files/Approved/briefsync.exe.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T13:49:03.339966+00:00\nAnswer event: a95177a0-ec28-44f6-b610-6c04410569c6	2026-10-28 13:49:04.238496	2026-10-28 13:49:04.238496	2	2	\N
140	396ab148-74b1-46ab-92ac-84cc0ccec964	The task-registration record names brief-viewer.exe as the registering process.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:50:51.500531+00:00\nAnswer event: bf716871-5e3e-4fd2-8baa-95adaf18b913	2026-10-28 13:50:52.696916	2026-10-28 13:50:52.696916	2	2	\N
146	b8118adf-d423-4552-bd3f-c67a98b12176	The recovered cache names fictional patrol LANTERN.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:54:00.023604+00:00\nAnswer event: 5a362aa4-bc3d-48dd-a632-ff30bece08ba	2026-10-28 13:54:00.335838	2026-10-28 13:54:00.335838	2	2	\N
148	842841bd-22c6-4d1d-904c-b65e4938314b	The recovered cache contains movement brief version 3.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:54:48.426385+00:00\nAnswer event: 8283ce27-3160-40f0-a00f-7349f6d7e978	2026-10-28 13:54:49.105926	2026-10-28 13:54:49.105926	2	2	\N
151	71b95561-f4e4-412d-83a1-07d991ab944c	The cached version includes check-in word CEDAR.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:55:14.251081+00:00\nAnswer event: 58448d21-0021-40a2-b626-dbbf4a4483f7	2026-10-28 13:55:14.573249	2026-10-28 13:55:14.573249	2	2	\N
154	2c01211d-e374-403a-bbf3-81122073445e	WS-17 is the workstation associated with the plan-v3 request.\nEvidence: endpoint/events.csv (account correlated from requester address)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T14:00:41.381651+00:00\nAnswer event: 8852eab3-5464-4152-ab43-ab1f957b1373	2026-10-28 14:00:41.663514	2026-10-28 14:00:41.663514	2	2	\N
157	1d4724da-233c-4020-a4bf-1a7fcfec8ea0	The password-reset record is timestamped 09:20:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.action:password_reset)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T14:02:08.876952+00:00\nAnswer event: 3a55ca5d-20a1-4114-8dfe-1b9bbd2951f5	2026-10-28 14:02:09.226415	2026-10-28 14:02:09.226415	2	2	\N
161	dd0fbab6-957b-483d-b9d8-da1ad2b4c8e6	The registered task is named BriefSync.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T14:04:34.683722+00:00\nAnswer event: 6b7e94ac-7010-4a89-aee8-dba859551749	2026-10-28 14:04:34.914216	2026-10-28 14:04:34.914216	2	2	\N
163	c088f0a3-1c8b-4940-893c-a848dc93301b	The recovered cache contains movement brief version 3.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:05:06.689415+00:00\nAnswer event: 1e6b4f81-b65e-4337-ad3e-953eb5dbbe84	2026-10-28 14:05:07.34479	2026-10-28 14:05:07.34479	2	2	\N
166	b88bacd3-cbac-4e58-8354-9054c880ede6	The cached version includes check-in word CEDAR.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:05:40.047749+00:00\nAnswer event: 49ac612d-3f1a-4db5-b208-a29a2d1b4513	2026-10-28 14:05:41.272443	2026-10-28 14:05:41.272443	2	2	\N
171	dfc986da-5af7-4de2-b211-f5d264f93629	The separate password-login attempt at 09:05 failed; it must not be conflated with session refresh success.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:08:15.378516+00:00\nAnswer event: 69d7096d-6e18-4f21-b65d-d64cc3056656	2026-10-28 14:08:15.55021	2026-10-28 14:08:15.55021	2	2	\N
116	b24ccef9-c593-4256-8e5c-e0ec5f579920	WS-17 is the workstation associated with the plan-v3 request.\nEvidence: endpoint/events.csv (account correlated from requester address)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q1\nSolved by: BOO\nUTC: 2026-10-28T13:28:23.026284+00:00\nAnswer event: 16a7529c-34f7-4b2d-b7a4-906344b217eb	2026-10-28 13:28:23.423942	2026-10-28 13:28:23.423942	2	2	\N
117	f9eb3086-013d-49ac-ba19-66bc4f072e26	The plan download is correlated by request identifier req-71.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q2\nSolved by: BOO\nUTC: 2026-10-28T13:31:46.965789+00:00\nAnswer event: 3c2d8799-5062-4e3b-966d-f483162da93a	2026-10-28 13:31:47.427763	2026-10-28 13:31:47.427763	2	2	\N
121	ba541afa-ef11-4bef-85f9-24ac9a059087	The upload record identifies 198.51.100.77 as its external destination.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q4\nSolved by: BOO\nUTC: 2026-10-28T13:33:24.429830+00:00\nAnswer event: 9ddccbbf-8229-4013-9d6f-8aef8a447a29	2026-10-28 13:33:24.726719	2026-10-28 13:33:24.726719	2	2	\N
124	55cb501d-8d1f-4ef2-b543-ea65895af72b	The registered task is named BriefSync.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:37:41.478585+00:00\nAnswer event: d723cad5-3f73-4d53-a6dd-4e71832df359	2026-10-28 13:37:42.197955	2026-10-28 13:37:42.197955	2	2	\N
127	488a9de7-d5c2-42b0-bb38-5cc8f5a091e2	The DNS record maps relay.archive.example to an address.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q1\nSolved by: BOO\nUTC: 2026-10-28T13:38:59.889096+00:00\nAnswer event: 7b0e759d-421f-4110-a609-528803367788	2026-10-28 13:39:00.853599	2026-10-28 13:39:00.853599	2	2	\N
133	12261889-387c-4c17-a517-bb50457f9033	The DNS response records a 60-second TTL.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q4\nSolved by: BOO\nUTC: 2026-10-28T13:42:05.045796+00:00\nAnswer event: 65adc50f-4b19-42ff-aee3-5c765c2fc925	2026-10-28 13:42:05.914031	2026-10-28 13:42:05.914031	2	2	\N
138	6f5afbe0-720b-4251-8ec2-0708064a85fd	The registered task is named BriefSync.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:50:09.278927+00:00\nAnswer event: 1de8f1ed-2808-4ef9-89ca-6be26e294078	2026-10-28 13:50:10.198523	2026-10-28 13:50:10.198523	2	2	\N
144	4da71037-c8b4-433d-9f7c-65749f48562d	WS-22 has a similarly named approved task; its name alone is not a compromise indicator.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T13:53:18.960267+00:00\nAnswer event: 104e2d90-05a7-4815-a678-c6922e85d162	2026-10-28 13:53:19.853481	2026-10-28 13:53:19.853481	2	2	\N
147	53be5cf0-e5b3-4d95-8bc4-488c718ec802	The download URL names briefs.helpdesk.example; this does not establish the original delivery mechanism.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T13:54:00.780785+00:00\nAnswer event: 81456cdf-c57d-4ae0-b5b1-e2b18d58077f	2026-10-28 13:54:01.593504	2026-10-28 13:54:01.593504	2	2	\N
149	bc00cf1c-8600-4575-b3d2-3362f8e2ac90	The browser target path places the download in C:/Downloads.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:55:01.513714+00:00\nAnswer event: 372f3304-7778-4907-849e-353c26a8c3f4	2026-10-28 13:55:01.79574	2026-10-28 13:55:01.79574	2	2	\N
155	cfdf4050-c296-49a1-a4e8-1103757fef86	The download URL names briefs.helpdesk.example; this does not establish the original delivery mechanism.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T14:01:24.470772+00:00\nAnswer event: cd165223-c037-4602-b3f9-0b1fd881a7dd	2026-10-28 14:01:24.706985	2026-10-28 14:01:24.706985	2	2	\N
164	1945c11f-3a8e-40e5-bf3a-e20ff92be97f	The later successful refresh reused S-41.\nEvidence: wazuh/telemetry.jsonl (data.action:session_refresh)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T14:05:09.531397+00:00\nAnswer event: c5eaacde-3720-455a-bfa7-c57fbbe2dc99	2026-10-28 14:05:09.86734	2026-10-28 14:05:09.86734	2	2	\N
167	7e3836aa-888d-4fc0-a8c3-66f1d89927f8	The external S-41 refresh is timestamped 09:03:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:05:53.242177+00:00\nAnswer event: fdb0aed4-8d8d-481e-89c7-670fe78085c8	2026-10-28 14:05:53.731668	2026-10-28 14:05:53.731668	2	2	\N
169	ca03bdc7-e555-4e2a-a53f-17054b163356	The refresh carries previous_claim, rather than a newly challenged MFA result.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:07:00.357547+00:00\nAnswer event: 05150a21-774a-454f-8486-3356ccaa7e17	2026-10-28 14:07:01.498869	2026-10-28 14:07:01.498869	2	2	\N
118	e740fdfe-9c8d-4002-8640-8e9503458c52	The recorded DNS client is WS-17 at 10.26.10.17.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:31:59.737998+00:00\nAnswer event: 8dd67a7d-fc6c-43b0-bbe3-2540b0520f68	2026-10-28 13:31:59.965562	2026-10-28 13:31:59.965562	2	2	\N
120	adfd5569-a1ae-499e-a08f-13065e32dc4b	The identity record assigns session S-41 to m.ellis.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T13:32:18.471582+00:00\nAnswer event: 649201d5-d422-4a65-af5c-74e73d8ade25	2026-10-28 13:32:18.994812	2026-10-28 13:32:18.994812	2	2	\N
123	c166ed11-3e95-49ac-965e-766565cf9132	The refresh carries previous_claim, rather than a newly challenged MFA result.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T13:36:18.413513+00:00\nAnswer event: 3db50541-c8f9-4840-a34a-669b133b91b5	2026-10-28 13:36:19.015418	2026-10-28 13:36:19.015418	2	2	\N
125	0bf62b84-e65f-482a-b10e-fe8c5de517ae	Request req-72 identifies the outbound upload.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:37:42.229740+00:00\nAnswer event: 9144b82a-2d84-4cbd-b963-6bc3c684e24a	2026-10-28 13:37:42.46754	2026-10-28 13:37:42.46754	2	2	\N
126	c5d29afc-f5ad-46f6-8e72-3fc04f5d92ca	The upload record identifies 198.51.100.77 as its external destination.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:38:16.055594+00:00\nAnswer event: bc3dff24-0ff7-4d6a-9548-971f7fdabbb9	2026-10-28 13:38:16.625744	2026-10-28 13:38:16.625744	2	2	\N
128	174ac909-0f8a-4400-9eac-039b596aae64	The separate password-login attempt at 09:05 failed; it must not be conflated with session refresh success.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T13:39:08.275711+00:00\nAnswer event: e9f724ae-6ae4-4f72-bd56-a29cbeaa62f7	2026-10-28 13:39:09.249032	2026-10-28 13:39:09.249032	2	2	\N
130	324a55e9-0084-4438-89aa-3532856ac651	The DNS answer is 198.51.100.77.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q2\nSolved by: BOO\nUTC: 2026-10-28T13:40:14.293995+00:00\nAnswer event: a9916532-8398-4829-b3ce-235a7dd9ae76	2026-10-28 13:40:14.495186	2026-10-28 13:40:14.495186	2	2	\N
131	15a72f48-8d3d-4c90-b076-f4cf71cb04f7	The browser target path places the download in C:/Downloads.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T13:40:47.942030+00:00\nAnswer event: a7507305-ab1a-4019-9644-8fcb19691ef2	2026-10-28 13:40:48.517693	2026-10-28 13:40:48.517693	2	2	\N
135	48fb5453-0691-4ac6-acbe-ab07ce147af3	The recorded task trigger is user logon.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:46:35.054963+00:00\nAnswer event: dbf76bbf-31cc-43a3-a233-992955258a4d	2026-10-28 13:46:36.062525	2026-10-28 13:46:36.062525	2	2	\N
137	369cc677-68f2-4bf0-9d16-55e35e8f24d1	After subtracting the documented 120-second device offset, task registration occurred at 09:08:00 UTC.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:49:34.066222+00:00\nAnswer event: f497dab5-7461-46d0-998f-e126009c02bf	2026-10-28 13:49:35.213235	2026-10-28 13:49:35.213235	2	2	\N
139	e624810a-94cb-47d8-9a4b-464d9ddfc482	The browser export records the viewer download at 08:57:00 UTC.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:50:12.277286+00:00\nAnswer event: 8a54aba8-059b-4497-a94d-bb9c4364781c	2026-10-28 13:50:12.501084	2026-10-28 13:50:12.501084	2	2	\N
141	64e1c908-9e60-402b-8474-fca4d8768677	The recorded download filename is brief-viewer.exe.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:51:10.291659+00:00\nAnswer event: 1f375816-ce2a-40d1-ad82-4c16aa1b6fca	2026-10-28 13:51:11.349372	2026-10-28 13:51:11.349372	2	2	\N
142	a641e020-b128-4feb-9b22-ef1139939f71	The browser export records the viewer download at 08:57:00 UTC.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T13:51:10.369935+00:00\nAnswer event: a80d62a3-5606-45b0-b211-3083d067f951	2026-10-28 13:51:11.590307	2026-10-28 13:51:11.590307	2	2	\N
143	2dcd5513-efe8-4d57-9e9f-52382894bc29	The recorded download filename is brief-viewer.exe.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T13:52:48.649776+00:00\nAnswer event: 5577893e-aba7-45dc-9d8a-36328ecf6552	2026-10-28 13:52:48.961353	2026-10-28 13:52:48.961353	2	2	\N
145	cac0f3e9-89aa-417a-8f12-1b5d95520e8f	The recorded task trigger is user logon.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T13:53:24.600114+00:00\nAnswer event: aaff7d9c-2c62-4173-b0c2-e5aed5bda097	2026-10-28 13:53:25.250058	2026-10-28 13:53:25.250058	2	2	\N
150	cb4a307e-e6a1-423f-b4c6-6f8338f13249	The cached version names sector AMBER.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T13:55:03.513123+00:00\nAnswer event: 4279880b-c0ac-43aa-875d-4c04a3dbe5df	2026-10-28 13:55:04.073124	2026-10-28 13:55:04.073124	2	2	\N
152	0fe9942a-094c-400d-a334-0264b89453ca	The browser target path places the download in C:/Downloads.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T13:55:38.174861+00:00\nAnswer event: ecc7486f-f79c-403d-bcf4-4d9d51889a82	2026-10-28 13:55:38.451401	2026-10-28 13:55:38.451401	2	2	\N
153	2a9c48e4-35ab-4cf4-93fb-8ed7a95a627d	The WS-22 inventory identifies Exercise IT as publisher.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T13:59:12.083077+00:00\nAnswer event: 416c2a5f-b8cb-4c79-aa75-a2899f963645	2026-10-28 13:59:13.077948	2026-10-28 13:59:13.077948	2	2	\N
158	88c33466-54b6-471c-bb53-1740d94e6678	The identity record assigns session S-41 to m.ellis.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:03:16.318541+00:00\nAnswer event: f7596c0a-e909-401a-85e5-70befb11dab8	2026-10-28 14:03:17.188767	2026-10-28 14:03:17.188767	2	2	\N
160	d63303f0-d80c-45b4-bbc4-a66eee6c4dfc	The plan download is correlated by request identifier req-71.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T14:04:19.630824+00:00\nAnswer event: 142c394a-a14e-4340-819d-1bff621ca086	2026-10-28 14:04:20.302068	2026-10-28 14:04:20.302068	2	2	\N
168	dd82b7a0-fd6d-4f2c-bdba-f426371146c0	Request req-72 identifies the outbound upload.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T14:06:20.885929+00:00\nAnswer event: c994cb60-8746-4232-9240-f7ac5d0a5f36	2026-10-28 14:06:21.437925	2026-10-28 14:06:21.437925	2	2	\N
170	18756903-a2f8-479a-a2c0-1a3439bce4a8	The server audit records r.chen as the planner reading v4.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T14:07:19.365704+00:00\nAnswer event: c2de8242-40d4-4875-9a93-6330dc3209a5	2026-10-28 14:07:20.11877	2026-10-28 14:07:20.11877	2	2	\N
156	505ab2cb-baae-4f75-aeb9-1e81e06cb1a1	After subtracting the documented 120-second device offset, task registration occurred at 09:08:00 UTC.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:01:55.053347+00:00\nAnswer event: 54d3cd31-2b3b-4c96-884a-813ca9343700	2026-10-28 14:01:55.711381	2026-10-28 14:01:55.711381	2	2	\N
159	f04cb931-60cb-4fe6-97ca-63ed5090090f	A later session refresh succeeded at 09:26:00 UTC.\nEvidence: identity/late-auth.csv (action=session_refresh AND result=success)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T14:04:16.475096+00:00\nAnswer event: 3bdccf48-a3b9-4ee1-8847-168a6b9fbcfe	2026-10-28 14:04:17.004889	2026-10-28 14:04:17.004889	2	2	\N
162	16478cd2-12a1-4783-82c1-e623be5c3bb4	The recovered cache names fictional patrol LANTERN.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:04:42.843624+00:00\nAnswer event: f0a3f654-73ed-4689-a4d6-c1d37f46e1e8	2026-10-28 14:04:43.419159	2026-10-28 14:04:43.419159	2	2	\N
165	d764c1df-0f28-4de4-81cb-f07add591669	The cached version names sector AMBER.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:05:26.278117+00:00\nAnswer event: bf56aa80-498a-42a2-bf18-3d63deacde02	2026-10-28 14:05:26.513241	2026-10-28 14:05:26.513241	2	2	\N
172	66bded42-80e6-4001-a903-ccc7ba0eb399	The identity record assigns session S-41 to m.ellis.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:09:15.975934+00:00\nAnswer event: a41998cd-412b-4d4d-8e9f-6410d305d0ea	2026-10-28 14:09:17.103545	2026-10-28 14:09:17.103545	2	2	\N
173	f66c90d0-ce89-4a36-9dc0-af23e9fe2e3d	The task-registration record names brief-viewer.exe as the registering process.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T14:10:41.386657+00:00\nAnswer event: cba511ec-99bf-4b83-9b23-723b2a8f6e31	2026-10-28 14:10:42.01038	2026-10-28 14:10:42.01038	2	2	\N
174	f3d32b90-fdd8-43bf-923b-b4484e0baf53	The supplied identity policy treats explicit session revocation separately from a password reset. No containment change was performed by participants.\nEvidence: identity/policy.txt (issued-session invalidation policy)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T14:11:52.400078+00:00\nAnswer event: a3fed4df-e64d-4215-b464-de0af0687b18	2026-10-28 14:11:52.634015	2026-10-28 14:11:52.634015	2	2	\N
175	5594cdb5-e983-49f7-8f92-4b49fb1b8e1e	The identity record assigns session S-41 to m.ellis.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q1\nSolved by: BOO\nUTC: 2026-10-28T14:12:27.153963+00:00\nAnswer event: bcc740f9-1601-4f71-9a07-c84fdc79b881	2026-10-28 14:12:27.50925	2026-10-28 14:12:27.50925	2	2	\N
176	efc50a1b-eb85-430a-af88-90e4177a29a9	The registered task is named BriefSync.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T14:13:30.032440+00:00\nAnswer event: 1796ca25-3fc0-4754-aea4-d2b152647588	2026-10-28 14:13:30.917625	2026-10-28 14:13:30.917625	2	2	\N
177	51ca86d8-440c-4494-81c5-dd6d756ffe7c	The server audit records r.chen as the planner reading v4.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q4\nSolved by: BOO\nUTC: 2026-10-28T14:13:50.915983+00:00\nAnswer event: 84670b38-19ae-4cd9-8fa9-4469d2d930e8	2026-10-28 14:13:51.49127	2026-10-28 14:13:51.49127	2	2	\N
178	0c8df46e-92a4-419a-9973-edac71a8e84b	The task-registration record names brief-viewer.exe as the registering process.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T14:14:43.299261+00:00\nAnswer event: 423467a5-9c80-48e6-804b-dbd78d506146	2026-10-28 14:14:43.850172	2026-10-28 14:14:43.850172	2	2	\N
179	5e709dc3-cbb7-44b3-a25b-bf3998f7d23c	The recorded task trigger is user logon.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T14:15:33.170980+00:00\nAnswer event: 183ba1a7-2846-43e3-8e9f-018094973da3	2026-10-28 14:15:34.127816	2026-10-28 14:15:34.127816	2	2	\N
180	6864eede-333d-42de-a992-3f1c3f0dfd8c	The upload record identifies 198.51.100.77 as its external destination.\nEvidence: network/sensor.pcap (udp.dstport == 514)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T01-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T14:15:57.032898+00:00\nAnswer event: f07cc93d-b66c-4d1d-b2fa-d99be1b2c4ea	2026-10-28 14:15:57.970887	2026-10-28 14:15:57.970887	2	2	\N
181	9a677730-2b9e-41be-aee3-3011239b69dc	The password-reset record is timestamped 09:20:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.action:password_reset)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:16:07.740593+00:00\nAnswer event: b938a8bf-65a5-4921-9654-5f3f5284b3a3	2026-10-28 14:16:08.388289	2026-10-28 14:16:08.388289	2	2	\N
182	34813ec3-57f0-41aa-ad45-9f7cad133d8d	WS-22 has a similarly named approved task; its name alone is not a compromise indicator.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q1\nSolved by: BOO\nUTC: 2026-10-28T14:18:20.035662+00:00\nAnswer event: 94b622b6-b570-4deb-b2ed-23ce07d69579	2026-10-28 14:18:20.355398	2026-10-28 14:18:20.355398	2	2	\N
183	f07f9a78-21c0-4cd5-a529-f11091f65ee7	The approved WS-22 application path is C:/Program Files/Approved/briefsync.exe.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q3\nSolved by: BOO\nUTC: 2026-10-28T14:19:01.102238+00:00\nAnswer event: cb6e5a0a-ecbf-4e61-80a7-236e32b62cbb	2026-10-28 14:19:01.465821	2026-10-28 14:19:01.465821	2	2	\N
184	3fe17f96-1ff3-47d1-b7ce-88758f927048	The recorded task trigger is user logon.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T14:19:01.179347+00:00\nAnswer event: 23ea4da0-5213-4e5a-ab29-473ad969ae53	2026-10-28 14:19:01.670978	2026-10-28 14:19:01.670978	2	2	\N
185	bd68387d-0be8-4511-a1ee-fb49ef25d34b	The WS-22 inventory identifies Exercise IT as publisher.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q2\nSolved by: BOO\nUTC: 2026-10-28T14:19:27.495860+00:00\nAnswer event: f9a346e3-18d3-4ca4-be42-e3e1192c9222	2026-10-28 14:19:28.57808	2026-10-28 14:19:28.57808	2	2	\N
187	25895c6a-ef43-427f-990e-ff3deccd7214	A later session refresh succeeded at 09:26:00 UTC.\nEvidence: identity/late-auth.csv (action=session_refresh AND result=success)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:20:19.202135+00:00\nAnswer event: 347e8062-eef2-4fcb-94c7-04c43db08044	2026-10-28 14:20:19.444336	2026-10-28 14:20:19.444336	2	2	\N
189	78ed2451-3411-4497-a5d8-69a2d1129061	The later successful refresh reused S-41.\nEvidence: wazuh/telemetry.jsonl (data.action:session_refresh)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:21:15.628530+00:00\nAnswer event: 413042c3-b30e-448d-b634-6f29437f2619	2026-10-28 14:21:16.134592	2026-10-28 14:21:16.134592	2	2	\N
191	88af1424-1456-4484-bf8f-85f03b3965c9	The recovered cache contains movement brief version 3.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T14:22:08.058819+00:00\nAnswer event: bf9fc798-a892-4965-a5ed-31c070ae6902	2026-10-28 14:22:09.02312	2026-10-28 14:22:09.02312	2	2	\N
197	5bc71ac2-9c41-431a-8434-a73688f5ed90	The download URL names briefs.helpdesk.example; this does not establish the original delivery mechanism.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:23:05.991747+00:00\nAnswer event: 5e8e20d1-7e98-4b9d-80d9-602b71b3e150	2026-10-28 14:23:06.771913	2026-10-28 14:23:06.771913	2	2	\N
200	3688184d-732b-465d-a9da-89ce587c3686	CEDAR is unchanged between the supplied v3 and v4 records.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q4\nSolved by: BOO\nUTC: 2026-10-28T14:24:00.167529+00:00\nAnswer event: 64e42dc1-e017-4c27-b0f0-beca435ae1eb	2026-10-28 14:24:00.51218	2026-10-28 14:24:00.51218	2	2	\N
203	59eb1f47-b5aa-4d87-9de1-7d9223693b0d	The DNS record maps relay.archive.example to an address.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T14:24:22.073737+00:00\nAnswer event: 0d80b8ec-ee84-43d8-9666-0fd2d90e03ad	2026-10-28 14:24:22.581328	2026-10-28 14:24:22.581328	2	2	\N
206	fa96b87e-6683-4999-b9fc-e6d57cf128a6	The supplied identity policy treats explicit session revocation separately from a password reset. No containment change was performed by participants.\nEvidence: identity/policy.txt (issued-session invalidation policy)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:24:58.072604+00:00\nAnswer event: 07d03e9c-63cd-4120-879c-4d6cec6a8384	2026-10-28 14:24:59.135242	2026-10-28 14:24:59.135242	2	2	\N
210	7da83a1c-7bb7-4d21-9e4e-3ac636f03c97	The external S-41 refresh is timestamped 09:03:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:26:53.055934+00:00\nAnswer event: c4076db1-faa5-423d-a989-fa0db57b5a64	2026-10-28 14:26:53.535676	2026-10-28 14:26:53.535676	2	2	\N
213	ce857e5b-5932-4703-9317-0d5687c5dd29	The DNS answer is 198.51.100.77.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T14:29:07.793814+00:00\nAnswer event: fabd886b-e590-48f9-b2d8-bb68e5795fdc	2026-10-28 14:29:08.288481	2026-10-28 14:29:08.288481	2	2	\N
218	ef79e524-fd86-4743-b038-cc4e34e0a258	The DNS response records a 60-second TTL.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T14:32:48.556325+00:00\nAnswer event: f3251922-3201-4b56-9491-e18abf305175	2026-10-28 14:32:49.281532	2026-10-28 14:32:49.281532	2	2	\N
221	2619e20b-675d-49c3-8281-b7fb63ed957c	Request req-71 returned plan-v3.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:33:15.854811+00:00\nAnswer event: 68aba61e-8050-484f-a70d-ee9a43071c82	2026-10-28 14:33:16.695532	2026-10-28 14:33:16.695532	2	2	\N
224	a994299c-7838-435a-a653-d8c1777d8afc	The later successful refresh reused S-41.\nEvidence: wazuh/telemetry.jsonl (data.action:session_refresh)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:33:59.085082+00:00\nAnswer event: c8ffa0cd-f5a7-4468-92c2-b27649196246	2026-10-28 14:33:59.342868	2026-10-28 14:33:59.342868	2	2	\N
226	82aabcb0-021f-447d-9a54-c0e467b84dcb	The browser export records the viewer download at 08:57:00 UTC.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q1\nSolved by: BOO\nUTC: 2026-10-28T14:34:52.264222+00:00\nAnswer event: 384285bd-8ee6-4e39-bccf-f482e045fc63	2026-10-28 14:34:53.138857	2026-10-28 14:34:53.138857	2	2	\N
230	67a9d77f-4747-4274-b73a-41f42c5397b2	The cached version names sector AMBER.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T14:36:06.777711+00:00\nAnswer event: 8294d4c2-1ebf-4d58-949d-e40a13bc7e67	2026-10-28 14:36:06.946139	2026-10-28 14:36:06.946139	2	2	\N
237	e9c45237-f5da-45fd-9d3f-625ba6ab5424	The roster request returned HTTP 403.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:38:02.046196+00:00\nAnswer event: 52012c68-6f3c-45da-964c-af4a65bbc83e	2026-10-28 14:38:03.050718	2026-10-28 14:38:03.050718	2	2	\N
240	aa1a591c-1c88-4f65-a4fc-5179c385d7d8	The denied roster request returned zero body bytes.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:39:02.063823+00:00\nAnswer event: 7e2dcc1d-178d-42ed-89de-2780294740a0	2026-10-28 14:39:03.139322	2026-10-28 14:39:03.139322	2	2	\N
186	083adbd4-3e48-4806-a427-9d63072924c7	After subtracting the documented 120-second device offset, task registration occurred at 09:08:00 UTC.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T14:20:14.552727+00:00\nAnswer event: 0acdb658-7664-4178-80df-081e3386c7df	2026-10-28 14:20:15.148618	2026-10-28 14:20:15.148618	2	2	\N
194	bd9d6767-34f2-4ca8-ad89-0cba33ca1198	The cached version includes check-in word CEDAR.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T14:22:27.492716+00:00\nAnswer event: e77d46eb-7c21-43a5-9fb2-54313f8b83ca	2026-10-28 14:22:28.237486	2026-10-28 14:22:28.237486	2	2	\N
199	db969ad4-4daf-4282-9d1c-b0be3132b5f9	The external S-41 refresh is timestamped 09:03:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T14:23:40.181028+00:00\nAnswer event: 1fbf7643-8525-45b1-9a42-c2b6d394da96	2026-10-28 14:23:40.84269	2026-10-28 14:23:40.84269	2	2	\N
202	4985c9e5-d81d-4a48-9732-bb0048f413ac	The separate password-login attempt at 09:05 failed; it must not be conflated with session refresh success.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T14:24:16.615652+00:00\nAnswer event: 4c4a8d02-1483-4e28-9584-1e1bd61e9f33	2026-10-28 14:24:17.271292	2026-10-28 14:24:17.271292	2	2	\N
205	6b6f32c3-e6a4-4391-91d0-2cbe9f648ee2	Version 4 specifies the 10:30–11:30Z movement window.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q3\nSolved by: BOO\nUTC: 2026-10-28T14:24:50.419402+00:00\nAnswer event: c007149e-d4f5-4e43-ada6-14856f9c4709	2026-10-28 14:24:50.581775	2026-10-28 14:24:50.581775	2	2	\N
208	eacb330d-41bc-456a-8de6-1f37d2b3d229	The supplied version history records v4 superseding v3 at 09:10:00 UTC.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q1\nSolved by: BOO\nUTC: 2026-10-28T14:25:28.757371+00:00\nAnswer event: 29190aa3-4c90-4d1f-b638-ea1649b46f00	2026-10-28 14:25:29.189054	2026-10-28 14:25:29.189054	2	2	\N
211	2f66737f-c12f-4305-b950-79e609d8e5a6	The refresh carries previous_claim, rather than a newly challenged MFA result.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:27:56.608638+00:00\nAnswer event: 42fe5c17-83ff-4363-ad77-02280169b127	2026-10-28 14:27:57.175718	2026-10-28 14:27:57.175718	2	2	\N
215	33e92c8b-3333-406f-9792-3ef2586e17f3	The recorded DNS client is WS-17 at 10.26.10.17.\nEvidence: network/dns.pcap (dns)\nLimitation: Replayed or reconstructed evidence; transmission metadata does not establish human receipt, reading, or intent.\nQuestion: T02-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T14:29:57.506959+00:00\nAnswer event: 4314a644-cbbf-4592-ae47-7be00727363f	2026-10-28 14:29:57.976144	2026-10-28 14:29:57.976144	2	2	\N
216	d643a3ce-093a-4f3e-8be4-77e7dce3d656	Request req-71 returned plan-v3.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T14:31:23.984599+00:00\nAnswer event: 1aecf7fe-9c02-475d-8348-71073aa1d871	2026-10-28 14:31:25.056586	2026-10-28 14:31:25.056586	2	2	\N
220	5fb876a1-26a2-4b12-87b6-b903abc3b5f5	The refresh carries previous_claim, rather than a newly challenged MFA result.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q3\nSolved by: BOO\nUTC: 2026-10-28T14:33:07.310740+00:00\nAnswer event: 7554dd8a-cf82-4573-b20e-2319fb279ee1	2026-10-28 14:33:08.268101	2026-10-28 14:33:08.268101	2	2	\N
223	230cd94a-0837-4569-8969-e0695a2eb4bd	The external S-41 refresh is timestamped 09:03:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q2\nSolved by: BOO\nUTC: 2026-10-28T14:33:40.954426+00:00\nAnswer event: a5066d4d-9309-404f-b68a-174840521c70	2026-10-28 14:33:41.74586	2026-10-28 14:33:41.74586	2	2	\N
231	79aee160-d229-411a-9361-8ddd33f4ae7d	The browser target path places the download in C:/Downloads.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q4\nSolved by: BOO\nUTC: 2026-10-28T14:36:15.383994+00:00\nAnswer event: 185e4d26-cc48-402d-966e-d6e352604933	2026-10-28 14:36:16.409073	2026-10-28 14:36:16.409073	2	2	\N
233	8c76ce11-cdb2-4f2e-b2cf-acca3c81d821	The denied roster request returned zero body bytes.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T14:36:44.020628+00:00\nAnswer event: 506b68ce-c795-4106-bd88-640ec1407b7b	2026-10-28 14:36:44.405767	2026-10-28 14:36:44.405767	2	2	\N
236	603f14c3-6d4c-4663-bb1d-6ffea90a6ad2	The cached version includes check-in word CEDAR.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T14:37:29.461329+00:00\nAnswer event: 9ee71118-8db7-45f1-9281-6ec084a38e3a	2026-10-28 14:37:30.116513	2026-10-28 14:37:30.116513	2	2	\N
243	376d5a55-0ac9-40a2-9cab-e8ef3ab4c2dd	The password-reset record is timestamped 09:20:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.action:password_reset)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q1\nSolved by: BOO\nUTC: 2026-10-28T14:39:37.701384+00:00\nAnswer event: 2f88eb57-0de2-4cd1-b20c-30d39902ed47	2026-10-28 14:39:38.693843	2026-10-28 14:39:38.693843	2	2	\N
188	3d32835f-d374-4fec-9bec-57e04971149a	Request req-75 identifies the denied roster access, not a successful disclosure.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q4\nSolved by: BOO\nUTC: 2026-10-28T14:20:42.215233+00:00\nAnswer event: fdb13663-b333-4b98-8679-3080d81c14ee	2026-10-28 14:20:43.154574	2026-10-28 14:20:43.154574	2	2	\N
190	6471ede2-3843-460b-a08f-72f5fcdd0a83	The recovered cache names fictional patrol LANTERN.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T14:21:56.757076+00:00\nAnswer event: cbcafef8-f358-47e0-bd7b-30ebb030ad97	2026-10-28 14:21:57.494946	2026-10-28 14:21:57.494946	2	2	\N
193	f0c365b1-112b-42f6-bc67-e4059f9e2faf	The cached version names sector AMBER.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T14:22:17.350991+00:00\nAnswer event: af10dd18-ecce-48ed-a882-a7e07cefe9fe	2026-10-28 14:22:17.657629	2026-10-28 14:22:17.657629	2	2	\N
196	df6249fc-6598-4088-994d-fe5e066a83f6	The roster request returned HTTP 403.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q2\nSolved by: BOO\nUTC: 2026-10-28T14:22:53.275561+00:00\nAnswer event: 2622056b-729c-4704-9251-82ee2183faa7	2026-10-28 14:22:54.228386	2026-10-28 14:22:54.228386	2	2	\N
201	42a2892c-71c7-43ef-b7c6-c79e5e387e55	The refresh carries previous_claim, rather than a newly challenged MFA result.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T14:24:05.086173+00:00\nAnswer event: f4f0c2a7-9c26-4bd4-b6b1-302f0240baf9	2026-10-28 14:24:05.835851	2026-10-28 14:24:05.835851	2	2	\N
204	236ff77b-8713-4888-a45d-a04bf216e82f	The password-reset record is timestamped 09:20:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.action:password_reset)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T14:24:46.216529+00:00\nAnswer event: 12c41106-1718-4728-bdb3-4b5e4fc79ddb	2026-10-28 14:24:47.292443	2026-10-28 14:24:47.292443	2	2	\N
207	5cdb8b4e-1f27-4e39-b830-4bd26dc29bf3	Version 4 specifies sector BLUE.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q2\nSolved by: BOO\nUTC: 2026-10-28T14:25:09.581542+00:00\nAnswer event: 95b88618-3049-4c76-bbfb-2d4b63705476	2026-10-28 14:25:10.599263	2026-10-28 14:25:10.599263	2	2	\N
209	899888ba-4faf-4425-bb92-295276218b89	The separate password-login attempt at 09:05 failed; it must not be conflated with session refresh success.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q4\nSolved by: BOO\nUTC: 2026-10-28T14:26:21.737815+00:00\nAnswer event: b3d80741-d204-49b3-a48f-4bb27d64375a	2026-10-28 14:26:22.544765	2026-10-28 14:26:22.544765	2	2	\N
214	eb11faed-03a6-47a6-ba33-67733d9efe6f	The separate password-login attempt at 09:05 failed; it must not be conflated with session refresh success.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:29:55.074785+00:00\nAnswer event: a69a43bc-d282-4ef7-9ec3-4055a111c8ba	2026-10-28 14:29:55.72061	2026-10-28 14:29:55.72061	2	2	\N
217	b6dcd6a6-ee2c-43c1-8ed2-f84da556122b	The password-reset record is timestamped 09:20:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.action:password_reset)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:32:05.794123+00:00\nAnswer event: b4f26208-3bf3-49f6-8f67-24211223dd52	2026-10-28 14:32:06.18844	2026-10-28 14:32:06.18844	2	2	\N
225	6b4eb125-0913-45b7-bcaf-0c593aa8284d	Request req-71 returned plan-v3.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:34:30.860089+00:00\nAnswer event: 043ed295-3cbf-427f-9fbe-b46405226d62	2026-10-28 14:34:31.358706	2026-10-28 14:34:31.358706	2	2	\N
227	b2a1f37b-9c8a-4777-851f-3d00a4ae676c	The recorded download filename is brief-viewer.exe.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q2\nSolved by: BOO\nUTC: 2026-10-28T14:35:10.081939+00:00\nAnswer event: 979f5554-05eb-41d3-b16f-edd2e20fbb0d	2026-10-28 14:35:10.837743	2026-10-28 14:35:10.837743	2	2	\N
235	b4fbd4eb-1a9a-4eb3-b68f-3b5748396810	The registered task is named BriefSync.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q1\nSolved by: BOO\nUTC: 2026-10-28T14:37:24.094961+00:00\nAnswer event: 78940dd3-01cb-4d06-8246-eba9be3e062b	2026-10-28 14:37:24.780226	2026-10-28 14:37:24.780226	2	2	\N
238	b13e6ca5-1216-414b-8a2c-1d07f39b3bd4	The task-registration record names brief-viewer.exe as the registering process.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q2\nSolved by: BOO\nUTC: 2026-10-28T14:38:06.284846+00:00\nAnswer event: b039ee75-a861-4344-ad41-b77c0bd2a78e	2026-10-28 14:38:07.344253	2026-10-28 14:38:07.344253	2	2	\N
242	49ee8e04-8cd9-49aa-b0a6-3766aec74237	Request req-75 identifies the denied roster access, not a successful disclosure.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:39:25.754856+00:00\nAnswer event: 11d343ca-01b9-4ab8-8ea1-35278f6e8aaa	2026-10-28 14:39:26.163823	2026-10-28 14:39:26.163823	2	2	\N
192	d559c13f-116e-46e7-9c97-01a24a14fac5	The denied roster request returned zero body bytes.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q3\nSolved by: BOO\nUTC: 2026-10-28T14:22:10.342243+00:00\nAnswer event: 53038c8a-c111-421a-b2d1-3769b0dc87df	2026-10-28 14:22:11.304117	2026-10-28 14:22:11.304117	2	2	\N
195	0331ce40-84d2-47cc-b755-9077af460841	The identity record assigns session S-41 to m.ellis.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T14:22:46.445766+00:00\nAnswer event: 0acace20-ae97-47e6-a119-d1dc40c99a82	2026-10-28 14:22:46.860126	2026-10-28 14:22:46.860126	2	2	\N
198	7fddf9cf-53cd-4e76-aed0-f686adf24a41	Request req-71 returned plan-v3.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q1\nSolved by: BOO\nUTC: 2026-10-28T14:23:25.108025+00:00\nAnswer event: 79896809-21f8-45fa-96f7-7109fa792baf	2026-10-28 14:23:25.348922	2026-10-28 14:23:25.348922	2	2	\N
212	36b701ba-e201-4a60-8c87-64199242e0b6	The later successful refresh reused S-41.\nEvidence: wazuh/telemetry.jsonl (data.action:session_refresh)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T14:28:30.785641+00:00\nAnswer event: 924125ae-e924-4d16-9f22-83e8acfc58d8	2026-10-28 14:28:31.187004	2026-10-28 14:28:31.187004	2	2	\N
219	c7d8cbda-8bc7-4096-b595-2124074ebb2a	A later session refresh succeeded at 09:26:00 UTC.\nEvidence: identity/late-auth.csv (action=session_refresh AND result=success)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:32:59.219404+00:00\nAnswer event: cf8a94f1-f546-4c5d-987a-f43acec53fd7	2026-10-28 14:32:59.81576	2026-10-28 14:32:59.81576	2	2	\N
222	0ae83e65-1b74-4894-8b57-39f95bc72dbb	The recovered cache names fictional patrol LANTERN.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T14:33:22.940577+00:00\nAnswer event: 4d48e2b6-6a34-453a-84f5-73b024887f8e	2026-10-28 14:33:23.083028	2026-10-28 14:33:23.083028	2	2	\N
228	d8173cf9-f437-4727-acc5-c32b373f32c8	The recovered cache contains movement brief version 3.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T14:35:22.349557+00:00\nAnswer event: f07c4a83-24be-491a-91cc-b8532b5b2c9d	2026-10-28 14:35:23.410028	2026-10-28 14:35:23.410028	2	2	\N
229	b58d3681-e604-4109-9484-78f01832fa47	The download URL names briefs.helpdesk.example; this does not establish the original delivery mechanism.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q3\nSolved by: BOO\nUTC: 2026-10-28T14:35:55.123112+00:00\nAnswer event: a859c3b3-fc85-49cb-9eac-71cafb4df7f1	2026-10-28 14:35:55.437034	2026-10-28 14:35:55.437034	2	2	\N
232	61deaa1a-e41d-4dc8-a01f-5af42abffbf1	The roster request returned HTTP 403.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T14:36:18.512279+00:00\nAnswer event: 7a3a6ffd-c4c7-4137-a40c-e19de618a2b2	2026-10-28 14:36:18.679034	2026-10-28 14:36:18.679034	2	2	\N
234	974535ba-c5d7-4fdc-9244-604e91c1eb42	Request req-75 identifies the denied roster access, not a successful disclosure.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T14:37:11.271494+00:00\nAnswer event: bba96550-c662-4954-8cf4-1ab43410990b	2026-10-28 14:37:12.198295	2026-10-28 14:37:12.198295	2	2	\N
239	623f057b-d9d6-4915-84c7-bf7ca1999c2c	The recorded task trigger is user logon.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q3\nSolved by: BOO\nUTC: 2026-10-28T14:38:56.587317+00:00\nAnswer event: d56a0d87-da8a-4828-a5e7-cf48d3198ca5	2026-10-28 14:38:56.761977	2026-10-28 14:38:56.761977	2	2	\N
241	65d483ec-cb07-4606-b6c8-3a7f6c455fb5	The supplied version history records v4 superseding v3 at 09:10:00 UTC.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T14:39:20.096955+00:00\nAnswer event: 2b74cd97-2998-4008-a334-dadef59c8941	2026-10-28 14:39:20.838347	2026-10-28 14:39:20.838347	2	2	\N
244	db493c90-4243-4258-b91b-b5d4f4190d2c	Version 4 specifies sector BLUE.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T14:39:55.944033+00:00\nAnswer event: 1ba20cbf-57ee-42f0-a01d-9ad989818c1d	2026-10-28 14:39:56.323463	2026-10-28 14:39:56.323463	2	2	\N
245	dff5279b-9a5a-4017-ac1c-d9e789d1a874	The roster request returned HTTP 403.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:40:17.166783+00:00\nAnswer event: d871e96c-0deb-4c91-b766-d8cb57df21da	2026-10-28 14:40:18.147309	2026-10-28 14:40:18.147309	2	2	\N
246	ec927939-7016-47f8-a010-66081a670f57	Version 4 specifies the 10:30–11:30Z movement window.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T14:40:32.768966+00:00\nAnswer event: 0ebb59b5-079e-42e7-a420-3647a0ef570b	2026-10-28 14:40:33.734532	2026-10-28 14:40:33.734532	2	2	\N
247	ccb423bb-fcad-4e98-8e98-db478b9b0665	CEDAR is unchanged between the supplied v3 and v4 records.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T14:40:41.647611+00:00\nAnswer event: 0f796b53-6607-4e49-b141-bf074265257d	2026-10-28 14:40:42.242218	2026-10-28 14:40:42.242218	2	2	\N
248	c3961362-5720-47ac-816a-5d2cb6293ba1	The denied roster request returned zero body bytes.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:42:09.324416+00:00\nAnswer event: 352dfb6f-85a8-4101-a411-f392195ee36b	2026-10-28 14:42:09.724789	2026-10-28 14:42:09.724789	2	2	\N
249	9b7c8740-3106-4019-b573-fd489546390a	Request req-75 identifies the denied roster access, not a successful disclosure.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:42:53.669665+00:00\nAnswer event: 59c3fc7a-6b2e-4087-93d6-b463d8ff734a	2026-10-28 14:42:54.067332	2026-10-28 14:42:54.067332	2	2	\N
250	452a605d-497a-4d8d-a806-4d7b97a5a96a	The supplied version history records v4 superseding v3 at 09:10:00 UTC.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:43:15.035668+00:00\nAnswer event: 8f763ffb-e5fc-47bc-b818-c646c97ee544	2026-10-28 14:43:15.976094	2026-10-28 14:43:15.976094	2	2	\N
251	acdecb4b-9271-4ac8-80bf-1abd46eb6632	Version 4 specifies sector BLUE.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:43:45.717820+00:00\nAnswer event: a963ffd4-e500-4004-a063-c2f54b33c71a	2026-10-28 14:43:46.038604	2026-10-28 14:43:46.038604	2	2	\N
252	42cd737c-5cd6-4db7-b09b-fae599c940f7	Version 4 specifies the 10:30–11:30Z movement window.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:44:48.448108+00:00\nAnswer event: 19d7c0f0-4782-46c6-b243-60504d166839	2026-10-28 14:44:48.668625	2026-10-28 14:44:48.668625	2	2	\N
253	9b7cf8ac-b388-4bf7-81c7-ce3c30fa7e4a	CEDAR is unchanged between the supplied v3 and v4 records.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:45:00.311862+00:00\nAnswer event: 2b048a27-5829-4705-bbf8-610efe2667e1	2026-10-28 14:45:01.236187	2026-10-28 14:45:01.236187	2	2	\N
254	b3ab4d3d-5b5f-4c95-8dcb-5a3383041ff8	A later session refresh succeeded at 09:26:00 UTC.\nEvidence: identity/late-auth.csv (action=session_refresh AND result=success)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q2\nSolved by: BOO\nUTC: 2026-10-28T14:46:04.908237+00:00\nAnswer event: 54a89377-a9a0-4c87-a82a-cfd9d11cb4b8	2026-10-28 14:46:06.050885	2026-10-28 14:46:06.050885	2	2	\N
255	94028658-871e-45bd-9465-6fde2879962d	WS-22 has a similarly named approved task; its name alone is not a compromise indicator.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:47:51.481250+00:00\nAnswer event: bb94e87d-02a1-4db0-b87c-d9e20818f714	2026-10-28 14:47:52.09894	2026-10-28 14:47:52.09894	2	2	\N
256	e140db69-1762-4441-bc16-81d1db9f0293	After subtracting the documented 120-second device offset, task registration occurred at 09:08:00 UTC.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q4\nSolved by: BOO\nUTC: 2026-10-28T14:48:41.992470+00:00\nAnswer event: 258c5a8b-9177-444c-9db5-8eb565567e1e	2026-10-28 14:48:43.069999	2026-10-28 14:48:43.069999	2	2	\N
257	4dc49f3e-3de0-4c59-99ef-490c77f5065e	The WS-22 inventory identifies Exercise IT as publisher.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:48:44.603899+00:00\nAnswer event: 34419ef6-22a1-4107-8efd-15fa11c8e42a	2026-10-28 14:48:45.43672	2026-10-28 14:48:45.43672	2	2	\N
258	be931e3a-9b49-41f3-95d0-619a1f7533cf	The approved WS-22 application path is C:/Program Files/Approved/briefsync.exe.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:49:19.917821+00:00\nAnswer event: 755ac40a-d079-426b-a3b2-2a8ddcb1d9d9	2026-10-28 14:49:20.73662	2026-10-28 14:49:20.73662	2	2	\N
259	db295868-ead4-49a1-815e-15f2cb641687	The server audit records r.chen as the planner reading v4.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:50:13.259974+00:00\nAnswer event: 9107ff40-5ed7-4409-b0af-3868ef7fd2f6	2026-10-28 14:50:13.602866	2026-10-28 14:50:13.602866	2	2	\N
260	24e92c74-ac0b-4a08-bbb6-5d3af2fd6138	The recovered cache names fictional patrol LANTERN.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q1\nSolved by: BOO\nUTC: 2026-10-28T14:51:55.643306+00:00\nAnswer event: 94d6bdd2-f5c4-49d2-84ae-e54e3b4f79be	2026-10-28 14:51:56.79933	2026-10-28 14:51:56.79933	2	2	\N
263	ca3f1259-8f07-4eab-ae0a-928b48f94236	The cached version names sector AMBER.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q3\nSolved by: BOO\nUTC: 2026-10-28T14:52:21.292855+00:00\nAnswer event: 229a09a0-563e-40be-9c53-a88bfd8ff3e2	2026-10-28 14:52:22.365623	2026-10-28 14:52:22.365623	2	2	\N
267	2234a9be-a8ad-4310-ad74-4397cbc7f769	The supplied version history records v4 superseding v3 at 09:10:00 UTC.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:54:15.169133+00:00\nAnswer event: e835fe79-3c1d-4cd7-8c4c-88eff65b34da	2026-10-28 14:54:16.119748	2026-10-28 14:54:16.119748	2	2	\N
275	99bf6729-0ca9-4f22-9150-6ab75b506a46	WS-31 endpoint collection stopped at 08:50:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:57:38.870762+00:00\nAnswer event: 0a65c2a2-48dc-46c1-9dcb-c336d0fa2685	2026-10-28 14:57:39.860246	2026-10-28 14:57:39.860246	2	2	\N
276	c221f0d0-5195-4600-afe8-1f72f5568785	Task inventory alone does not establish execution on WS-31. Further collection would be required.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:58:27.530370+00:00\nAnswer event: 88010160-2c7d-4e93-98bd-e21bd548ce8e	2026-10-28 14:58:28.076726	2026-10-28 14:58:28.076726	2	2	\N
290	a07b3680-c368-4931-89c7-8b36d3ba1f4d	The approved WS-22 application path is C:/Program Files/Approved/briefsync.exe.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T15:08:50.511544+00:00\nAnswer event: 8b81e8e1-ef2e-4f17-b6f1-0fa1989f2864	2026-10-28 15:08:50.859529	2026-10-28 15:08:50.859529	2	2	\N
293	892e6796-507f-46a1-adf8-4f35f6e8790b	The recorded download filename is brief-viewer.exe.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:09:58.010177+00:00\nAnswer event: 0527a969-802c-4435-af8b-276ae44004ba	2026-10-28 15:09:59.155968	2026-10-28 15:09:59.155968	2	2	\N
297	6e41c47d-d7ed-4040-81ef-4f2aab13f5ce	The browser target path places the download in C:/Downloads.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:10:36.801199+00:00\nAnswer event: 640a2314-fcbf-42e7-8928-9d4bac4402c9	2026-10-28 15:10:37.158836	2026-10-28 15:10:37.158836	2	2	\N
299	0970bf48-1174-4e5f-9c15-4da1a4e01b74	The identity record assigns session S-41 to m.ellis.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T15:11:52.499281+00:00\nAnswer event: 3e4454e9-2e9b-4cc7-b399-1bd43327cd39	2026-10-28 15:11:52.722452	2026-10-28 15:11:52.722452	2	2	\N
302	3c77b617-54f5-44ee-a0c9-549c435c42a4	Version 4 specifies the 10:30–11:30Z movement window.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T15:12:55.576242+00:00\nAnswer event: d09f5b66-904b-494f-a30b-7b70cbcaf815	2026-10-28 15:12:55.77884	2026-10-28 15:12:55.77884	2	2	\N
304	14f3c0ee-c03c-4b4a-827b-4523b9d2331a	The coverage record lists no network collection for WS-31.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:14:40.914926+00:00\nAnswer event: b2c673f1-2984-448d-8554-1a75af1d09af	2026-10-28 15:14:42.16504	2026-10-28 15:14:42.16504	2	2	\N
307	4788271c-b16d-411f-9eb4-b4be39dca60e	DOCS-1 audit collection has a gap beginning at 09:14:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:16:14.934716+00:00\nAnswer event: f544ed63-6c8f-4d33-8e78-5f52e1a1aa84	2026-10-28 15:16:15.109045	2026-10-28 15:16:15.109045	2	2	\N
310	1d7f9b4b-4043-471d-9063-173738a32eae	DOCS-1 audit collection has a gap beginning at 09:14:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:17:05.197908+00:00\nAnswer event: 6bbff631-9e0e-47b9-9f24-dfa969c49314	2026-10-28 15:17:06.293151	2026-10-28 15:17:06.293151	2	2	\N
313	348aa89b-0a20-48da-be00-443276ea2aa1	The WS-22 inventory identifies Exercise IT as publisher.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:17:50.206629+00:00\nAnswer event: f0f10e29-24e7-4ffb-a3eb-16bb26c9dcbf	2026-10-28 15:17:51.055862	2026-10-28 15:17:51.055862	2	2	\N
261	d099c289-86d2-4a3a-a593-da2accaa877e	The recovered cache contains movement brief version 3.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q2\nSolved by: BOO\nUTC: 2026-10-28T14:52:11.236235+00:00\nAnswer event: 94be8454-609c-41cd-ad4d-3b687543f092	2026-10-28 14:52:11.428215	2026-10-28 14:52:11.428215	2	2	\N
268	63ca448f-d9e6-4e29-b0be-e43916a388a1	Version 4 specifies sector BLUE.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:54:39.394733+00:00\nAnswer event: e624e403-30c5-4d22-be2f-76cd8a38f823	2026-10-28 14:54:39.991764	2026-10-28 14:54:39.991764	2	2	\N
271	964f940f-17d3-41d1-a97b-8a544d11c0c9	After subtracting the documented 120-second device offset, task registration occurred at 09:08:00 UTC.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T14:55:28.973444+00:00\nAnswer event: c6c98267-8c27-4c54-8687-92bd9739c74a	2026-10-28 14:55:29.789854	2026-10-28 14:55:29.789854	2	2	\N
282	cebb0136-9304-451a-acc2-e60cbff86e5d	The supplied identity policy treats explicit session revocation separately from a password reset. No containment change was performed by participants.\nEvidence: identity/policy.txt (issued-session invalidation policy)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T15:03:01.770168+00:00\nAnswer event: 47caf4fc-355e-40c8-b3f4-c0dcd9f987ed	2026-10-28 15:03:02.521534	2026-10-28 15:03:02.521534	2	2	\N
289	87dd729b-af1d-4210-8315-517ffb99e87d	The browser export records the viewer download at 08:57:00 UTC.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:08:23.166826+00:00\nAnswer event: 59478292-0b9c-4ff1-bae4-be52d802dbdb	2026-10-28 15:08:23.980389	2026-10-28 15:08:23.980389	2	2	\N
295	4eaaa248-9887-4976-afcf-38d3c2f18359	The WS-31 inventory observation is timestamped 08:45:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:10:22.321795+00:00\nAnswer event: d9fda9f5-8aea-47da-8426-35fd0ed71346	2026-10-28 15:10:23.239619	2026-10-28 15:10:23.239619	2	2	\N
298	83a52659-c8b8-45b7-ac4c-4bc358d54fee	The supplied version history records v4 superseding v3 at 09:10:00 UTC.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T15:11:05.690401+00:00\nAnswer event: bce32caa-8bda-4602-9770-68c3fa078d1b	2026-10-28 15:11:06.431011	2026-10-28 15:11:06.431011	2	2	\N
301	565b08aa-b107-4b7c-a304-25a45ecb4410	The download URL names briefs.helpdesk.example; this does not establish the original delivery mechanism.\nEvidence: browser/downloads.csv (browser/downloads.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T03-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:12:32.032051+00:00\nAnswer event: 7f0e2eaa-a50d-48eb-90c5-9919dfb818f7	2026-10-28 15:12:33.083366	2026-10-28 15:12:33.083366	2	2	\N
312	28b0277b-2704-4e0c-8494-b208f67be051	The refresh carries previous_claim, rather than a newly challenged MFA result.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T15:17:25.873855+00:00\nAnswer event: 53ce79a1-0774-44b4-8a16-c38efaf7fbc7	2026-10-28 15:17:26.364741	2026-10-28 15:17:26.364741	2	2	\N
315	9ec14491-e1dd-49d5-b517-53e4413acd23	DOCS-1 audit collection resumes at 09:18:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:18:25.228718+00:00\nAnswer event: fba27b90-e92b-461c-b8df-a3b223d3a782	2026-10-28 15:18:26.407981	2026-10-28 15:18:26.407981	2	2	\N
318	baa983a1-225c-432c-bcd9-f659b284e36e	The server audit records r.chen as the planner reading v4.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T15:19:31.880651+00:00\nAnswer event: 5836b0ab-10fb-4bf1-ae13-4f11efe3489c	2026-10-28 15:19:32.548678	2026-10-28 15:19:32.548678	2	2	\N
321	a8cb6256-790e-406d-ad39-962b07fdd2cb	The acquisition manifest maps this isolated lab reconstruction to WS-17; the original computer name is preserved.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:20:12.899151+00:00\nAnswer event: f692385f-1194-4973-b6b5-91d2b304ba30	2026-10-28 15:20:13.16572	2026-10-28 15:20:13.16572	2	2	\N
262	f65174d5-ec74-4662-ba75-95f4fa2cb7b1	The later successful refresh reused S-41.\nEvidence: wazuh/telemetry.jsonl (data.action:session_refresh)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q3\nSolved by: BOO\nUTC: 2026-10-28T14:52:14.064887+00:00\nAnswer event: d69ccda4-5a31-4e67-8e28-afc475d15e72	2026-10-28 14:52:14.864413	2026-10-28 14:52:14.864413	2	2	\N
265	4695a291-9520-4c19-bfb5-1cc5065faee8	WS-31 inventory contains a task named BriefSync, creating an unresolved scope lead.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:52:44.139209+00:00\nAnswer event: 3722052b-cb47-4e02-b377-3099f606ad8a	2026-10-28 14:52:44.476875	2026-10-28 14:52:44.476875	2	2	\N
269	e83199f8-b5b6-4eb8-b360-f9221d728204	A later session refresh succeeded at 09:26:00 UTC.\nEvidence: identity/late-auth.csv (action=session_refresh AND result=success)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T14:54:40.784008+00:00\nAnswer event: 0ec40d78-f569-44b2-9f12-5f0997660dd7	2026-10-28 14:54:41.265947	2026-10-28 14:54:41.265947	2	2	\N
272	668a0ca2-c3db-4aeb-90b6-9af31f9ed247	The supplied identity policy treats explicit session revocation separately from a password reset. No containment change was performed by participants.\nEvidence: identity/policy.txt (issued-session invalidation policy)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q4\nSolved by: BOO\nUTC: 2026-10-28T14:55:36.620719+00:00\nAnswer event: 1cddd3eb-2aa1-4823-8e89-c93c8d538145	2026-10-28 14:55:37.211212	2026-10-28 14:55:37.211212	2	2	\N
274	9c90d6b6-be07-49a0-b5f3-bfc3a99ec55b	The supplied identity policy treats explicit session revocation separately from a password reset. No containment change was performed by participants.\nEvidence: identity/policy.txt (issued-session invalidation policy)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:56:35.202247+00:00\nAnswer event: e60f9c36-2f82-440b-b891-4a5713ce93e4	2026-10-28 14:56:36.217875	2026-10-28 14:56:36.217875	2	2	\N
278	765ab377-280a-4603-98dc-4a228f24511b	WS-22 has a similarly named approved task; its name alone is not a compromise indicator.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:59:51.636739+00:00\nAnswer event: 34f3e861-b391-4b76-a9af-e41251e36556	2026-10-28 14:59:51.890192	2026-10-28 14:59:51.890192	2	2	\N
280	9d6140f3-3ab1-46a0-9e05-55a30e9e04c7	The WS-31 inventory observation is timestamped 08:45:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:02:02.536173+00:00\nAnswer event: f10a7a01-63bc-425c-a4f1-a6271c7562a1	2026-10-28 15:02:03.331805	2026-10-28 15:02:03.331805	2	2	\N
283	eef25abc-f57f-4c28-a344-2f049b942116	The approved WS-22 application path is C:/Program Files/Approved/briefsync.exe.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:03:18.297585+00:00\nAnswer event: 7310990e-3cc9-4363-b5bc-759bed34ab64	2026-10-28 15:03:19.203085	2026-10-28 15:03:19.203085	2	2	\N
285	ee351517-0c03-45d8-a92e-6a73344bd1a7	WS-22 has a similarly named approved task; its name alone is not a compromise indicator.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T15:04:39.692949+00:00\nAnswer event: 14a57fea-5cf2-4f20-8993-3ee364676a7e	2026-10-28 15:04:40.841294	2026-10-28 15:04:40.841294	2	2	\N
287	0b35a438-c5fa-404f-8cc3-b49aafe2df62	The server audit records r.chen as the planner reading v4.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:07:02.072880+00:00\nAnswer event: 551f6c3f-a88d-4515-b159-bfa6d1a23583	2026-10-28 15:07:02.89912	2026-10-28 15:07:02.89912	2	2	\N
292	5f5b6e1c-8537-4032-955b-cae55a526fcf	The coverage record lists no network collection for WS-31.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:09:44.542709+00:00\nAnswer event: 5fa5e086-f316-4716-bc34-36480633f82f	2026-10-28 15:09:45.611213	2026-10-28 15:09:45.611213	2	2	\N
296	c1bb16d0-f9ea-410c-8ace-791fd02d9eeb	WS-31 endpoint collection stopped at 08:50:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:10:32.851511+00:00\nAnswer event: 37d4bdd5-c061-4a2e-80c2-c7bc9b3d0fcf	2026-10-28 15:10:33.805223	2026-10-28 15:10:33.805223	2	2	\N
306	1d899213-679a-4968-b6be-cd94dabf7c6d	The external S-41 refresh is timestamped 09:03:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:15:42.666742+00:00\nAnswer event: d3819cef-e09c-4c95-85f7-9e66f3e67984	2026-10-28 15:15:43.141961	2026-10-28 15:15:43.141961	2	2	\N
309	ada5d59a-ac20-45d9-889c-d6820e19d57b	WS-22 has a similarly named approved task; its name alone is not a compromise indicator.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T15:17:00.589795+00:00\nAnswer event: e017681b-d19b-446c-a0c9-4e4f7fed53a5	2026-10-28 15:17:00.885884	2026-10-28 15:17:00.885884	2	2	\N
316	48ce8cac-9c9f-418d-9eb9-b5df2dc19a04	The approved WS-22 application path is C:/Program Files/Approved/briefsync.exe.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T15:18:36.598670+00:00\nAnswer event: c38b6ffa-0e9f-4628-a5f4-36f41106bb1c	2026-10-28 15:18:36.876363	2026-10-28 15:18:36.876363	2	2	\N
319	88382d8e-7bb7-4a87-9c54-77ab29357ec0	The coverage record lists no network collection for WS-31.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:19:35.939612+00:00\nAnswer event: 1c218f91-5067-43f5-9cc4-16a47b3b418f	2026-10-28 15:19:36.864975	2026-10-28 15:19:36.864975	2	2	\N
264	adace454-1219-4de4-872f-0c833a18b60f	The cached version includes check-in word CEDAR.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q4\nSolved by: BOO\nUTC: 2026-10-28T14:52:32.233499+00:00\nAnswer event: 52d0f16b-b42b-4f47-9442-1d6afd28781c	2026-10-28 14:52:33.060682	2026-10-28 14:52:33.060682	2	2	\N
266	7da91caf-c223-43ab-a8f5-9eae45b3031b	The WS-31 inventory observation is timestamped 08:45:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T14:53:07.527141+00:00\nAnswer event: 4c1f44d3-d0dc-4d37-9504-ec3888dd59dc	2026-10-28 14:53:08.194149	2026-10-28 14:53:08.194149	2	2	\N
270	388d68db-6f5f-46be-aa1a-1500a514d5dc	Version 4 specifies the 10:30–11:30Z movement window.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:55:16.076591+00:00\nAnswer event: a4ab4818-1bbb-4fd2-b06e-9dc2abc063e3	2026-10-28 14:55:16.25738	2026-10-28 14:55:16.25738	2	2	\N
273	2a7ce1ae-1ad9-4343-8714-1cd046383e59	CEDAR is unchanged between the supplied v3 and v4 records.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T14:55:44.056682+00:00\nAnswer event: 46784096-ab17-4160-8bcc-f8d6ea45778a	2026-10-28 14:55:44.740383	2026-10-28 14:55:44.740383	2	2	\N
277	3f175c59-61b0-48e4-8a6b-8ceaa1c8796a	Request req-71 returned plan-v3.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T14:59:04.183347+00:00\nAnswer event: f7dac219-d207-49e1-9756-5f9b4e7746bf	2026-10-28 14:59:04.358714	2026-10-28 14:59:04.358714	2	2	\N
279	712ad055-240d-4f33-8b57-1ebce45f0c8d	The roster request returned HTTP 403.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:01:35.009786+00:00\nAnswer event: 392380bf-0526-4806-8d1f-efe5edf243b2	2026-10-28 15:01:35.43626	2026-10-28 15:01:35.43626	2	2	\N
281	708f7187-d778-4869-a3c8-f6e121dd302f	The WS-22 inventory identifies Exercise IT as publisher.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:02:38.576189+00:00\nAnswer event: 92164b9d-79d9-4f41-95df-706a8403e29e	2026-10-28 15:02:39.513894	2026-10-28 15:02:39.513894	2	2	\N
284	437d8c84-eeea-455f-ba6a-cba8f735d06c	The denied roster request returned zero body bytes.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T15:04:32.057991+00:00\nAnswer event: 450d58cb-14f8-4074-872d-06a1870dba27	2026-10-28 15:04:32.354184	2026-10-28 15:04:32.354184	2	2	\N
286	56940329-06fa-4f64-9587-cd5143c1f32a	Request req-75 identifies the denied roster access, not a successful disclosure.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T15:05:37.970095+00:00\nAnswer event: 1b07c96c-2a52-4423-9559-b93862510f99	2026-10-28 15:05:38.494815	2026-10-28 15:05:38.494815	2	2	\N
288	cbd0bdbc-e6f8-4efe-abb0-1b60075b85b9	The WS-22 inventory identifies Exercise IT as publisher.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T15:08:15.958394+00:00\nAnswer event: 8059b7f0-5c20-4bc9-9975-dcddc54ba344	2026-10-28 15:08:16.630126	2026-10-28 15:08:16.630126	2	2	\N
291	07264605-2bcd-4649-8987-def3463631f8	WS-31 inventory contains a task named BriefSync, creating an unresolved scope lead.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:09:20.923469+00:00\nAnswer event: da507943-216e-48ff-8fd7-43f4b3fe9e65	2026-10-28 15:09:21.741311	2026-10-28 15:09:21.741311	2	2	\N
294	4f150097-d006-4bfc-8650-c107139288d2	The server audit records r.chen as the planner reading v4.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-22)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T10-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T15:10:01.992755+00:00\nAnswer event: 831cc94a-dcfc-4bf4-8fc6-f1494550d010	2026-10-28 15:10:02.543604	2026-10-28 15:10:02.543604	2	2	\N
300	c0bbdafe-292e-4350-b33b-52f80483cdef	Version 4 specifies sector BLUE.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:12:06.303006+00:00\nAnswer event: 8222ea99-a0e9-44ac-8772-8af6d2346644	2026-10-28 15:12:07.269051	2026-10-28 15:12:07.269051	2	2	\N
303	f3b20444-6cd9-4688-8598-b6b3e7d58688	CEDAR is unchanged between the supplied v3 and v4 records.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T15:13:36.463573+00:00\nAnswer event: 4a234880-12c3-482e-9774-eb344e4e040d	2026-10-28 15:13:37.009609	2026-10-28 15:13:37.009609	2	2	\N
305	b8f2ff01-94df-4767-a244-14481f8f9656	Task inventory alone does not establish execution on WS-31. Further collection would be required.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:14:56.137998+00:00\nAnswer event: 6892c2ee-2a40-47b7-872c-facdadbd03fe	2026-10-28 15:14:56.666511	2026-10-28 15:14:56.666511	2	2	\N
308	f2aa7f65-a4aa-4f42-b92c-960c113e1c8f	DOCS-1 audit collection resumes at 09:18:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:16:30.299485+00:00\nAnswer event: 2e3a205e-35d9-4522-90e9-2b6e34765091	2026-10-28 15:16:30.842275	2026-10-28 15:16:30.842275	2	2	\N
311	9de1cfce-ed5c-4f79-a16b-7c7702608c85	Native Security record 606 records viewer PID 6364.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:17:06.045881+00:00\nAnswer event: be03dfac-52dc-41ce-8bf2-4443dd99ad10	2026-10-28 15:17:06.57702	2026-10-28 15:17:06.57702	2	2	\N
314	7c443d1e-a4b0-4b5c-be82-c3440a5c7a0d	The documented WS-17 device offset is 120 seconds fast; normalized records must not receive a second correction.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:18:16.029319+00:00\nAnswer event: a749de45-773f-4644-8bf1-a39d90c8ef4f	2026-10-28 15:18:16.959296	2026-10-28 15:18:16.959296	2	2	\N
317	4346ab74-8659-4868-a7f1-b9a2535cc6b8	Native Security record 606 records viewer PID 6364.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:19:25.769920+00:00\nAnswer event: eaed8595-6179-4a24-b5c0-a59755c49d82	2026-10-28 15:19:26.144722	2026-10-28 15:19:26.144722	2	2	\N
320	0de55b6f-6dda-4113-9464-38b47fb113f4	The native process event names browser.exe as the parent training surrogate.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:19:41.104823+00:00\nAnswer event: f5de6f41-ba99-4c5f-bab7-d7e8476cc6d2	2026-10-28 15:19:42.206169	2026-10-28 15:19:42.206169	2	2	\N
322	397b4b62-ada8-4786-8006-a22fdddc8e57	The reconstructed process was created at 23:22:00 UTC on 2026-09-15; no historic clock correction applies.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:21:16.680062+00:00\nAnswer event: 399fde4e-f00a-402a-b476-683699bf966f	2026-10-28 15:21:16.890321	2026-10-28 15:21:16.890321	2	2	\N
323	9cb1ddba-e00f-453a-ba12-7ff781ff029f	The task-registration record names brief-viewer.exe as the registering process.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:21:40.449255+00:00\nAnswer event: 230d72ca-1f3f-4f04-8140-df752473e8f0	2026-10-28 15:21:40.748591	2026-10-28 15:21:40.748591	2	2	\N
324	6f85dabc-d9e3-4176-a557-86c9cbb2eff9	Native Security record 607 records the BriefSync task.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:21:55.561966+00:00\nAnswer event: e9081cd6-bb7d-4612-ab70-f8d00498a712	2026-10-28 15:21:56.433732	2026-10-28 15:21:56.433732	2	2	\N
325	973515f5-4f36-4ab6-a9d4-2196ffd9abbd	The registered task is named BriefSync.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:22:11.513337+00:00\nAnswer event: ed198359-c266-4b34-a4b8-5c11b1649181	2026-10-28 15:22:12.090076	2026-10-28 15:22:12.090076	2	2	\N
326	87929b52-171b-4aa7-9810-03c474cc52f8	The captured task XML targets the harmless brief-viewer.exe training surrogate.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:22:29.492993+00:00\nAnswer event: ac2b0923-f26f-4efb-80bf-0f209dab512c	2026-10-28 15:22:29.653103	2026-10-28 15:22:29.653103	2	2	\N
327	46c02ed7-d473-4121-a0d6-037df5a4291c	The recorded task trigger is user logon.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:22:43.608533+00:00\nAnswer event: 200bf9ee-0228-4acc-a483-dee7fec1a4b6	2026-10-28 15:22:44.21407	2026-10-28 15:22:44.21407	2	2	\N
328	f4d6fb12-b4ec-4a68-8541-2bc34954a30d	Volatility recovered viewer PID 6364 at kernel virtual offset 0xc98352279080.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:23:13.215608+00:00\nAnswer event: 1628def4-0045-439f-9cbe-a33ea26fbfe1	2026-10-28 15:23:14.263704	2026-10-28 15:23:14.263704	2	2	\N
329	b7c73e80-24d0-4e93-b6fb-4fab8a37b28f	DOCS-1 audit collection has a gap beginning at 09:14:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:23:17.844106+00:00\nAnswer event: 623e57b5-0b1b-4a97-a634-02407d2e2014	2026-10-28 15:23:18.579227	2026-10-28 15:23:18.579227	2	2	\N
330	8ad1e9d1-b9b4-4062-b58c-b23f40b51040	The separate password-login attempt at 09:05 failed; it must not be conflated with session refresh success.\nEvidence: wazuh/telemetry.jsonl (data.session:S-41)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T06-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T15:23:25.808401+00:00\nAnswer event: 01d9fcaa-e477-4926-9dae-02e069015766	2026-10-28 15:23:26.042832	2026-10-28 15:23:26.042832	2	2	\N
331	acc1e4f2-b4a9-4bbb-adaa-27d272e6a62e	Acquisition timestamps describe the lab capture and must not be rewritten as historical incident timestamps.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:23:32.911998+00:00\nAnswer event: e25bf1bd-e3e8-4ea8-9165-91ad2eb7821c	2026-10-28 15:23:33.483857	2026-10-28 15:23:33.483857	2	2	\N
332	b7672d25-905b-4cef-a6f3-d54f9eafb2f8	DOCS-1 audit collection resumes at 09:18:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:23:39.041819+00:00\nAnswer event: 68769668-3172-4700-a029-271130ddb23f	2026-10-28 15:23:39.891505	2026-10-28 15:23:39.891505	2	2	\N
333	c58b7aae-39eb-416e-a839-12c0027440e8	The recovered viewer process records parent PID 7644.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:23:43.659853+00:00\nAnswer event: ffb2672c-c453-4a5b-aa81-bebf8e0d033f	2026-10-28 15:23:44.204715	2026-10-28 15:23:44.204715	2	2	\N
334	a69d6885-d454-44dd-a92e-5c609c3a6b3d	The recovered cache names fictional patrol LANTERN.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:23:54.148464+00:00\nAnswer event: 100f0442-2171-4f7b-b4e3-a05f02d634a8	2026-10-28 15:23:54.680368	2026-10-28 15:23:54.680368	2	2	\N
335	d589336b-ac62-46b5-9ace-98483a44bdaa	The reconstructed task was registered at 23:22:01 UTC on 2026-09-15.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:24:08.299542+00:00\nAnswer event: 4f2302b2-cb1a-4f0a-8239-cb578fd253f2	2026-10-28 15:24:09.332144	2026-10-28 15:24:09.332144	2	2	\N
342	8ab410f8-e3b0-4b68-abd6-cae838abf9ba	The password-reset record is timestamped 09:20:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.action:password_reset)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T15:25:04.622592+00:00\nAnswer event: 0857c9cf-c077-49cb-b2b1-0eeeb8f89b30	2026-10-28 15:25:05.508035	2026-10-28 15:25:05.508035	2	2	\N
344	6901df50-f0ec-4cf6-930b-1894586e5d61	A later session refresh succeeded at 09:26:00 UTC.\nEvidence: identity/late-auth.csv (action=session_refresh AND result=success)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:27:05.586271+00:00\nAnswer event: 60ba686f-53bd-4c60-a8da-3177ac3b2a3a	2026-10-28 15:27:06.605156	2026-10-28 15:27:06.605156	2	2	\N
347	1d764750-b463-412a-8200-1c456a657c4a	The documented WS-17 device offset is 120 seconds fast; normalized records must not receive a second correction.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:28:01.830878+00:00\nAnswer event: 6b0914a1-8d4b-4b27-b910-f70d45686f24	2026-10-28 15:28:02.418325	2026-10-28 15:28:02.418325	2	2	\N
349	d2132a34-2c11-4a06-8052-906c12dc241d	The supplied identity policy treats explicit session revocation separately from a password reset. No containment change was performed by participants.\nEvidence: identity/policy.txt (issued-session invalidation policy)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T15:29:58.922467+00:00\nAnswer event: 2eb58505-8af8-415e-b2f9-06af1f1a5064	2026-10-28 15:29:59.531451	2026-10-28 15:29:59.531451	2	2	\N
351	61f4a38b-5555-4743-859f-394a04705768	WS-31 inventory contains a task named BriefSync, creating an unresolved scope lead.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:31:49.155450+00:00\nAnswer event: 77c48819-fca8-4354-b582-4b6f630dd96c	2026-10-28 15:31:50.104481	2026-10-28 15:31:50.104481	2	2	\N
354	72143434-5a71-400d-9e2b-a7e81451c6ed	The captured task XML targets the harmless brief-viewer.exe training surrogate.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:32:47.912397+00:00\nAnswer event: 923354e9-bc4e-4537-96cb-321765daa0a8	2026-10-28 15:32:48.30923	2026-10-28 15:32:48.30923	2	2	\N
357	6422afc7-3dad-4bb7-a027-66cf5dc184ef	The reconstructed task was registered at 23:22:01 UTC on 2026-09-15.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:33:41.670341+00:00\nAnswer event: 9aefdbc0-48bb-499f-a98d-39ccf6c59386	2026-10-28 15:33:42.30358	2026-10-28 15:33:42.30358	2	2	\N
361	098d9b2f-b2fd-424f-9c79-81521646af5e	The acquisition manifest maps this isolated lab reconstruction to WS-17; the original computer name is preserved.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:34:30.682114+00:00\nAnswer event: 5d3018ca-c9d7-4aa6-9f78-90dcd7ee6d50	2026-10-28 15:34:31.400521	2026-10-28 15:34:31.400521	2	2	\N
364	d54d49c3-fc6d-4463-99ff-768b8aa84f36	The native snapshot records TCP remote port 443.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:35:01.082583+00:00\nAnswer event: 58b2fec2-665e-4377-935d-a57bc72de092	2026-10-28 15:35:01.767453	2026-10-28 15:35:01.767453	2	2	\N
368	1f82b02a-dd65-43c5-9f64-87201ce1162c	The reconstructed process was created at 23:22:00 UTC on 2026-09-15; no historic clock correction applies.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:35:32.699018+00:00\nAnswer event: 67f5a512-55c9-4888-a9b8-fef2e4ca2bee	2026-10-28 15:35:33.493022	2026-10-28 15:35:33.493022	2	2	\N
371	b2956f16-23d6-4cb9-a335-c0097b17cbb8	The recovered viewer process records parent PID 7644.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:36:34.227276+00:00\nAnswer event: 185e918a-8968-4eee-a411-809cc9b4befd	2026-10-28 15:36:34.472361	2026-10-28 15:36:34.472361	2	2	\N
377	0b477735-2a40-472b-ae51-237f0255e607	Volatility recovered viewer PID 6364 at kernel virtual offset 0xc98352279080.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:38:21.271419+00:00\nAnswer event: 9cf778c1-b785-4006-9548-bf34b87edf2a	2026-10-28 15:38:21.847292	2026-10-28 15:38:21.847292	2	2	\N
380	7afe31da-6748-4101-81ab-84a16295c6bf	The recovered parent process name is browser.exe; it is a training surrogate.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:39:27.256275+00:00\nAnswer event: bc641139-85c9-4e47-8986-65fbd9080caa	2026-10-28 15:39:28.126072	2026-10-28 15:39:28.126072	2	2	\N
383	1416867c-ca47-44eb-99da-411c8b4b5f39	The recovered parent process name is browser.exe; it is a training surrogate.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:40:29.112659+00:00\nAnswer event: 13754b47-4718-4b94-ad1a-b1c2f715d296	2026-10-28 15:40:30.179184	2026-10-28 15:40:30.179184	2	2	\N
336	97dde744-71a0-4fe7-bc72-3b1899a81250	The recovered parent process name is browser.exe; it is a training surrogate.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:24:18.970015+00:00\nAnswer event: 24c4411f-a07f-4d17-a437-1246b3a8dea0	2026-10-28 15:24:19.886135	2026-10-28 15:24:19.886135	2	2	\N
339	a8467029-2483-4282-ae96-7986e1494823	The cached version names sector AMBER.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:24:40.759058+00:00\nAnswer event: e1420972-e4bf-4d9b-acd5-887c6ec9944f	2026-10-28 15:24:41.081478	2026-10-28 15:24:41.081478	2	2	\N
343	bb777adc-8de2-4703-9a7c-e3ab83e1a8be	The memory-derived command line contains cache argument C:/Temp/move-cache.txt.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:25:10.542264+00:00\nAnswer event: 50c48b10-e422-4f1d-b071-5615b2bbf26f	2026-10-28 15:25:10.87305	2026-10-28 15:25:10.87305	2	2	\N
352	260d3dd1-e6f5-463e-a318-52044887c8be	Native Security record 606 records viewer PID 6364.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:32:06.670520+00:00\nAnswer event: 6f1f82e0-3eb8-40b3-9bf9-f2ec7d920bd1	2026-10-28 15:32:07.739626	2026-10-28 15:32:07.739626	2	2	\N
355	db666f70-2476-445a-8be5-09a4f1226bf0	The roster request returned HTTP 403.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:33:13.283215+00:00\nAnswer event: 5daec0ba-4dc2-4222-89e0-0ee285f6bc1c	2026-10-28 15:33:14.113631	2026-10-28 15:33:14.113631	2	2	\N
358	b807ed8b-6c6e-43a8-abfd-b34bdf13ac02	The supplied version history records v4 superseding v3 at 09:10:00 UTC.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:34:21.191383+00:00\nAnswer event: 9e7303a9-1788-42aa-b16d-dc54658fe320	2026-10-28 15:34:21.373195	2026-10-28 15:34:21.373195	2	2	\N
365	4ad4e79b-2ca8-4507-9f1f-ec54efb0c4e8	Version 4 specifies the 10:30–11:30Z movement window.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:35:04.355559+00:00\nAnswer event: 43fb9f60-148c-4538-9976-cda3d50228d9	2026-10-28 15:35:05.089781	2026-10-28 15:35:05.089781	2	2	\N
374	75dae165-d784-4afb-96b7-70446472f49c	The reconstructed task was registered at 23:22:01 UTC on 2026-09-15.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q3\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:37:47.398909+00:00\nAnswer event: 026e726f-11ae-44b0-8661-cd800f91e8d4	2026-10-28 15:37:48.116791	2026-10-28 15:37:48.116791	2	2	\N
378	78cc7284-d04a-4624-9e84-900d98fa32b9	The training surrogate contains destination string 198.51.100.77.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:38:32.043663+00:00\nAnswer event: 1b7b271a-1951-4dc2-901b-0857741a7550	2026-10-28 15:38:32.284943	2026-10-28 15:38:32.284943	2	2	\N
384	1133173f-a825-4f9d-9ac9-24eda4ad74d4	The WS-31 inventory observation is timestamped 08:45:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:40:32.674217+00:00\nAnswer event: badb8e2c-271d-48b2-a2d7-61ce50eaf28b	2026-10-28 15:40:33.623803	2026-10-28 15:40:33.623803	2	2	\N
387	5c05ef80-681f-48f3-ad3d-a405d46d6391	The training surrogate contains task-label string BriefSync.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:40:41.017458+00:00\nAnswer event: 4aec56b4-0f54-49ad-9f9a-4d0c79c4caf6	2026-10-28 15:40:41.682949	2026-10-28 15:40:41.682949	2	2	\N
393	92330ab3-6a47-4b5e-bb53-6d734194aef3	The WS-31 inventory observation is timestamped 08:45:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:42:42.329034+00:00\nAnswer event: d5450d1a-5028-4800-8cdf-fedf5ee4f09e	2026-10-28 15:42:43.259658	2026-10-28 15:42:43.259658	2	2	\N
400	cc591a18-55db-4d2c-a18a-6b3a337ab23a	The documented WS-17 device offset is 120 seconds fast; normalized records must not receive a second correction.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:43:54.128450+00:00\nAnswer event: 685fe2c2-6c41-43be-abeb-cbf4d0447c39	2026-10-28 15:43:54.516639	2026-10-28 15:43:54.516639	2	2	\N
402	b0865bbe-526c-4ef9-b567-27a4614270a5	The reconstructed process was created at 23:22:00 UTC on 2026-09-15; no historic clock correction applies.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:45:52.471490+00:00\nAnswer event: 8d8e6672-d8f2-4f29-b3ae-799c86bbbbc0	2026-10-28 15:45:53.267466	2026-10-28 15:45:53.267466	2	2	\N
405	6eb16263-f43d-4a55-963b-fe2e4e288962	Native Security record 607 records the BriefSync task.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:46:50.613708+00:00\nAnswer event: e50290f0-203c-494f-af9a-a251c3b2d013	2026-10-28 15:46:51.415542	2026-10-28 15:46:51.415542	2	2	\N
408	754914f7-da7b-44cb-8f4e-d8bcab3ea535	The captured task XML targets the harmless brief-viewer.exe training surrogate.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:47:39.393179+00:00\nAnswer event: 75edd4ce-58cb-43cb-84a0-333078c97173	2026-10-28 15:47:40.21043	2026-10-28 15:47:40.21043	2	2	\N
337	542501ea-58b8-4597-b285-52b934e11cab	After subtracting the documented 120-second device offset, task registration occurred at 09:08:00 UTC.\nEvidence: endpoint/events.csv (endpoint/events.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T04-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:24:24.203408+00:00\nAnswer event: 4c0ec12b-af08-437e-b2fe-cfd8301600bf	2026-10-28 15:24:25.178812	2026-10-28 15:24:25.178812	2	2	\N
340	61a1b998-483c-4d51-b76a-7ed3bfd5559b	The documented WS-17 device offset is 120 seconds fast; normalized records must not receive a second correction.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:24:51.991497+00:00\nAnswer event: 423142be-0270-4f7d-b971-9a1fb33c0873	2026-10-28 15:24:52.646162	2026-10-28 15:24:52.646162	2	2	\N
345	3e127c44-c44d-4fb9-9bce-c68d579562fc	Request req-71 returned plan-v3.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:27:43.583622+00:00\nAnswer event: 766da67d-28df-47a1-ae64-7b65ab1411fa	2026-10-28 15:27:44.60733	2026-10-28 15:27:44.60733	2	2	\N
348	7a66f709-2634-469f-9ca2-a9c644881876	Request req-75 identifies the denied roster access, not a successful disclosure.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:29:27.618614+00:00\nAnswer event: f66c738a-56f4-4eac-8fac-20c99769167d	2026-10-28 15:29:28.562979	2026-10-28 15:29:28.562979	2	2	\N
350	6701f7df-e8bd-4d32-acd8-aef49200ec42	Native Security record 607 records the BriefSync task.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:31:31.081520+00:00\nAnswer event: 439e9652-425e-4eb0-bac5-6327db913f47	2026-10-28 15:31:32.266241	2026-10-28 15:31:32.266241	2	2	\N
353	d6156b7c-ef1f-4bcd-b16e-b72e3c93a1b1	The denied roster request returned zero body bytes.\nEvidence: server/access.csv (server/access.csv)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T08-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:32:21.147539+00:00\nAnswer event: c212d67f-bab2-4543-aaf3-300983050ac7	2026-10-28 15:32:21.347846	2026-10-28 15:32:21.347846	2	2	\N
356	1b332d26-12c7-48b5-9ebb-30a3189702d9	The native process event names browser.exe as the parent training surrogate.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:33:17.790886+00:00\nAnswer event: 832e12ab-175c-4634-94eb-c17a8cf7ac50	2026-10-28 15:33:18.398212	2026-10-28 15:33:18.398212	2	2	\N
359	3fa83be0-374b-4bd1-94d6-64628042dfb7	The guest's native connection snapshot records PID 6364.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:34:24.160161+00:00\nAnswer event: 6d9c7b6e-bb9c-4367-9231-9e999793584d	2026-10-28 15:34:24.701426	2026-10-28 15:34:24.701426	2	2	\N
362	662eddd1-0fc2-43ea-a957-99faa3b2517f	Version 4 specifies sector BLUE.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:34:40.190467+00:00\nAnswer event: 280b1e9d-b6ec-44b7-987c-2e97506a2b2e	2026-10-28 15:34:40.810267	2026-10-28 15:34:40.810267	2	2	\N
366	12799ac9-1afe-462e-aeb1-59c7e306de94	CEDAR is unchanged between the supplied v3 and v4 records.\nEvidence: server/version-comparison.csv (Open the CSV in the text viewer)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T09-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:35:12.541084+00:00\nAnswer event: 32c14523-a321-4bca-850b-6c9dc90822b4	2026-10-28 15:35:13.64152	2026-10-28 15:35:13.64152	2	2	\N
369	1b3ba39a-d57e-49e0-942c-842847326814	Volatility recovered viewer PID 6364 at kernel virtual offset 0xc98352279080.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:35:44.581138+00:00\nAnswer event: d63cb632-6d19-4ac7-bb86-bff13c573ede	2026-10-28 15:35:44.996673	2026-10-28 15:35:44.996673	2	2	\N
372	cdbbf583-243a-4253-83ef-0ff53a6cd9db	Native Security record 607 records the BriefSync task.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:36:59.544378+00:00\nAnswer event: 82705883-1b0d-447a-9458-23bfaa724411	2026-10-28 15:37:00.308591	2026-10-28 15:37:00.308591	2	2	\N
375	112e47fd-d56b-49f8-999e-8a23eb9737cc	The acquisition manifest maps this isolated lab reconstruction to WS-17; the original computer name is preserved.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:37:55.024139+00:00\nAnswer event: 6d6cf1eb-b9b2-4071-83b3-6b6ccc3024a7	2026-10-28 15:37:55.582817	2026-10-28 15:37:55.582817	2	2	\N
381	79af7a3d-c12e-4264-a185-8ebe8a696a0f	WS-31 inventory contains a task named BriefSync, creating an unresolved scope lead.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:40:07.128472+00:00\nAnswer event: da739bc7-2e18-408e-bda5-929fa6a9b4ec	2026-10-28 15:40:08.178501	2026-10-28 15:40:08.178501	2	2	\N
385	c57db720-ac54-4d00-ae4e-7ae53f509fcb	WS-31 inventory contains a task named BriefSync, creating an unresolved scope lead.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T15:40:33.037273+00:00\nAnswer event: 850edbbd-8915-4398-9a59-43fe4a6eeaaf	2026-10-28 15:40:33.881459	2026-10-28 15:40:33.881459	2	2	\N
388	007d1496-ab3b-462b-bdeb-7eff466753ec	Native Security record 606 records viewer PID 6364.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:41:16.905056+00:00\nAnswer event: 57520938-0f08-4ce5-9657-898e6211bb9f	2026-10-28 15:41:17.901998	2026-10-28 15:41:17.901998	2	2	\N
338	40ac4f4d-4f2b-4729-b121-3cdbd22e3666	The recovered cache contains movement brief version 3.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:24:24.362254+00:00\nAnswer event: fc23c510-e68f-45f8-b00a-bf4e8b1b8b59	2026-10-28 15:24:25.417797	2026-10-28 15:24:25.417797	2	2	\N
341	a2fea277-9bd5-44c1-9cdb-159d7128a49b	The cached version includes check-in word CEDAR.\nEvidence: disk/WS17-fat16.img (Deleted Files; inspect the entry ending OVECACH.TXT)\nLimitation: Prepared evidence is limited to the specified collection. Presence of an artifact is not proof of every related action.\nQuestion: T05-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:24:57.335818+00:00\nAnswer event: 231babd9-d982-42db-9179-56ae6444868f	2026-10-28 15:24:58.006855	2026-10-28 15:24:58.006855	2	2	\N
346	b191440e-eb85-4901-8988-07c577ab3df9	The later successful refresh reused S-41.\nEvidence: wazuh/telemetry.jsonl (data.action:session_refresh)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T07-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T15:27:44.067518+00:00\nAnswer event: a1b41c90-74f5-40d9-8791-962a1c94fb65	2026-10-28 15:27:44.820847	2026-10-28 15:27:44.820847	2	2	\N
360	4531f0d5-b307-4a80-94d3-677b22fb24b2	Acquisition timestamps describe the lab capture and must not be rewritten as historical incident timestamps.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:34:30.485583+00:00\nAnswer event: db67cd6e-9554-44c7-9753-ea5d71a7de5a	2026-10-28 15:34:31.173489	2026-10-28 15:34:31.173489	2	2	\N
363	70064ff5-cdf3-416c-a1e3-062a8bf4c7b1	198.51.100.77 was a guest-local loopback address in this reconstruction; no Internet traffic occurred.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:34:49.359376+00:00\nAnswer event: 08c2451f-8145-4dc8-ab4b-f40314e740f2	2026-10-28 15:34:50.256079	2026-10-28 15:34:50.256079	2	2	\N
367	02726532-9866-49a9-93f3-082f2c2356c6	This is a live acquisition sidecar, not a validated memory connection finding or evidence of human reading.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:35:27.909150+00:00\nAnswer event: ec940232-633f-4773-987d-e63992d4c1e7	2026-10-28 15:35:28.190879	2026-10-28 15:35:28.190879	2	2	\N
370	c20e73e0-254e-470c-8661-f665b7b90545	The DLP metadata links the supplied body to req-72.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:36:02.152304+00:00\nAnswer event: 60ffe0cc-58ba-4852-8687-842134dc02a5	2026-10-28 15:36:02.596807	2026-10-28 15:36:02.596807	2	2	\N
373	53eb3283-f6ca-4abf-ada7-abb97892c818	The captured task XML targets the harmless brief-viewer.exe training surrogate.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:37:22.911534+00:00\nAnswer event: da0ba757-27e2-4f82-bc48-eccafddc0514	2026-10-28 15:37:24.127688	2026-10-28 15:37:24.127688	2	2	\N
376	307f686b-d9c9-45f8-9fa6-e61c14bf0b76	Acquisition timestamps describe the lab capture and must not be rewritten as historical incident timestamps.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:38:07.698365+00:00\nAnswer event: 0dedee96-37d4-4189-9319-1fec90768e79	2026-10-28 15:38:08.204611	2026-10-28 15:38:08.204611	2	2	\N
379	25ea27c8-1655-4211-9e6b-aad4baff99c4	The recovered viewer process records parent PID 7644.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q2\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:38:38.735665+00:00\nAnswer event: a9c39301-ce92-425e-9ee2-6500f45908b7	2026-10-28 15:38:39.700974	2026-10-28 15:38:39.700974	2	2	\N
382	e112fa4b-fefe-4fd2-b028-1ef5c3dd89f7	The training surrogate contains configuration path /upload.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:40:17.407581+00:00\nAnswer event: 29b36c8c-e106-4d14-8a11-87e05f1e44e0	2026-10-28 15:40:17.631851	2026-10-28 15:40:17.631851	2	2	\N
389	6e30fe00-e6e2-4a0e-9427-203cf0f54077	The supplied training surrogate performs no network calls; its strings are for static inspection.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:41:18.264700+00:00\nAnswer event: 661e5076-0c4b-4dbd-a55d-3b3ba53755cb	2026-10-28 15:41:19.389294	2026-10-28 15:41:19.389294	2	2	\N
392	87767818-fccb-49c5-89f3-1966ad2ebbea	DOCS-1 audit collection has a gap beginning at 09:14:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:42:34.813237+00:00\nAnswer event: 51f29ec7-d49f-4663-950b-b960958c99d2	2026-10-28 15:42:35.933007	2026-10-28 15:42:35.933007	2	2	\N
395	1825add9-edac-465c-83e4-36770b363712	DOCS-1 audit collection resumes at 09:18:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:42:58.960608+00:00\nAnswer event: 8d640c1b-656a-4362-a699-ab263910ce16	2026-10-28 15:43:00.096574	2026-10-28 15:43:00.096574	2	2	\N
398	2a0a5726-b0e8-4f9a-ab49-e3c906308925	WS-31 endpoint collection stopped at 08:50:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T15:43:42.776002+00:00\nAnswer event: c17c73e9-cbe0-40af-8937-39f99cf962d3	2026-10-28 15:43:43.764599	2026-10-28 15:43:43.764599	2	2	\N
407	c7bd55b6-35bc-4463-9d02-f44abac426fd	The recovered viewer process records parent PID 7644.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:47:28.481097+00:00\nAnswer event: 45016769-f7b5-4643-8765-db9fd623c8c3	2026-10-28 15:47:28.677799	2026-10-28 15:47:28.677799	2	2	\N
386	e7743165-1b31-468a-9b28-4c063a7496b8	The coverage record lists no network collection for WS-31.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:40:39.846519+00:00\nAnswer event: c71a2399-ad2b-4cea-8e59-9df31f0deaa6	2026-10-28 15:40:40.362046	2026-10-28 15:40:40.362046	2	2	\N
390	10fdeec9-d60d-45af-b3b6-434fa7699d43	The classify_version example compares its input with integer 3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:41:31.097583+00:00\nAnswer event: cfe77e1e-b8a9-46f4-8c2e-d01dc25e9e54	2026-10-28 15:41:32.009839	2026-10-28 15:41:32.009839	2	2	\N
396	43bd3273-ea1c-46b8-8078-790be8e21ce7	Task inventory alone does not establish execution on WS-31. Further collection would be required.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:43:09.759010+00:00\nAnswer event: 5d0d3a91-cf6b-49ed-93a7-b0d075fbdf12	2026-10-28 15:43:10.545843	2026-10-28 15:43:10.545843	2	2	\N
399	0f203d91-c1cd-4f8d-9a15-bf3d611b62e8	The memory-derived command line contains cache argument C:/Temp/move-cache.txt.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T15:43:47.582259+00:00\nAnswer event: 77485381-4a99-4c12-868a-5b2fcec82383	2026-10-28 15:43:48.091437	2026-10-28 15:43:48.091437	2	2	\N
404	0bfa905e-9678-4065-8de9-13e8421e33d1	Acquisition timestamps describe the lab capture and must not be rewritten as historical incident timestamps.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:46:39.642005+00:00\nAnswer event: 855a3448-8b0f-4438-bc6e-840f277128c6	2026-10-28 15:46:39.872827	2026-10-28 15:46:39.872827	2	2	\N
391	cf0a027f-5707-4142-848d-abc61443d2be	The body hash comparison matches movement brief v3.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:41:53.785921+00:00\nAnswer event: 9cc6ec6b-4402-4dc8-84f5-aaf886e3aaed	2026-10-28 15:41:54.780965	2026-10-28 15:41:54.780965	2	2	\N
394	e756b339-ec9e-428e-89b7-9dfb54a94b28	WS-31 endpoint collection stopped at 08:50:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:42:56.159959+00:00\nAnswer event: b053a444-2a3e-4621-a5c8-d054aae632bd	2026-10-28 15:42:56.789931	2026-10-28 15:42:56.789931	2	2	\N
397	2f7cab66-a31c-42f3-9637-69c2150621c1	The native process event names browser.exe as the parent training surrogate.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:43:39.288012+00:00\nAnswer event: 1bc14623-283b-49a0-8f59-d1970a816a99	2026-10-28 15:43:39.467934	2026-10-28 15:43:39.467934	2	2	\N
401	cd111a84-ed56-42ff-8a2e-23a80e106146	Task inventory alone does not establish execution on WS-31. Further collection would be required.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T15:44:21.715739+00:00\nAnswer event: 380e8970-8952-49bc-babc-4a2db6a45faf	2026-10-28 15:44:22.572951	2026-10-28 15:44:22.572951	2	2	\N
403	7447f823-bf91-4b3a-b2ea-f0fdfbc25013	The DLP upload timestamp is 09:06:00 UTC.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:46:27.455968+00:00\nAnswer event: d2349e63-5b81-472b-92ba-7a56745ecb38	2026-10-28 15:46:28.307316	2026-10-28 15:46:28.307316	2	2	\N
406	544b217d-e3a1-4e21-9cee-ded78d40fc27	Volatility recovered viewer PID 6364 at kernel virtual offset 0xc98352279080.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:47:15.734338+00:00\nAnswer event: 4ed65e49-8518-4907-a12a-af59fa137acd	2026-10-28 15:47:16.177903	2026-10-28 15:47:16.177903	2	2	\N
409	7a181f84-d035-497c-9cdc-a333371019d0	Native Security record 606 records viewer PID 6364.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T15:47:47.652285+00:00\nAnswer event: cfb6c066-1282-4019-8424-859af143a1db	2026-10-28 15:47:48.607666	2026-10-28 15:47:48.607666	2	2	\N
410	8fadda67-bbfe-4b7d-96f0-30bca1809969	The recovered parent process name is browser.exe; it is a training surrogate.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:47:50.559754+00:00\nAnswer event: 6ab1c39e-ff04-490b-8caa-a1ba21791146	2026-10-28 15:47:50.891806	2026-10-28 15:47:50.891806	2	2	\N
411	5712924f-f267-4c59-a58a-ae9cdd7bdcfc	The other branch returns the text other version.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q3\nSolved by: BOO\nUTC: 2026-10-28T15:48:07.521287+00:00\nAnswer event: d170565c-6e27-4b12-a090-61a18f52f672	2026-10-28 15:48:08.601073	2026-10-28 15:48:08.601073	2	2	\N
412	d749e69f-0a89-491a-b5f7-641130462884	The input-3 branch returns the text cached v3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:48:16.514592+00:00\nAnswer event: 87e4566a-9ee4-4607-aa3b-47d8b8eb2378	2026-10-28 15:48:17.159765	2026-10-28 15:48:17.159765	2	2	\N
413	b275ab21-55ad-43b6-8bf1-ef9e34ade54a	The reconstructed task was registered at 23:22:01 UTC on 2026-09-15.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:48:27.640015+00:00\nAnswer event: e0304a42-2e54-4266-97f4-fa2ec5381927	2026-10-28 15:48:28.709621	2026-10-28 15:48:28.709621	2	2	\N
414	91daaadd-3a4c-4e93-a991-26afd66dacf7	The existence of a static branch does not establish that it executed during the incident.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:48:34.587702+00:00\nAnswer event: b3e4ff17-68e0-40b5-8146-7af9f10e95eb	2026-10-28 15:48:35.051905	2026-10-28 15:48:35.051905	2	2	\N
415	6ab6eef5-d1e7-4651-8cba-c29fb69154d8	The native process event names browser.exe as the parent training surrogate.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:49:44.947251+00:00\nAnswer event: 5067e7dd-b456-4cca-966a-301af9aded57	2026-10-28 15:49:45.842559	2026-10-28 15:49:45.842559	2	2	\N
416	bdbad930-ebda-4724-8fb8-675718c9dc6b	An HTTP acknowledgment does not prove a human read the transmitted body.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q4\nSolved by: BOO\nUTC: 2026-10-28T15:49:51.143962+00:00\nAnswer event: edfbb7ad-5645-47db-800e-3c701285ab15	2026-10-28 15:49:52.183035	2026-10-28 15:49:52.183035	2	2	\N
417	fa16a0aa-1c5b-4203-b069-36860cfb740d	The memory-derived command line contains cache argument C:/Temp/move-cache.txt.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q4\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:50:20.304897+00:00\nAnswer event: 0152fa7e-700b-4c6b-bbc4-b71e3385888d	2026-10-28 15:50:21.323636	2026-10-28 15:50:21.323636	2	2	\N
419	5e6c73ce-a06f-4901-bd15-e94e597fdb31	The matched payload supports transmission of movement brief v3.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q1\nSolved by: BOO\nUTC: 2026-10-28T15:51:22.971755+00:00\nAnswer event: b3773f9d-5a81-4ea0-b270-713a14ead906	2026-10-28 15:51:24.10142	2026-10-28 15:51:24.10142	2	2	\N
418	0ef89f9a-cb2a-4229-8ef1-8e3be306218a	The memory-derived command line contains cache argument C:/Temp/move-cache.txt.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:50:24.922490+00:00\nAnswer event: c5a66f13-8304-4241-98d8-4c1b49af6486	2026-10-28 15:50:25.67387	2026-10-28 15:50:25.67387	2	2	\N
424	892c996c-217c-4553-b867-78832247cf1c	The native snapshot records TCP remote port 443.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:52:29.146613+00:00\nAnswer event: 4269e357-5e73-4191-accc-1c670d8c291a	2026-10-28 15:52:29.712188	2026-10-28 15:52:29.712188	2	2	\N
429	da8b866e-4d5e-4d14-be25-f041b5dadb3f	The denied roster request does not establish successful roster disclosure.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q2\nSolved by: BOO\nUTC: 2026-10-28T15:55:00.532579+00:00\nAnswer event: 44e75ffe-eb61-4af3-82ee-68adc37acda6	2026-10-28 15:55:01.151446	2026-10-28 15:55:01.151446	2	2	\N
438	07aaca54-b69d-4455-a46e-9e0a1ffd49e8	Native Security record 607 records the BriefSync task.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T15:58:35.341373+00:00\nAnswer event: f6025c10-cfc0-4db6-b2f2-0483768057bf	2026-10-28 15:58:36.399885	2026-10-28 15:58:36.399885	2	2	\N
440	805e8ea1-c82a-46ed-936b-150e94d69ef9	An HTTP acknowledgment does not prove a human read the transmitted body.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:59:57.876616+00:00\nAnswer event: 114c4b10-c860-45aa-84b7-8bda669e2786	2026-10-28 15:59:58.923199	2026-10-28 15:59:58.923199	2	2	\N
443	11cf046a-c7a5-492a-b3d4-b8667ed89ef6	Acquisition timestamps describe the lab capture and must not be rewritten as historical incident timestamps.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T16:01:07.095804+00:00\nAnswer event: 16c61d48-7081-4bb9-ba00-4b861bbd9d8d	2026-10-28 16:01:07.253063	2026-10-28 16:01:07.253063	2	2	\N
446	8966052a-f34b-4223-b6c6-f39407e099a9	Volatility recovered viewer PID 6364 at kernel virtual offset 0xc98352279080.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T16:02:35.999415+00:00\nAnswer event: 23fefcd9-e9aa-4cba-a7db-8a8ff40653a8	2026-10-28 16:02:36.795643	2026-10-28 16:02:36.795643	2	2	\N
449	7d0cc59b-1cf0-4b6b-8944-c13fe05354df	The recovered parent process name is browser.exe; it is a training surrogate.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T16:03:27.030586+00:00\nAnswer event: 299468eb-ac50-49c3-9d6a-02573ee03d73	2026-10-28 16:03:27.681138	2026-10-28 16:03:27.681138	2	2	\N
454	b16503af-bbc9-4bc4-957a-3901fe275974	WS-31 endpoint collection stopped at 08:50:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T16:05:41.544343+00:00\nAnswer event: 55e37570-ae33-4a69-a997-3ecce32f7fdc	2026-10-28 16:05:42.549542	2026-10-28 16:05:42.549542	2	2	\N
457	dd62ba62-7437-49e4-90e1-d1972cdf3071	The training surrogate contains configuration path /upload.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:07:15.674570+00:00\nAnswer event: c6dbcde7-99e2-41ec-8852-a3009ee11f58	2026-10-28 16:07:16.505939	2026-10-28 16:07:16.505939	2	2	\N
459	880f2eb3-1ea4-46e3-a740-a107c65e3053	The supplied evidence does not establish adversary intent.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:09:31.507427+00:00\nAnswer event: 078a3f89-fc32-4d60-85bf-08398c07b2a9	2026-10-28 16:09:32.626421	2026-10-28 16:09:32.626421	2	2	\N
462	9faf0218-4ce2-473f-afbc-7b44722b1155	The denied roster request does not establish successful roster disclosure.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:10:19.493836+00:00\nAnswer event: 020151eb-57e8-43ae-90f5-491c28f6d770	2026-10-28 16:10:20.545939	2026-10-28 16:10:20.545939	2	2	\N
472	112951da-6be8-46c1-bfc2-4e0f64da5783	Native Security record 607 records the BriefSync task.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T16:16:22.004441+00:00\nAnswer event: 02bd1109-1413-4744-9620-15182ebec088	2026-10-28 16:16:22.944812	2026-10-28 16:16:22.944812	2	2	\N
477	46f6ef8b-9a18-4737-84c5-910b0f613e65	The recovered viewer process records parent PID 7644.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T16:19:07.709021+00:00\nAnswer event: 025bd1ea-e853-4d79-a4a9-c21b8ec61b24	2026-10-28 16:19:07.979365	2026-10-28 16:19:07.979365	2	2	\N
481	c7938842-50d1-4aeb-a5cb-ad07a3a72d0a	198.51.100.77 was a guest-local loopback address in this reconstruction; no Internet traffic occurred.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T16:22:56.236463+00:00\nAnswer event: 56ad1778-1417-4a0f-baf4-cc2cc5ada36f	2026-10-28 16:22:56.847955	2026-10-28 16:22:56.847955	2	2	\N
420	c3b6dec1-9ca2-4229-8c54-0968a4cc75c9	The guest's native connection snapshot records PID 6364.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:51:32.383389+00:00\nAnswer event: 476ba73f-1636-4606-881d-325a63c5df57	2026-10-28 15:51:33.598129	2026-10-28 15:51:33.598129	2	2	\N
423	4007d21b-be96-4f73-aea5-496fcf5f8d49	198.51.100.77 was a guest-local loopback address in this reconstruction; no Internet traffic occurred.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:52:20.744287+00:00\nAnswer event: 2843e216-5065-4cf5-96fb-2b06252e3320	2026-10-28 15:52:21.211546	2026-10-28 15:52:21.211546	2	2	\N
426	52d531b5-80c7-42b7-9656-06bd645b2f9b	The guest's native connection snapshot records PID 6364.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q1\nSolved by: Enterprise-1\nUTC: 2026-10-28T15:53:32.262842+00:00\nAnswer event: 6bce848a-e5a8-4e4b-a933-5d319947ee53	2026-10-28 15:53:32.464432	2026-10-28 15:53:32.464432	2	2	\N
428	ea57d254-b4b0-4be1-a520-c7ebf5701c00	The acquisition manifest maps this isolated lab reconstruction to WS-17; the original computer name is preserved.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T15:54:37.499653+00:00\nAnswer event: 09f1cb49-2a4a-4340-b70d-099a7babbe42	2026-10-28 15:54:38.435789	2026-10-28 15:54:38.435789	2	2	\N
432	da992ef4-d705-48bd-b99d-4e6166bad3a4	The reconstructed process was created at 23:22:00 UTC on 2026-09-15; no historic clock correction applies.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T15:55:34.882279+00:00\nAnswer event: 2762254d-3c22-4113-988b-d94d621caacd	2026-10-28 15:55:35.827541	2026-10-28 15:55:35.827541	2	2	\N
435	a742f48d-67b6-4e0b-b11a-6aa1f304fa64	The input-3 branch returns the text cached v3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:56:33.957896+00:00\nAnswer event: a80e7b96-8c77-4502-b861-9789afa299fc	2026-10-28 15:56:35.017911	2026-10-28 15:56:35.017911	2	2	\N
437	9d72fbab-e0d7-496b-bf1f-1fa759505002	The DLP upload timestamp is 09:06:00 UTC.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:58:19.861760+00:00\nAnswer event: 832699af-9bf4-4812-be4f-d397e4682010	2026-10-28 15:58:20.807399	2026-10-28 15:58:20.807399	2	2	\N
445	c7372b29-2ca3-4a85-ac18-7f4c5f792ce8	FINAL INCIDENT ASSESSMENT — LIMITED DISCLOSURE CONFIRMED. At 09:06 UTC, WS-17 transmitted a payload matching Patrol LANTERN movement brief v3 to 198.51.100.77 in req-72. V4 superseded the route at 09:10 UTC, but CEDAR remained unchanged, leaving an active check-in word exposed. The roster request was denied with HTTP 403 and zero body bytes. Session S-41 survived the password reset, but control of the session and adversary intent are not established. WS-31 remains unresolved because collection ended before execution could be determined. Required actions: rotate CEDAR, revoke S-41, isolate and preserve WS-17, collect WS-31, and monitor or block the external relay indicator.\n\nCompletion event: 38f841a4-9706-40d2-8b32-38553736c09b\nCompleted by: BOO	2026-10-28 16:02:22.184057	2026-10-28 16:02:22.184057	2	2	\N
448	be736aec-db93-4c12-a246-3d9c80c30dcc	WS-31 inventory contains a task named BriefSync, creating an unresolved scope lead.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T16:03:12.480214+00:00\nAnswer event: a9f3fefe-7a6b-43af-b101-d0d02b726e76	2026-10-28 16:03:13.202796	2026-10-28 16:03:13.202796	2	2	\N
451	6130d6ff-2f9b-4bc9-8979-c760a6d195f9	The other branch returns the text other version.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:04:32.756543+00:00\nAnswer event: 96be91ff-b47f-4384-90ea-f61c3a14432f	2026-10-28 16:04:33.629211	2026-10-28 16:04:33.629211	2	2	\N
461	07e4c057-0fe7-4eea-a1bd-bd65a081c205	The available inventory and collection gaps cannot clear WS-31.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:10:11.330234+00:00\nAnswer event: 183ec4f2-3f91-4fb3-b5b0-20adbeff714c	2026-10-28 16:10:12.109129	2026-10-28 16:10:12.109129	2	2	\N
467	e6434ed2-2c12-42e1-9e8b-94c4e67318e8	The documented WS-17 device offset is 120 seconds fast; normalized records must not receive a second correction.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T16:12:32.190274+00:00\nAnswer event: 690b09e7-7202-428f-bf66-ffcb66402f4b	2026-10-28 16:12:32.900365	2026-10-28 16:12:32.900365	2	2	\N
469	3e1f2d5e-d48b-4180-a112-7a94940a8b8a	The native process event names browser.exe as the parent training surrogate.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T16:14:12.671655+00:00\nAnswer event: 1a7fe049-fc27-4e1a-ad08-11e98206d4e8	2026-10-28 16:14:12.91772	2026-10-28 16:14:12.91772	2	2	\N
474	683fd569-6725-4893-97d1-02a042739fa0	The reconstructed task was registered at 23:22:01 UTC on 2026-09-15.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T16:17:25.300969+00:00\nAnswer event: 04216a5f-2383-464e-ab21-0ab69ec1cacc	2026-10-28 16:17:25.683253	2026-10-28 16:17:25.683253	2	2	\N
486	d0ada1f4-455a-472e-9908-c98465721fd3	Task inventory alone does not establish execution on WS-31. Further collection would be required.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:33:47.514315+00:00\nAnswer event: 3ca21147-ec58-4da0-93c1-41a3e7d75398	2026-10-28 16:33:47.935669	2026-10-28 16:33:47.935669	2	2	\N
421	6feab86e-9e20-45bc-ae0b-1aef8af4fab4	The classify_version example compares its input with integer 3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:51:55.436258+00:00\nAnswer event: 9e856ffd-4169-4c99-84cd-d35361a7ead4	2026-10-28 15:51:56.259404	2026-10-28 15:51:56.259404	2	2	\N
427	2bacfa41-cfb9-48ee-a4ea-0761514b23be	This is a live acquisition sidecar, not a validated memory connection finding or evidence of human reading.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:54:04.584512+00:00\nAnswer event: 29ff7993-7137-4172-a437-233c31802a79	2026-10-28 15:54:05.361233	2026-10-28 15:54:05.361233	2	2	\N
430	23f69acd-727f-4012-af87-1063ee7ed215	DOCS-1 audit collection has a gap beginning at 09:14:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:55:00.854982+00:00\nAnswer event: 3bf1c9bf-d0a2-4aea-8ee2-3ab4e02c46f5	2026-10-28 15:55:01.366925	2026-10-28 15:55:01.366925	2	2	\N
433	b998530b-50af-4ee9-9e8b-e14eb9a5589f	The DLP metadata links the supplied body to req-72.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:55:37.153408+00:00\nAnswer event: 505a81f0-f0e9-490e-8687-f5775fe0a1b6	2026-10-28 15:55:38.129826	2026-10-28 15:55:38.129826	2	2	\N
441	c32f9d6a-f14d-43e1-8fb8-045c1a1e264e	The reconstructed task was registered at 23:22:01 UTC on 2026-09-15.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T16:00:07.810067+00:00\nAnswer event: 88b07532-a68c-4462-9db7-bdec49390333	2026-10-28 16:00:08.356234	2026-10-28 16:00:08.356234	2	2	\N
452	b07df004-1ea5-4b05-904f-ef2bc32d00d8	The WS-31 inventory observation is timestamped 08:45:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T16:05:27.150679+00:00\nAnswer event: 8ca7da75-1c49-458e-b717-069fb538deb5	2026-10-28 16:05:27.532234	2026-10-28 16:05:27.532234	2	2	\N
455	7a5be937-29d2-464e-92e2-184147c20f92	Task inventory alone does not establish execution on WS-31. Further collection would be required.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T16:05:48.160535+00:00\nAnswer event: 890d5d16-ff51-4968-81c0-e7309fbccedb	2026-10-28 16:05:48.946534	2026-10-28 16:05:48.946534	2	2	\N
463	4172fbd1-7485-4525-9796-2c359358e3e1	The matched payload supports transmission of movement brief v3.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:10:30.574128+00:00\nAnswer event: c5b38485-2003-4dec-969a-d9045561c917	2026-10-28 16:10:30.97417	2026-10-28 16:10:30.97417	2	2	\N
465	41a4ad78-36f2-4392-bc6e-cffe6738a878	DOCS-1 audit collection has a gap beginning at 09:14:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T16:12:14.396944+00:00\nAnswer event: aa1860c2-6ebc-403d-a33a-c4ecdc108f4e	2026-10-28 16:12:14.912451	2026-10-28 16:12:14.912451	2	2	\N
468	d256e9fc-1bc9-4949-b985-010e05fd80bc	Native Security record 606 records viewer PID 6364.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T16:13:31.233381+00:00\nAnswer event: 1c069f27-e385-4643-b0ba-0af33161a404	2026-10-28 16:13:31.569353	2026-10-28 16:13:31.569353	2	2	\N
470	d37e753d-6e93-4918-9b7a-d3454d24dd0f	The acquisition manifest maps this isolated lab reconstruction to WS-17; the original computer name is preserved.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T16:14:39.632763+00:00\nAnswer event: 1dbcd3f2-9803-4aea-9592-a183068664eb	2026-10-28 16:14:39.819863	2026-10-28 16:14:39.819863	2	2	\N
475	34ef5172-4bda-406e-9d53-6fb5d7698085	Acquisition timestamps describe the lab capture and must not be rewritten as historical incident timestamps.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T16:17:44.463091+00:00\nAnswer event: d82cfa6e-d6e3-4ca0-9f1a-e4dbff7dd01a	2026-10-28 16:17:44.704417	2026-10-28 16:17:44.704417	2	2	\N
478	f22ddd84-b300-4f44-b7bd-528c262cf457	The recovered parent process name is browser.exe; it is a training surrogate.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T16:19:18.040398+00:00\nAnswer event: bebf7c73-fdf0-44d0-b592-9cb5f934e606	2026-10-28 16:19:18.56104	2026-10-28 16:19:18.56104	2	2	\N
479	1965ea42-9011-460c-8894-9d1f8bf8fe68	The memory-derived command line contains cache argument C:/Temp/move-cache.txt.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T16:21:58.371993+00:00\nAnswer event: 92a12336-4bef-46c7-974e-0be50d90aa19	2026-10-28 16:21:58.626173	2026-10-28 16:21:58.626173	2	2	\N
482	4c31fafb-3464-470b-805a-aad88f7c5673	The native snapshot records TCP remote port 443.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T16:23:03.994569+00:00\nAnswer event: dd5b7748-78ec-4371-862c-9b38049b344c	2026-10-28 16:23:04.340429	2026-10-28 16:23:04.340429	2	2	\N
514	aef7746f-eb35-4a66-b149-ab267cf8ad70	The matched payload supports transmission of movement brief v3.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T17:03:19.900146+00:00\nAnswer event: c105de22-5b46-4e11-a140-aba83bb0bda3	2026-10-28 17:03:20.430846	2026-10-28 17:03:20.430846	2	2	\N
422	7a27ce94-1301-493b-a42d-5ba746b450ce	The coverage record lists no network collection for WS-31.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T15:52:19.751292+00:00\nAnswer event: 6236b7ed-eba9-4b22-aba9-6730285ba5b1	2026-10-28 15:52:19.943395	2026-10-28 15:52:19.943395	2	2	\N
425	b2ba6af6-fbb1-42a5-91cf-ea10d056d2ab	The training surrogate contains destination string 198.51.100.77.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q1\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:53:10.928063+00:00\nAnswer event: 1080c2f2-0a32-491e-88f1-8e00d3de3464	2026-10-28 15:53:11.851562	2026-10-28 15:53:11.851562	2	2	\N
431	e6d4e6fe-1336-4e88-b80f-7a5c6fb0bbc4	DOCS-1 audit collection resumes at 09:18:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T15:55:16.052327+00:00\nAnswer event: a1d1dcb3-fe31-4db1-b18c-0ccbb0ce6c3c	2026-10-28 15:55:16.907086	2026-10-28 15:55:16.907086	2	2	\N
434	4615a58e-394e-463c-b44d-fc2072951674	The documented WS-17 device offset is 120 seconds fast; normalized records must not receive a second correction.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T15:56:19.063353+00:00\nAnswer event: 6191f951-aea6-4c7e-9bd7-ec44c1c28148	2026-10-28 15:56:19.513939	2026-10-28 15:56:19.513939	2	2	\N
436	13db6154-d8fc-445b-b803-62b2261fcb2a	The body hash comparison matches movement brief v3.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q2\nSolved by: westpoint graduates\nUTC: 2026-10-28T15:57:38.452698+00:00\nAnswer event: 1c90edc5-d25d-40d2-9647-ea0aeeb11b99	2026-10-28 15:57:38.635607	2026-10-28 15:57:38.635607	2	2	\N
439	efaf6c71-c2ce-4ce3-822a-14d6db12c8c0	The captured task XML targets the harmless brief-viewer.exe training surrogate.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T15:59:20.910850+00:00\nAnswer event: ce8608f6-e819-4152-bb7c-fdbf7a312e54	2026-10-28 15:59:21.784282	2026-10-28 15:59:21.784282	2	2	\N
442	362ba7f7-40c6-454c-9bb4-633ff6a329f6	The available inventory and collection gaps cannot clear WS-31.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q3\nSolved by: BOO\nUTC: 2026-10-28T16:00:17.499173+00:00\nAnswer event: 4bdcfc06-8eac-463e-b976-a6afc78faae6	2026-10-28 16:00:17.852108	2026-10-28 16:00:17.852108	2	2	\N
444	eaa57ec0-0bb0-4f72-ae8b-dd369869b49c	The supplied evidence does not establish adversary intent.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q4\nSolved by: BOO\nUTC: 2026-10-28T16:02:21.080647+00:00\nAnswer event: 38f841a4-9706-40d2-8b32-38553736c09b	2026-10-28 16:02:22.081569	2026-10-28 16:02:22.081569	2	2	\N
447	307a27da-5819-4f55-95ab-d3222bbd3cb3	The recovered viewer process records parent PID 7644.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T16:03:08.010086+00:00\nAnswer event: 07ba5cb9-e942-420a-b390-69347812eb92	2026-10-28 16:03:08.814928	2026-10-28 16:03:08.814928	2	2	\N
450	41964fd4-a564-430f-b3f3-cc667c622842	The memory-derived command line contains cache argument C:/Temp/move-cache.txt.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T16:03:55.061198+00:00\nAnswer event: ae6fe7a0-55b0-43e6-b41b-129e75a453f9	2026-10-28 16:03:55.477821	2026-10-28 16:03:55.477821	2	2	\N
453	58639ea8-8110-4150-a0da-af17227a2a5e	The supplied training surrogate performs no network calls; its strings are for static inspection.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:05:31.299283+00:00\nAnswer event: fbd7ce9e-f00d-46d6-93f6-2f8339f209cb	2026-10-28 16:05:32.092481	2026-10-28 16:05:32.092481	2	2	\N
456	28d2057c-aa1c-4abb-bd95-8fa097925c18	The existence of a static branch does not establish that it executed during the incident.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q4\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:06:03.843030+00:00\nAnswer event: 53bea327-b8e0-4dd6-88bb-9c167fb51df6	2026-10-28 16:06:04.551831	2026-10-28 16:06:04.551831	2	2	\N
458	f7cd6735-b92d-4329-9c19-d4e15f232ce5	The training surrogate contains task-label string BriefSync.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q3\nSolved by: westpoint graduates\nUTC: 2026-10-28T16:08:34.110277+00:00\nAnswer event: 8a704d3f-b811-437c-b29f-2d47a042db5e	2026-10-28 16:08:34.626249	2026-10-28 16:08:34.626249	2	2	\N
460	468f05f8-3fe7-4f08-b887-fc45ba96ea2a	The coverage record lists no network collection for WS-31.\nEvidence: wazuh/telemetry.jsonl (data.type:coverage)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T16:09:42.512467+00:00\nAnswer event: 917bab39-79b0-474b-8c3c-3111891c0a1c	2026-10-28 16:09:43.127067	2026-10-28 16:09:43.127067	2	2	\N
464	b434dd1f-1efa-4cf9-80fa-2f291fa1aa02	FINAL INCIDENT ASSESSMENT — LIMITED DISCLOSURE CONFIRMED. At 09:06 UTC, WS-17 transmitted a payload matching Patrol LANTERN movement brief v3 to 198.51.100.77 in req-72. V4 superseded the route at 09:10 UTC, but CEDAR remained unchanged, leaving an active check-in word exposed. The roster request was denied with HTTP 403 and zero body bytes. Session S-41 survived the password reset, but control of the session and adversary intent are not established. WS-31 remains unresolved because collection ended before execution could be determined. Required actions: rotate CEDAR, revoke S-41, isolate and preserve WS-17, collect WS-31, and monitor or block the external relay indicator.\n\nCompletion event: c5b38485-2003-4dec-969a-d9045561c917\nCompleted by: westpoint graduates	2026-10-28 16:10:31.088519	2026-10-28 16:10:31.088519	2	2	\N
466	5475ed15-dd38-4e1e-a121-0a60e14c6c25	DOCS-1 audit collection resumes at 09:18:00 UTC.\nEvidence: server/collection.txt (DOCS-1 unavailable interval)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T12-Q3\nSolved by: CHUDS\nUTC: 2026-10-28T16:12:24.940164+00:00\nAnswer event: 06adcb81-5b24-41fb-9785-35685ffe3ac4	2026-10-28 16:12:25.460922	2026-10-28 16:12:25.460922	2	2	\N
471	1f864eff-ac70-4a40-84d6-4fa3c00516a3	The reconstructed process was created at 23:22:00 UTC on 2026-09-15; no historic clock correction applies.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T16:15:33.008410+00:00\nAnswer event: bd77be3e-7908-4bbc-82c4-30175a155e24	2026-10-28 16:15:33.572591	2026-10-28 16:15:33.572591	2	2	\N
473	8f7d5b75-f7db-4ac3-b86c-bf9f7efb7120	The captured task XML targets the harmless brief-viewer.exe training surrogate.\nEvidence: prepared/windows-task.json (prepared/windows-task.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T14-Q2\nSolved by: CHUDS\nUTC: 2026-10-28T16:16:54.269093+00:00\nAnswer event: 804ccb7e-2433-45ba-ae99-e9b8cd3cb4cb	2026-10-28 16:16:55.427883	2026-10-28 16:16:55.427883	2	2	\N
483	23e240fa-8ad9-41bb-92c8-f5ec4f6cc0a0	This is a live acquisition sidecar, not a validated memory connection finding or evidence of human reading.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q4\nSolved by: CHUDS\nUTC: 2026-10-28T16:23:13.362560+00:00\nAnswer event: 90653968-13a9-4a97-8dbe-86073a6787a3	2026-10-28 16:23:13.8934	2026-10-28 16:23:13.8934	2	2	\N
484	05fab732-4042-4259-9828-a0e4745f50e7	The training surrogate contains destination string 198.51.100.77.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T16:26:15.355978+00:00\nAnswer event: 67f808d3-ac17-4f94-8021-91b980e56683	2026-10-28 16:26:16.474069	2026-10-28 16:26:16.474069	2	2	\N
485	9db247fe-538f-4117-9895-c6a4d0b30abd	WS-31 endpoint collection stopped at 08:50:00 UTC.\nEvidence: wazuh/telemetry.jsonl (data.host:WS-31)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T11-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:29:17.257188+00:00\nAnswer event: a3e66695-3329-412c-9703-c969dc56ef1b	2026-10-28 16:29:18.110941	2026-10-28 16:29:18.110941	2	2	\N
493	c920d7ff-cc07-4ce0-bffb-fe7f5f5d4724	The native snapshot records TCP remote port 443.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:41:26.807058+00:00\nAnswer event: e4f6f9bc-3b89-461d-9665-977920c67902	2026-10-28 16:41:27.056237	2026-10-28 16:41:27.056237	2	2	\N
496	1c7967b3-10c4-4c05-869c-e87466ee8c07	The training surrogate contains configuration path /upload.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T16:42:07.365215+00:00\nAnswer event: fbfcac08-cb70-4eb5-a745-7bc9dbd9d0a3	2026-10-28 16:42:07.917862	2026-10-28 16:42:07.917862	2	2	\N
498	9c517811-6341-4aa5-b719-295b7f3990c5	The supplied training surrogate performs no network calls; its strings are for static inspection.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T16:44:00.287403+00:00\nAnswer event: ff2dbac2-a092-4668-8cbf-be157f1bbd27	2026-10-28 16:44:00.817936	2026-10-28 16:44:00.817936	2	2	\N
476	0c3f86bc-5956-4197-b053-23102412edfe	Volatility recovered viewer PID 6364 at kernel virtual offset 0xc98352279080.\nEvidence: prepared/memory-processes.json (prepared/memory-processes.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T15-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T16:18:59.787669+00:00\nAnswer event: 71792b58-4cd4-4c58-bc5c-552d961b3399	2026-10-28 16:19:00.604706	2026-10-28 16:19:00.604706	2	2	\N
480	e4a6cd7a-48fc-459e-90f0-80a426039e0b	The guest's native connection snapshot records PID 6364.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q1\nSolved by: CHUDS\nUTC: 2026-10-28T16:22:46.911684+00:00\nAnswer event: 5e782125-6a3a-4526-8910-1a922d50a30d	2026-10-28 16:22:47.380692	2026-10-28 16:22:47.380692	2	2	\N
487	310e7cdd-c2ff-4e8a-a758-b28f55d0045b	The native process event names browser.exe as the parent training surrogate.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:35:52.192930+00:00\nAnswer event: 7f65e673-c230-42c4-9b9e-968af1208cd0	2026-10-28 16:35:52.667717	2026-10-28 16:35:52.667717	2	2	\N
489	7de89066-62ce-4642-8dbc-430f934b91c3	The reconstructed process was created at 23:22:00 UTC on 2026-09-15; no historic clock correction applies.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:37:52.302623+00:00\nAnswer event: ea80a083-43fd-4a3d-8d22-dec9090fc561	2026-10-28 16:37:52.957714	2026-10-28 16:37:52.957714	2	2	\N
490	78ea5fd6-489a-4b8b-8b21-fe34cb955d46	198.51.100.77 was a guest-local loopback address in this reconstruction; no Internet traffic occurred.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:40:43.748949+00:00\nAnswer event: 5baead6d-0e98-44a5-aec8-abf5eb0b904e	2026-10-28 16:40:44.081967	2026-10-28 16:40:44.081967	2	2	\N
494	bfa6c3dc-10d0-47df-967e-709914918864	198.51.100.77 was a guest-local loopback address in this reconstruction; no Internet traffic occurred.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T16:41:33.429535+00:00\nAnswer event: 85127186-cc3d-48c0-a6d1-a8df3e74050b	2026-10-28 16:41:34.457553	2026-10-28 16:41:34.457553	2	2	\N
499	2cd5e54b-f67d-4cba-9449-19cc655fbdb2	The guest's native connection snapshot records PID 6364.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:44:16.521538+00:00\nAnswer event: 07940d1c-e58b-4b27-9b58-3782f2100e22	2026-10-28 16:44:17.442959	2026-10-28 16:44:17.442959	2	2	\N
488	702ccdfa-0acd-4d65-ad87-988525dca11a	The acquisition manifest maps this isolated lab reconstruction to WS-17; the original computer name is preserved.\nEvidence: prepared/windows-process.json (prepared/windows-process.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T13-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:36:23.069016+00:00\nAnswer event: 59a89393-7a84-42f3-917e-aa9fb59b954a	2026-10-28 16:36:23.922619	2026-10-28 16:36:23.922619	2	2	\N
491	42fa1ac7-5210-457d-8a41-31048d100b38	The training surrogate contains destination string 198.51.100.77.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T16:40:58.581400+00:00\nAnswer event: 40936f11-4329-448b-807d-4bce2acf0642	2026-10-28 16:40:59.762259	2026-10-28 16:40:59.762259	2	2	\N
497	d74be02f-bbc2-445c-b57e-d5a9aaa5715c	The training surrogate contains task-label string BriefSync.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T16:43:29.836050+00:00\nAnswer event: af086978-6c59-4623-8fc7-b5c3f749b611	2026-10-28 16:43:30.638546	2026-10-28 16:43:30.638546	2	2	\N
492	d7a425d7-cbf9-4a66-a1c3-f36fcecf1642	The guest's native connection snapshot records PID 6364.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T16:41:05.039896+00:00\nAnswer event: d390c5a7-2ac2-488f-b235-3e31b8cf5f98	2026-10-28 16:41:06.27102	2026-10-28 16:41:06.27102	2	2	\N
495	654f193b-eaa0-4d85-893d-90fc8839c039	This is a live acquisition sidecar, not a validated memory connection finding or evidence of human reading.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:41:47.931571+00:00\nAnswer event: 7aa298a9-6b51-4845-9850-e27b3d9e835d	2026-10-28 16:41:48.092015	2026-10-28 16:41:48.092015	2	2	\N
500	1131fdca-3481-41f8-8943-35d664e5bd6e	The classify_version example compares its input with integer 3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T16:44:51.159281+00:00\nAnswer event: 0fed32d1-bb83-44ef-93a3-0c8c90ba71ef	2026-10-28 16:44:51.713779	2026-10-28 16:44:51.713779	2	2	\N
501	81d6ac33-1e51-48a5-892d-6a50ccbe9344	The input-3 branch returns the text cached v3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T16:45:39.112299+00:00\nAnswer event: 01ecad4d-bd1e-4ec3-9cea-8021601b7fab	2026-10-28 16:45:39.274693	2026-10-28 16:45:39.274693	2	2	\N
502	1a3450bb-962d-458b-bade-9d59c30109e3	The supplied training surrogate performs no network calls; its strings are for static inspection.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:46:22.335256+00:00\nAnswer event: 1348ee6e-2569-4ca9-a5e3-4c8e2bec95f7	2026-10-28 16:46:23.090387	2026-10-28 16:46:23.090387	2	2	\N
503	07e9563d-a520-4768-a23c-b80141ca976e	The other branch returns the text other version.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T16:46:22.742342+00:00\nAnswer event: d71f598a-ed4b-49e5-a888-bc89108ae651	2026-10-28 16:46:23.374811	2026-10-28 16:46:23.374811	2	2	\N
504	40f5f65e-0849-4301-9471-7608d7f90c97	The existence of a static branch does not establish that it executed during the incident.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T16:47:02.803725+00:00\nAnswer event: b45fb6f7-2441-416b-b85f-a4333537ae51	2026-10-28 16:47:03.832305	2026-10-28 16:47:03.832305	2	2	\N
505	0565da69-96a5-4ace-87a4-1025b60a7ed2	The DLP metadata links the supplied body to req-72.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q1\nSolved by: thingthing1\nUTC: 2026-10-28T16:49:40.279431+00:00\nAnswer event: 29662c97-7eed-45b1-9a5b-5ee3eb0832ee	2026-10-28 16:49:41.274006	2026-10-28 16:49:41.274006	2	2	\N
506	f7b49c0b-8eb9-470f-a0e7-a980dea4df2d	This is a live acquisition sidecar, not a validated memory connection finding or evidence of human reading.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T16:50:49.865974+00:00\nAnswer event: f4f8b567-39ff-4df6-8eed-e9178c614dfa	2026-10-28 16:50:50.244568	2026-10-28 16:50:50.244568	2	2	\N
507	c83e903f-92b9-41cd-962f-5b05ea191021	The body hash comparison matches movement brief v3.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T16:52:52.719619+00:00\nAnswer event: 168d7b9e-b837-4a41-8e72-b6bab4e6c13d	2026-10-28 16:52:53.165455	2026-10-28 16:52:53.165455	2	2	\N
508	37493baf-a5cc-47b2-8b7c-4f0e7aec600f	The DLP upload timestamp is 09:06:00 UTC.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T16:53:54.233647+00:00\nAnswer event: 2823faec-7252-46ec-ba60-d27afe4ed5be	2026-10-28 16:53:54.810697	2026-10-28 16:53:54.810697	2	2	\N
509	76df8a8a-3a42-4d7b-9aa4-f1b66cbd3497	The training surrogate contains destination string 198.51.100.77.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:54:10.323832+00:00\nAnswer event: b4830c02-55cd-4053-8b2a-b02967a51599	2026-10-28 16:54:11.482701	2026-10-28 16:54:11.482701	2	2	\N
510	dd8bfed1-e31b-4079-9085-590e82e4cd11	An HTTP acknowledgment does not prove a human read the transmitted body.\nEvidence: network/dlp-metadata.json (Open metadata and compare its sha256 with server/catalog.csv)\nLimitation: The supplied document or export supports only the stated comparison, not human receipt or adversary intent.\nQuestion: T19-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T16:54:42.985484+00:00\nAnswer event: 8965570b-cb5a-4b27-8e75-81a4c836d29c	2026-10-28 16:54:43.489351	2026-10-28 16:54:43.489351	2	2	\N
511	6d7a9918-90ac-4b2a-9c32-8366d0aa34d6	The classify_version example compares its input with integer 3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q1\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:55:01.194210+00:00\nAnswer event: 4301fb53-a221-4cbd-9041-c920295e049e	2026-10-28 16:55:02.108023	2026-10-28 16:55:02.108023	2	2	\N
512	11034430-506b-48ab-b691-92d74c106788	The training surrogate contains configuration path /upload.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T16:55:16.978684+00:00\nAnswer event: b0dbdf43-9d5b-445a-9aae-a63d633a6d93	2026-10-28 16:55:17.813543	2026-10-28 16:55:17.813543	2	2	\N
513	05f0adae-5c3d-41ee-bd3a-d2f30e7963c9	The native snapshot records TCP remote port 443.\nEvidence: prepared/windows-connections.json (prepared/windows-connections.json)\nLimitation: Isolated native training reconstruction with actual acquisition UTC. It does not replace the historical incident timeline. Consult the record provenance and original hash.\nQuestion: T16-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T16:57:44.311744+00:00\nAnswer event: 1173d1cd-519e-43b6-bf34-2ebbf48e23ea	2026-10-28 16:57:45.084384	2026-10-28 16:57:45.084384	2	2	\N
515	2ec0bfd2-7f1b-461a-8bb6-ea169cc80235	The training surrogate contains task-label string BriefSync.\nEvidence: binary/brief-viewer-training (Windows > Strings)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T17-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T17:04:05.655944+00:00\nAnswer event: d94ad930-083d-4e58-bf0c-3a5b7f925d21	2026-10-28 17:04:06.177981	2026-10-28 17:04:06.177981	2	2	\N
521	eb417ca6-1760-41aa-a992-0372ee3ea5a5	The other branch returns the text other version.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q3\nSolved by: MFKiLLG\nUTC: 2026-10-28T17:06:34.091839+00:00\nAnswer event: 58599f4a-6b23-4f29-b23c-f3a0b77136e3	2026-10-28 17:06:34.407789	2026-10-28 17:06:34.407789	2	2	\N
516	04de09d2-c7c1-4d8e-acb1-228c4c06f8b1	The denied roster request does not establish successful roster disclosure.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q2\nSolved by: thingthing1\nUTC: 2026-10-28T17:04:21.265824+00:00\nAnswer event: 23383453-f27e-43c5-bc31-272fff9dc7fa	2026-10-28 17:04:21.81182	2026-10-28 17:04:21.81182	2	2	\N
518	a9869cfc-6b9d-46c5-a3c2-f253b614b320	The supplied evidence does not establish adversary intent.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q4\nSolved by: thingthing1\nUTC: 2026-10-28T17:05:52.073202+00:00\nAnswer event: 68ecedfa-f7d4-4b9f-9df0-554b7ef2cad6	2026-10-28 17:05:52.830308	2026-10-28 17:05:52.830308	2	2	\N
517	f1c34a74-e062-4e0f-9f2d-d1f0803da440	The available inventory and collection gaps cannot clear WS-31.\nEvidence: wazuh/telemetry.jsonl (data.request:req-72)\nLimitation: Historical replay is not a live observation. Missing telemetry is not proof that an event did not occur.\nQuestion: T20-Q3\nSolved by: thingthing1\nUTC: 2026-10-28T17:05:37.082759+00:00\nAnswer event: a6fbd684-fc6e-44ea-8082-08e63b6f2597	2026-10-28 17:05:37.272158	2026-10-28 17:05:37.272158	2	2	\N
520	678af7cb-04be-4af3-ab49-32edc625eb52	The input-3 branch returns the text cached v3.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q2\nSolved by: MFKiLLG\nUTC: 2026-10-28T17:06:10.940735+00:00\nAnswer event: bb9e8a3e-da80-4603-bbec-fff393ef2156	2026-10-28 17:06:11.631434	2026-10-28 17:06:11.631434	2	2	\N
519	a5f23ec4-5a0f-45e0-864f-5c36459b6e83	FINAL INCIDENT ASSESSMENT — LIMITED DISCLOSURE CONFIRMED. At 09:06 UTC, WS-17 transmitted a payload matching Patrol LANTERN movement brief v3 to 198.51.100.77 in req-72. V4 superseded the route at 09:10 UTC, but CEDAR remained unchanged, leaving an active check-in word exposed. The roster request was denied with HTTP 403 and zero body bytes. Session S-41 survived the password reset, but control of the session and adversary intent are not established. WS-31 remains unresolved because collection ended before execution could be determined. Required actions: rotate CEDAR, revoke S-41, isolate and preserve WS-17, collect WS-31, and monitor or block the external relay indicator.\n\nCompletion event: 68ecedfa-f7d4-4b9f-9df0-554b7ef2cad6\nCompleted by: thingthing1	2026-10-28 17:05:52.951218	2026-10-28 17:05:52.951218	2	2	\N
522	3de36ab9-57a4-49e7-a037-e82e6e861075	The existence of a static branch does not establish that it executed during the incident.\nEvidence: binary/brief-viewer-training (Functions > classify_version)\nLimitation: This harmless training surrogate demonstrates static inspection, not behavior of an acquired incident executable.\nQuestion: T18-Q4\nSolved by: MFKiLLG\nUTC: 2026-10-28T17:06:42.215839+00:00\nAnswer event: 817c7c37-c86c-4091-998b-4fa30240af5c	2026-10-28 17:06:42.801759	2026-10-28 17:06:42.801759	2	2	\N
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact (id, contact_uuid, contact_name, contact_email, contact_role, contact_note, contact_work_phone, contact_mobile_phone, custom_attributes, client_id) FROM stdin;
\.


--
-- Data for Name: custom_attribute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_attribute (attribute_id, attribute_display_name, attribute_description, attribute_for, attribute_content) FROM stdin;
1	IOC	Defines default attributes for IOCs	ioc	{}
2	Events	Defines default attributes for Events	event	{}
3	Assets	Defines default attributes for Assets	asset	{}
4	Tasks	Defines default attributes for Tasks	task	{}
5	Notes	Defines default attributes for Notes	note	{}
6	Evidences	Defines default attributes for Evidences	evidence	{}
7	Cases	Defines default attributes for Cases	case	{}
8	Customers	Defines default attributes for Customers	client	{}
\.


--
-- Data for Name: data_store_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_store_file (file_id, file_uuid, file_original_name, file_local_name, file_description, file_date_added, file_tags, file_size, file_is_ioc, file_is_evidence, file_password, file_parent_id, file_sha256, added_by_user_id, modification_history, file_case_id) FROM stdin;
\.


--
-- Data for Name: data_store_path; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_store_path (path_id, path_uuid, path_name, path_parent_id, path_is_root, path_case_id) FROM stdin;
\.


--
-- Data for Name: event_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_category (id, name) FROM stdin;
1	Unspecified
2	Legitimate
3	Remediation
4	Initial Access
5	Execution
6	Persistence
7	Privilege Escalation
8	Defense Evasion
9	Credential Access
10	Discovery
11	Lateral Movement
12	Collection
13	Command and Control
14	Exfiltration
15	Impact
\.


--
-- Data for Name: event_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_comments (id, comment_id, comment_event_id) FROM stdin;
\.


--
-- Data for Name: evidence_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.evidence_comments (id, comment_id, comment_evidence_id) FROM stdin;
\.


--
-- Data for Name: evidence_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.evidence_type (id, name, description, creation_date, created_by_id) FROM stdin;
1	Unspecified	Unspecified	2026-10-27 21:39:38.12156	\N
2	HDD image - Generic	Generic copy of an hard drive	2026-10-27 21:39:38.124837	\N
3	HDD image - DD - Other	DD copy of an hard drive	2026-10-27 21:39:38.127065	\N
4	HDD image - DD - Windows	DD copy of an hard drive	2026-10-27 21:39:38.129224	\N
5	HDD image - DD - Unix	DD copy of an hard drive	2026-10-27 21:39:38.131338	\N
6	HDD image - DD - MacOS	DD copy of an hard drive	2026-10-27 21:39:38.133394	\N
7	HDD image - E01 - Other	E01 acquisition of an hard drive	2026-10-27 21:39:38.135484	\N
8	HDD image - E01 - Windows	E01 acquisition of an hard drive	2026-10-27 21:39:38.139564	\N
9	HDD image - E01 - Unix	E01 acquisition of an hard drive	2026-10-27 21:39:38.141717	\N
10	HDD image - E01 - MacOS	E01 acquisition of an hard drive	2026-10-27 21:39:38.143746	\N
11	HDD image - AFF4 - Other	AFF4 acquisition of an hard drive	2026-10-27 21:39:38.145953	\N
12	HDD image - AFF4 - Windows	AFF4 acquisition of an hard drive	2026-10-27 21:39:38.147999	\N
13	HDD image - AFF4 - Unix	AFF4 acquisition of an hard drive	2026-10-27 21:39:38.150087	\N
14	HDD image - AFF4 - MacOS	AFF4 acquisition of an hard drive	2026-10-27 21:39:38.152097	\N
15	SSD image - Generic	Generic copy of an solid state drive	2026-10-27 21:39:38.154174	\N
16	SSD image - DD - Other	DD copy of an solid state drive	2026-10-27 21:39:38.156231	\N
17	SSD image - DD - Windows	DD copy of an solid state drive	2026-10-27 21:39:38.158505	\N
18	SSD image - DD - Unix	DD copy of an solid state drive	2026-10-27 21:39:38.160803	\N
19	SSD image - DD - MacOS	DD copy of an solid state drive	2026-10-27 21:39:38.162853	\N
20	SSD image - E01 - Other	EO1 copy of a solid state drive	2026-10-27 21:39:38.164979	\N
21	SSD image - E01 - Windows	EO1 copy of a solid state drive	2026-10-27 21:39:38.167071	\N
22	SSD image - E01 - Unix	EO1 copy of a solid state drive	2026-10-27 21:39:38.169039	\N
23	SSD image - E01 - MacOS	EO1 copy of MacOS on a solid state drive	2026-10-27 21:39:38.171078	\N
24	SSD image - AFF4 - Other	AFF4 copy of an solid state drive	2026-10-27 21:39:38.173166	\N
25	SSD image - AFF4 - Windows	AFF4 copy of an solid state drive	2026-10-27 21:39:38.175176	\N
26	SSD image - AFF4 - Unix	AFF4 copy of an solid state drive	2026-10-27 21:39:38.177175	\N
27	SSD image - AFF4 - MacOS	AFF4 copy of an solid state drive	2026-10-27 21:39:38.179089	\N
28	VM image - Generic	Generic copy of a VM 	2026-10-27 21:39:38.181064	\N
29	VM image - Linux Server	Copy of a Linux Server VM	2026-10-27 21:39:38.183646	\N
30	VM image - Windows Server	Copy of a Windows Server VM	2026-10-27 21:39:38.186508	\N
31	Phone Image - Android	Copy of an Android phone	2026-10-27 21:39:38.1897	\N
32	Phone Image - iPhone	Copy of an iPhone	2026-10-27 21:39:38.194201	\N
33	Phone backup - Android (adb)	adb backup of an Android	2026-10-27 21:39:38.19803	\N
34	Phone backup - iPhone (iTunes)	iTunes backup of an iPhone	2026-10-27 21:39:38.201112	\N
35	Tablet Image - Android	Copy of an Android tablet	2026-10-27 21:39:38.204584	\N
36	Tablet Image - iPad	Copy of an iPad tablet	2026-10-27 21:39:38.207352	\N
37	Tablet backup - Android (adb)	adb backup of an Android tablet	2026-10-27 21:39:38.20989	\N
38	Tablet backup - iPad (iTunes)	iTunes backup of an iPad	2026-10-27 21:39:38.212093	\N
39	Collection - Velociraptor	Velociraptor collection	2026-10-27 21:39:38.214571	\N
40	Collection - ORC	ORC collection	2026-10-27 21:39:38.216822	\N
41	Collection - KAPE	KAPE collection	2026-10-27 21:39:38.219081	\N
42	Memory acquisition - Physical RAM	Physical RAM acquisition	2026-10-27 21:39:38.222016	\N
43	Memory acquisition - VMEM	vmem file	2026-10-27 21:39:38.225088	\N
44	Logs - Linux	Standard Linux logs	2026-10-27 21:39:38.227907	\N
45	Logs - Windows EVTX	Standard Windows EVTX logs	2026-10-27 21:39:38.230987	\N
46	Logs - Windows EVT	Standard Windows EVT logs	2026-10-27 21:39:38.233903	\N
47	Logs - MacOS	Standard MacOS logs	2026-10-27 21:39:38.23668	\N
48	Logs - Generic	Generic logs	2026-10-27 21:39:38.239405	\N
49	Logs - Firewall	Firewall logs	2026-10-27 21:39:38.242208	\N
50	Logs - Proxy	Proxy logs	2026-10-27 21:39:38.244862	\N
51	Logs - DNS	DNS logs	2026-10-27 21:39:38.247255	\N
52	Logs - Email	Email logs	2026-10-27 21:39:38.249782	\N
53	Executable - Windows (PE)	Generic Windows executable	2026-10-27 21:39:38.252197	\N
54	Executable - Linux (ELF)	Generic Linux executable	2026-10-27 21:39:38.25458	\N
55	Executable - MacOS (Mach-O)	Generic MacOS executable	2026-10-27 21:39:38.256875	\N
56	Executable - Generic	Generic executable	2026-10-27 21:39:38.259299	\N
57	Script - Generic	Generic script	2026-10-27 21:39:38.261683	\N
58	Generic - Data blob	Generic blob of data	2026-10-27 21:39:38.26429	\N
\.


--
-- Data for Name: global_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.global_tasks (id, task_uuid, task_title, task_description, task_tags, task_open_date, task_close_date, task_last_update, task_userid_open, task_userid_close, task_userid_update, task_assignee_id, task_status_id) FROM stdin;
\.


--
-- Data for Name: group_case_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.group_case_access (id, group_id, case_id, access_level) FROM stdin;
29	1	1	4
30	2	1	4
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (group_id, group_uuid, group_name, group_description, group_permissions, group_auto_follow, group_auto_follow_access_level) FROM stdin;
1	b948ad4a-2a9b-4eda-b3a3-fe509a1346a7	Administrators	Administrators	4095	t	4
2	1938dcd3-e5b2-415f-b227-b64ca3752a57	Analysts	Standard Analysts	1133	f	4
\.


--
-- Data for Name: ioc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ioc (ioc_id, ioc_uuid, ioc_value, ioc_type_id, ioc_description, ioc_tags, user_id, ioc_misp, ioc_tlp_id, custom_attributes, ioc_enrichment, modification_history) FROM stdin;
\.


--
-- Data for Name: ioc_asset_link; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ioc_asset_link (ioc_asset_link_id, ioc_id, asset_id) FROM stdin;
\.


--
-- Data for Name: ioc_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ioc_comments (id, comment_id, comment_ioc_id) FROM stdin;
\.


--
-- Data for Name: ioc_link; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ioc_link (ioc_link_id, ioc_id, case_id) FROM stdin;
\.


--
-- Data for Name: ioc_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ioc_type (type_id, type_name, type_description, type_taxonomy, type_validation_regex, type_validation_expect) FROM stdin;
1	AS	Autonomous system	\N	\N	\N
2	aba-rtn	ABA routing transit number	\N	\N	\N
3	account	Account of any type	\N	\N	\N
4	anonymised	Anonymised value - described with the anonymisation object via a relationship	\N	\N	\N
5	attachment	Attachment with external information	\N	\N	\N
6	authentihash	Authenticode executable signature hash	\N	\N	\N
7	boolean	Boolean value - to be used in objects	\N	\N	\N
8	btc	Bitcoin Address	\N	\N	\N
9	campaign-id	Associated campaign ID	\N	\N	\N
10	campaign-name	Associated campaign name	\N	\N	\N
11	cdhash	An Apple Code Directory Hash, identifying a code-signed Mach-O executable file	\N	\N	\N
12	chrome-extension-id	Chrome extension id	\N	\N	\N
13	community-id	a community ID flow hashing algorithm to map multiple traffic monitors into common flow id	\N	\N	\N
14	cookie	HTTP cookie as often stored on the user web client. This can include authentication cookie or session cookie.	\N	\N	\N
15	dash	Dash Address	\N	\N	\N
16	datetime	Datetime in the ISO 8601 format	\N	\N	\N
17	dkim	DKIM public key	\N	\N	\N
18	dkim-signature	DKIM signature	\N	\N	\N
19	dns-soa-email	RFC1035 mandates that DNS zones should have a SOA (Statement Of Authority) record that contains an email address where a PoC for the domain could be contacted. This can sometimes be used for attribution/linkage between different domains even if protected by whois privacy	\N	\N	\N
20	domain	A domain name used in the malware	\N	\N	\N
21	domain|ip	A domain name and its IP address (as found in DNS lookup) separated by a |	\N	\N	\N
22	email	An e-mail address	\N	\N	\N
23	email-attachment	File name of the email attachment.	\N	\N	\N
24	email-body	Email body	\N	\N	\N
25	email-dst	The destination email address. Used to describe the recipient when describing an e-mail.	\N	\N	\N
26	email-dst-display-name	Email destination display name	\N	\N	\N
27	email-header	Email header	\N	\N	\N
28	email-message-id	The email message ID	\N	\N	\N
29	email-mime-boundary	The email mime boundary separating parts in a multipart email	\N	\N	\N
30	email-reply-to	Email reply to header	\N	\N	\N
31	email-src	The source email address. Used to describe the sender when describing an e-mail.	\N	\N	\N
32	email-src-display-name	Email source display name	\N	\N	\N
33	email-subject	The subject of the email	\N	\N	\N
34	email-thread-index	The email thread index header	\N	\N	\N
35	email-x-mailer	Email x-mailer header	\N	\N	\N
36	favicon-mmh3	favicon-mmh3 is the murmur3 hash of a favicon as used in Shodan.	\N	\N	\N
37	filename	Filename	\N	\N	\N
38	filename-pattern	A pattern in the name of a file	\N	\N	\N
39	filename|authentihash	A checksum in md5 format	\N	\N	\N
40	filename|impfuzzy	Import fuzzy hash - a fuzzy hash created based on the imports in the sample.	\N	\N	\N
41	filename|imphash	Import hash - a hash created based on the imports in the sample.	\N	\N	\N
42	filename|md5	A filename and an md5 hash separated by a |	\N	\N	\N
43	filename|pehash	A filename and a PEhash separated by a |	\N	\N	\N
44	filename|sha1	A filename and an sha1 hash separated by a |	\N	\N	\N
45	filename|sha224	A filename and a sha-224 hash separated by a |	\N	\N	\N
46	filename|sha256	A filename and an sha256 hash separated by a |	\N	\N	\N
47	filename|sha3-224	A filename and an sha3-224 hash separated by a |	\N	\N	\N
48	filename|sha3-256	A filename and an sha3-256 hash separated by a |	\N	\N	\N
49	filename|sha3-384	A filename and an sha3-384 hash separated by a |	\N	\N	\N
50	filename|sha3-512	A filename and an sha3-512 hash separated by a |	\N	\N	\N
51	filename|sha384	A filename and a sha-384 hash separated by a |	\N	\N	\N
52	filename|sha512	A filename and a sha-512 hash separated by a |	\N	\N	\N
53	filename|sha512/224	A filename and a sha-512/224 hash separated by a |	\N	\N	\N
54	filename|sha512/256	A filename and a sha-512/256 hash separated by a |	\N	\N	\N
55	filename|ssdeep	A checksum in ssdeep format	\N	\N	\N
56	filename|tlsh	A filename and a Trend Micro Locality Sensitive Hash separated by a |	\N	\N	\N
57	filename|vhash	A filename and a VirusTotal hash separated by a |	\N	\N	\N
58	first-name	First name of a natural person	\N	\N	\N
59	float	A floating point value.	\N	\N	\N
60	full-name	Full name of a natural person	\N	\N	\N
61	gene	GENE - Go Evtx sigNature Engine	\N	\N	\N
62	git-commit-id	A git commit ID.	\N	\N	\N
63	github-organisation	A github organisation	\N	\N	\N
64	github-repository	A github repository	\N	\N	\N
65	github-username	A github user name	\N	\N	\N
66	hassh-md5	hassh is a network fingerprinting standard which can be used to identify specific Client SSH implementations. The fingerprints can be easily stored, searched and shared in the form of an MD5 fingerprint.	\N	\N	\N
67	hasshserver-md5	hasshServer is a network fingerprinting standard which can be used to identify specific Server SSH implementations. The fingerprints can be easily stored, searched and shared in the form of an MD5 fingerprint.	\N	\N	\N
68	hex	A value in hexadecimal format	\N	\N	\N
69	hostname	A full host/dnsname of an attacker	\N	\N	\N
70	hostname|port	Hostname and port number separated by a |	\N	\N	\N
71	http-method	HTTP method used by the malware (e.g. POST, GET, …).	\N	\N	\N
72	iban	International Bank Account Number	\N	\N	\N
73	identity-card-number	Identity card number	\N	\N	\N
74	impfuzzy	A fuzzy hash of import table of Portable Executable format	\N	\N	\N
75	imphash	Import hash - a hash created based on the imports in the sample.	\N	\N	\N
76	ip-any	A source or destination IP address of the attacker or C&C server	\N	\N	\N
77	ip-dst	A destination IP address of the attacker or C&C server	\N	\N	\N
78	ip-dst|port	IP destination and port number separated by a |	\N	\N	\N
79	ip-src	A source IP address of the attacker	\N	\N	\N
80	ip-src|port	IP source and port number separated by a |	\N	\N	\N
81	ja3-fingerprint-md5	JA3 is a method for creating SSL/TLS client fingerprints that should be easy to produce on any platform and can be easily shared for threat intelligence.	\N	\N	\N
82	jabber-id	Jabber ID	\N	\N	\N
83	jarm-fingerprint	JARM is a method for creating SSL/TLS server fingerprints.	\N	\N	\N
84	kusto-query	Kusto query - Kusto from Microsoft Azure is a service for storing and running interactive analytics over Big Data.	\N	\N	\N
85	link	Link to an external information	\N	\N	\N
86	mac-address	Mac address	\N	\N	\N
87	mac-eui-64	Mac EUI-64 address	\N	\N	\N
88	malware-sample	Attachment containing encrypted malware sample	\N	\N	\N
89	malware-type	Malware type	\N	\N	\N
90	md5	A checksum in md5 format	\N	\N	\N
91	middle-name	Middle name of a natural person	\N	\N	\N
92	mime-type	A media type (also MIME type and content type) is a two-part identifier for file formats and format contents transmitted on the Internet	\N	\N	\N
93	mobile-application-id	The application id of a mobile application	\N	\N	\N
94	mutex	Mutex, use the format \\BaseNamedObjects<Mutex>	\N	\N	\N
95	named pipe	Named pipe, use the format .\\pipe<PipeName>	\N	\N	\N
96	other	Other attribute	\N	\N	\N
97	file-path	Path of file	\N	\N	\N
98	pattern-in-file	Pattern in file that identifies the malware	\N	\N	\N
99	pattern-in-memory	Pattern in memory dump that identifies the malware	\N	\N	\N
100	pattern-in-traffic	Pattern in network traffic that identifies the malware	\N	\N	\N
101	pdb	Microsoft Program database (PDB) path information	\N	\N	\N
102	pehash	PEhash - a hash calculated based of certain pieces of a PE executable file	\N	\N	\N
103	pgp-private-key	A PGP private key	\N	\N	\N
104	pgp-public-key	A PGP public key	\N	\N	\N
105	phone-number	Telephone Number	\N	\N	\N
106	port	Port number	\N	\N	\N
107	process-state	State of a process	\N	\N	\N
108	prtn	Premium-Rate Telephone Number	\N	\N	\N
109	regkey	Registry key or value	\N	\N	\N
110	regkey|value	Registry value + data separated by |	\N	\N	\N
111	sha1	A checksum in sha1 format	\N	\N	\N
112	sha224	A checksum in sha-224 format	\N	\N	\N
113	sha256	A checksum in sha256 format	\N	\N	\N
114	sha3-224	A checksum in sha3-224 format	\N	\N	\N
115	sha3-256	A checksum in sha3-256 format	\N	\N	\N
116	sha3-384	A checksum in sha3-384 format	\N	\N	\N
117	sha3-512	A checksum in sha3-512 format	\N	\N	\N
118	sha384	A checksum in sha-384 format	\N	\N	\N
119	sha512	A checksum in sha-512 format	\N	\N	\N
120	sha512/224	A checksum in the sha-512/224 format	\N	\N	\N
121	sha512/256	A checksum in the sha-512/256 format	\N	\N	\N
122	sigma	Sigma - Generic Signature Format for SIEM Systems	\N	\N	\N
123	size-in-bytes	Size expressed in bytes	\N	\N	\N
124	snort	An IDS rule in Snort rule-format	\N	\N	\N
125	ssdeep	A checksum in ssdeep format	\N	\N	\N
126	ssh-fingerprint	A fingerprint of SSH key material	\N	\N	\N
127	stix2-pattern	STIX 2 pattern	\N	\N	\N
128	target-email	Attack Targets Email(s)	\N	\N	\N
129	target-external	External Target Organizations Affected by this Attack	\N	\N	\N
130	target-location	Attack Targets Physical Location(s)	\N	\N	\N
131	target-machine	Attack Targets Machine Name(s)	\N	\N	\N
132	target-org	Attack Targets Department or Organization(s)	\N	\N	\N
133	target-user	Attack Targets Username(s)	\N	\N	\N
134	telfhash	telfhash is symbol hash for ELF files, just like imphash is imports hash for PE files.	\N	\N	\N
135	text	Name, ID or a reference	\N	\N	\N
136	threat-actor	A string identifying the threat actor	\N	\N	\N
137	tlsh	A checksum in the Trend Micro Locality Sensitive Hash format	\N	\N	\N
138	travel-details	Travel details	\N	\N	\N
139	twitter-id	Twitter ID	\N	\N	\N
140	uri	Uniform Resource Identifier	\N	\N	\N
141	url	url	\N	\N	\N
142	user-agent	The user-agent used by the malware in the HTTP request.	\N	\N	\N
143	vhash	A VirusTotal checksum	\N	\N	\N
144	vulnerability	A reference to the vulnerability used in the exploit	\N	\N	\N
145	weakness	A reference to the weakness used in the exploit	\N	\N	\N
146	whois-creation-date	The date of domain’s creation, obtained from the WHOIS information.	\N	\N	\N
147	whois-registrant-email	The e-mail of a domain’s registrant, obtained from the WHOIS information.	\N	\N	\N
148	whois-registrant-name	The name of a domain’s registrant, obtained from the WHOIS information.	\N	\N	\N
149	whois-registrant-org	The org of a domain’s registrant, obtained from the WHOIS information.	\N	\N	\N
150	whois-registrant-phone	The phone number of a domain’s registrant, obtained from the WHOIS information.	\N	\N	\N
151	whois-registrar	The registrar of the domain, obtained from the WHOIS information.	\N	\N	\N
152	windows-scheduled-task	A scheduled task in windows	\N	\N	\N
153	windows-service-displayname	A windows service’s displayname, not to be confused with the windows-service-name. This is the name that applications will generally display as the service’s name in applications.	\N	\N	\N
154	windows-service-name	A windows service name. This is the name used internally by windows. Not to be confused with the windows-service-displayname.	\N	\N	\N
155	x509-fingerprint-md5	X509 fingerprint in MD5 format	\N	\N	\N
156	x509-fingerprint-sha1	X509 fingerprint in SHA-1 format	\N	\N	\N
157	x509-fingerprint-sha256	X509 fingerprint in SHA-256 format	\N	\N	\N
158	xmr	Monero Address	\N	\N	\N
159	yara	Yara signature	\N	\N	\N
160	zeek	An NIDS rule in the Zeek rule-format	\N	\N	\N
\.


--
-- Data for Name: iris_hooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_hooks (id, hook_name, hook_description) FROM stdin;
1	on_postload_alert_create	Triggered on alert creation, after commit in DB
2	on_postload_alert_delete	Triggered on alert deletion, after commit in DB
3	on_postload_alert_update	Triggered on alert update, after commit in DB
4	on_postload_alert_resolution_update	Triggered on alert resolution update, after commit in DB
5	on_postload_alert_status_update	Triggered on alert status update, after commit in DB
6	on_postload_alert_escalate	Triggered on alert escalation, after commit in DB
7	on_postload_alert_merge	Triggered on alert merge, after commit in DB
8	on_postload_alert_unmerge	Triggered on alert unmerge, after commit in DB
9	on_manual_trigger_alert	Triggered upon user action
10	on_preload_case_create	Triggered on case creation, before commit in DB
11	on_postload_case_create	Triggered on case creation, after commit in DB
12	on_preload_case_delete	Triggered on case deletion, before commit in DB
13	on_postload_case_delete	Triggered on case deletion, after commit in DB
14	on_postload_case_update	Triggered on case update, after commit in DB
15	on_manual_trigger_case	Triggered upon user action
16	on_preload_asset_create	Triggered on asset creation, before commit in DB
17	on_postload_asset_create	Triggered on asset creation, after commit in DB
18	on_preload_asset_update	Triggered on asset update, before commit in DB
19	on_postload_asset_update	Triggered on asset update, after commit in DB
20	on_preload_asset_delete	Triggered on asset deletion, before commit in DB
21	on_postload_asset_delete	Triggered on asset deletion, after commit in DB
22	on_manual_trigger_asset	Triggered upon user action
23	on_preload_note_create	Triggered on note creation, before commit in DB
24	on_postload_note_create	Triggered on note creation, after commit in DB
25	on_preload_note_update	Triggered on note update, before commit in DB
26	on_postload_note_update	Triggered on note update, after commit in DB
27	on_preload_note_delete	Triggered on note deletion, before commit in DB
28	on_postload_note_delete	Triggered on note deletion, after commit in DB
29	on_manual_trigger_note	Triggered upon user action
30	on_preload_ioc_create	Triggered on ioc creation, before commit in DB
31	on_postload_ioc_create	Triggered on ioc creation, after commit in DB
32	on_preload_ioc_update	Triggered on ioc update, before commit in DB
33	on_postload_ioc_update	Triggered on ioc update, after commit in DB
34	on_preload_ioc_delete	Triggered on ioc deletion, before commit in DB
35	on_postload_ioc_delete	Triggered on ioc deletion, after commit in DB
36	on_manual_trigger_ioc	Triggered upon user action
37	on_preload_event_create	Triggered on event creation, before commit in DB
38	on_postload_event_create	Triggered on event creation, after commit in DB
39	on_preload_event_duplicate	Triggered on event duplication, before commit in DB
40	on_preload_event_update	Triggered on event update, before commit in DB
41	on_postload_event_update	Triggered on event update, after commit in DB
42	on_preload_event_delete	Triggered on event deletion, before commit in DB
43	on_postload_event_delete	Triggered on event deletion, after commit in DB
44	on_manual_trigger_event	Triggered upon user action
45	on_preload_evidence_create	Triggered on evidence creation, before commit in DB
46	on_postload_evidence_create	Triggered on evidence creation, after commit in DB
47	on_preload_evidence_update	Triggered on evidence update, before commit in DB
48	on_postload_evidence_update	Triggered on evidence update, after commit in DB
49	on_preload_evidence_delete	Triggered on evidence deletion, before commit in DB
50	on_postload_evidence_delete	Triggered on evidence deletion, after commit in DB
51	on_manual_trigger_evidence	Triggered upon user action
52	on_preload_task_create	Triggered on task creation, before commit in DB
53	on_postload_task_create	Triggered on task creation, after commit in DB
54	on_preload_task_update	Triggered on task update, before commit in DB
55	on_postload_task_update	Triggered on task update, after commit in DB
56	on_preload_task_delete	Triggered on task deletion, before commit in DB
57	on_postload_task_delete	Triggered on task deletion, after commit in DB
58	on_manual_trigger_task	Triggered upon user action
59	on_preload_global_task_create	Triggered on global task creation, before commit in DB
60	on_postload_global_task_create	Triggered on global task creation, after commit in DB
61	on_preload_global_task_update	Triggered on task update, before commit in DB
62	on_postload_global_task_update	Triggered on global task update, after commit in DB
63	on_preload_global_task_delete	Triggered on task deletion, before commit in DB
64	on_postload_global_task_delete	Triggered on global task deletion, after commit in DB
65	on_manual_trigger_global_task	Triggered upon user action
66	on_preload_report_create	Triggered on report creation, before generation in DB
67	on_postload_report_create	Triggered on report creation, before download of the document
68	on_preload_activities_report_create	Triggered on activities report creation, before generation in DB
69	on_postload_activities_report_create	Triggered on activities report creation, before download of the document
70	on_postload_asset_commented	Triggered on event commented, after commit in DB
71	on_postload_asset_comment_update	Triggered on event comment update, after commit in DB
72	on_postload_asset_comment_delete	Triggered on event comment deletion, after commit in DB
73	on_postload_evidence_commented	Triggered on evidence commented, after commit in DB
74	on_postload_evidence_comment_update	Triggered on evidence comment update, after commit in DB
75	on_postload_evidence_comment_delete	Triggered on evidence comment deletion, after commit in DB
76	on_postload_task_commented	Triggered on task commented, after commit in DB
77	on_postload_task_comment_update	Triggered on task comment update, after commit in DB
78	on_postload_task_comment_delete	Triggered on task comment deletion, after commit in DB
79	on_postload_ioc_commented	Triggered on IOC commented, after commit in DB
80	on_postload_ioc_comment_update	Triggered on IOC comment update, after commit in DB
81	on_postload_ioc_comment_delete	Triggered on IOC comment deletion, after commit in DB
82	on_postload_event_commented	Triggered on event commented, after commit in DB
83	on_postload_event_comment_update	Triggered on event comment update, after commit in DB
84	on_postload_event_comment_delete	Triggered on event comment deletion, after commit in DB
85	on_postload_note_commented	Triggered on note commented, after commit in DB
86	on_postload_note_comment_update	Triggered on note comment update, after commit in DB
87	on_postload_note_comment_delete	Triggered on note comment deletion, after commit in DB
88	on_postload_alert_commented	Triggered on alert commented, after commit in DB
89	on_postload_alert_comment_update	Triggered on alert comment update, after commit in DB
90	on_postload_alert_comment_delete	Triggered on alert comment deletion, after commit in DB
\.


--
-- Data for Name: iris_module; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_module (id, added_by_id, module_human_name, module_name, module_description, module_version, interface_version, date_added, is_active, has_pipeline, pipeline_args, module_config, module_type) FROM stdin;
1	1	IrisVT	iris_vt_module	Provides an interface between VirusTotal and IRIS	1.2.1	1.2.0	2026-10-27 21:39:38.719106	f	f	{}	[{"param_name": "vt_api_key", "param_human_name": "VT API Key", "param_description": "API key to use to communicate with VT", "default": null, "mandatory": true, "type": "sensitive_string"}, {"param_name": "vt_key_is_premium", "param_human_name": "VT Key is premium", "param_description": "Set to True if the VT key is premium", "default": false, "mandatory": true, "type": "bool", "value": false}, {"param_name": "vt_manual_hook_enabled", "param_human_name": "Manual triggers on IOCs", "param_description": "Set to True to offers possibility to manually triggers the module via the UI", "default": true, "mandatory": true, "type": "bool", "section": "Triggers", "value": true}, {"param_name": "vt_on_update_hook_enabled", "param_human_name": "Triggers automatically on IOC update", "param_description": "Set to True to automatically add a VT insight each time an IOC is updated", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "vt_on_create_hook_enabled", "param_human_name": "Triggers automatically on IOC create", "param_description": "Set to True to automatically add a VT insight each time an IOC is created", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "vt_ip_assign_asn_as_tag", "param_human_name": "Assign ASN tag to IP", "param_description": "Assign a new tag to IOC IPs with the ASN fetched from VT", "default": true, "mandatory": true, "type": "bool", "section": "Insights", "value": true}, {"param_name": "vt_tag_malicious_threshold", "param_human_name": "IOC tag malicious threshold", "param_description": "Tag the IOC has malicious if the percentage of detection is above the specified threshold", "default": "10", "mandatory": true, "type": "float", "section": "Insights", "value": "10"}, {"param_name": "vt_tag_suspicious_threshold", "param_human_name": "IOC tag suspicious threshold", "param_description": "Tag the IOC has suspicious if the percentage of detection is above the specified threshold", "default": "5", "mandatory": true, "type": "float", "section": "Insights", "value": "5"}, {"param_name": "vt_report_as_attribute", "param_human_name": "Add VT report as new IOC attribute", "param_description": "Creates a new attribute on the IOC, base on the VT report. Attributes are based on the templates of this configuration", "default": true, "mandatory": true, "type": "bool", "section": "Insights", "value": true}, {"param_name": "vt_domain_report_template", "param_human_name": "Domain report template", "param_description": "Domain reports template used to add a new custom attribute to the target IOC", "default": "{% if nb_detected_urls %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected URLS</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected URLs</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_urls }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_urls_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n{% if nb_detected_samples %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected samples</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected samples</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_samples }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_samples_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n            {% if whois %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_wh\\" data-toggle=\\"collapse\\" data-target=\\"#drop_whois\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-user-6\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        WHOIS\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_whois\\" class=\\"collapse\\" aria-labelledby=\\"drop_wh\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <blockquote class=\\"blockquote\\">\\n                            {% autoescape false %}\\n                            <p>{{ whois| replace(\\"\\\\n\\", \\"<br/>\\") }}</p>\\n                            {% endautoescape %}\\n                        </blockquote>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n    \\n            {% if resolutions %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_res\\" data-toggle=\\"collapse\\" data-target=\\"#drop_resolutions\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Resolutions history\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_resolutions\\" class=\\"collapse\\" aria-labelledby=\\"drop_res\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for resolution in resolutions %} \\n                            <li>{{resolution.ip_address}} ( Last resolved on {{resolution.last_resolved}} )</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n            {% if subdomains %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_sub\\" data-toggle=\\"collapse\\" data-target=\\"#drop_subdomains\\" aria-expanded=\\"false\\" aria-controls=\\"drop_subdomains\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-diagram\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Subdomains\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_subdomains\\" class=\\"collapse\\" aria-labelledby=\\"drop_sub\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for subdomain in subdomains %} \\n                            <li>{{subdomain}}</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n</script>", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "{% if nb_detected_urls %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected URLS</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected URLs</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_urls }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_urls_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n{% if nb_detected_samples %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected samples</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected samples</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_samples }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_samples_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n            {% if whois %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_wh\\" data-toggle=\\"collapse\\" data-target=\\"#drop_whois\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-user-6\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        WHOIS\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_whois\\" class=\\"collapse\\" aria-labelledby=\\"drop_wh\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <blockquote class=\\"blockquote\\">\\n                            {% autoescape false %}\\n                            <p>{{ whois| replace(\\"\\\\n\\", \\"<br/>\\") }}</p>\\n                            {% endautoescape %}\\n                        </blockquote>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n    \\n            {% if resolutions %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_res\\" data-toggle=\\"collapse\\" data-target=\\"#drop_resolutions\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Resolutions history\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_resolutions\\" class=\\"collapse\\" aria-labelledby=\\"drop_res\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for resolution in resolutions %} \\n                            <li>{{resolution.ip_address}} ( Last resolved on {{resolution.last_resolved}} )</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n            {% if subdomains %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_sub\\" data-toggle=\\"collapse\\" data-target=\\"#drop_subdomains\\" aria-expanded=\\"false\\" aria-controls=\\"drop_subdomains\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-diagram\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Subdomains\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_subdomains\\" class=\\"collapse\\" aria-labelledby=\\"drop_sub\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for subdomain in subdomains %} \\n                            <li>{{subdomain}}</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n</script>"}, {"param_name": "vt_ip_report_template", "param_human_name": "IP report template", "param_description": "IP report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Basic information</h3>\\n        <dl class=\\"row\\">\\n            {% if results.as_owner %}\\n            <dt class=\\"col-sm-3\\">AS owner</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.as_owner }}</dd>\\n            {% endif %}\\n            \\n            {% if country %}\\n            <dt class=\\"col-sm-3\\">Country</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.country }}</dd>\\n            {% endif %}\\n        </dl>\\n    </div>\\n</div>    \\n\\n{% if nb_detected_urls %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected URLS</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected URLs</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_urls }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_urls_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n{% if nb_detected_samples %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected communicating samples</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected samples</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_samples }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_samples_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.resolutions %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_res\\" data-toggle=\\"collapse\\" data-target=\\"#drop_resolutions\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Resolutions history\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_resolutions\\" class=\\"collapse\\" aria-labelledby=\\"drop_res\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for resolution in results.resolutions %} \\n                            <li>{{ resolution.hostname }} ( Last resolved on {{resolution.last_resolved}} )</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n</script>", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Basic information</h3>\\n        <dl class=\\"row\\">\\n            {% if results.as_owner %}\\n            <dt class=\\"col-sm-3\\">AS owner</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.as_owner }}</dd>\\n            {% endif %}\\n            \\n            {% if country %}\\n            <dt class=\\"col-sm-3\\">Country</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.country }}</dd>\\n            {% endif %}\\n        </dl>\\n    </div>\\n</div>    \\n\\n{% if nb_detected_urls %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected URLS</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected URLs</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_urls }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_urls_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n{% if nb_detected_samples %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected communicating samples</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected samples</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_samples }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_samples_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.resolutions %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_res\\" data-toggle=\\"collapse\\" data-target=\\"#drop_resolutions\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Resolutions history\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_resolutions\\" class=\\"collapse\\" aria-labelledby=\\"drop_res\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for resolution in results.resolutions %} \\n                            <li>{{ resolution.hostname }} ( Last resolved on {{resolution.last_resolved}} )</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n</script>"}, {"param_name": "vt_hash_report_template", "param_human_name": "Hash report template", "param_description": "Hash report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Basic information</h3>\\n        <dl class=\\"row\\">\\n            {% if results.total %}\\n            <dt class=\\"col-sm-3\\">Detection</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.positives }} / {{ results.total }}</dd>\\n            {% endif %}\\n            \\n            {% if results.permalink %}\\n            <dt class=\\"col-sm-3\\">Permalink</dt>\\n            <dd class=\\"col-sm-9\\"><a href='{{ results.permalink }}'>{{ results.permalink }}</a></dd>\\n            {% endif %}\\n            \\n            \\n            {% if results.scan_date %}\\n            <dt class=\\"col-sm-3\\">Scan date</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.scan_date }}</dd>\\n            {% endif %}\\n            \\n            {% if results.md5 %}\\n            <dt class=\\"col-sm-3\\">MD5</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.md5 }}</dd>\\n            {% endif %}\\n            \\n            {% if results.sha256 %}\\n            <dt class=\\"col-sm-3\\">SHA256</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.sha256 }}</dd>\\n            {% endif %}\\n        \\n        </dl>\\n    </div>\\n</div>    \\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.scans %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_sc\\" data-toggle=\\"collapse\\" data-target=\\"#drop_scans\\" aria-expanded=\\"false\\" aria-controls=\\"drop_scans\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Scans results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_scans\\" class=\\"collapse\\" aria-labelledby=\\"drop_sc\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"vt_in_scans\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Engine</th>\\n                                      <th>Detected</th>\\n                                      <th>Result</th>\\n                                      <th>Update</th>\\n                                      <th>Version</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for scan in results.scans %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ scan }}</td>\\n                                        <td>{{ results.scans[scan].detected }}</td>\\n                                        <td>{{ results.scans[scan].result }}</td>\\n                                        <td>{{ results.scans[scan].update }}</td>\\n                                        <td>{{ results.scans[scan].version }}</td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n\\n{% if results.scans %}\\n$(\\"#vt_in_scans\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n    \\n{% endif %}\\n\\n</script>", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Basic information</h3>\\n        <dl class=\\"row\\">\\n            {% if results.total %}\\n            <dt class=\\"col-sm-3\\">Detection</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.positives }} / {{ results.total }}</dd>\\n            {% endif %}\\n            \\n            {% if results.permalink %}\\n            <dt class=\\"col-sm-3\\">Permalink</dt>\\n            <dd class=\\"col-sm-9\\"><a href='{{ results.permalink }}'>{{ results.permalink }}</a></dd>\\n            {% endif %}\\n            \\n            \\n            {% if results.scan_date %}\\n            <dt class=\\"col-sm-3\\">Scan date</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.scan_date }}</dd>\\n            {% endif %}\\n            \\n            {% if results.md5 %}\\n            <dt class=\\"col-sm-3\\">MD5</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.md5 }}</dd>\\n            {% endif %}\\n            \\n            {% if results.sha256 %}\\n            <dt class=\\"col-sm-3\\">SHA256</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.sha256 }}</dd>\\n            {% endif %}\\n        \\n        </dl>\\n    </div>\\n</div>    \\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.scans %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_sc\\" data-toggle=\\"collapse\\" data-target=\\"#drop_scans\\" aria-expanded=\\"false\\" aria-controls=\\"drop_scans\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Scans results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_scans\\" class=\\"collapse\\" aria-labelledby=\\"drop_sc\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"vt_in_scans\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Engine</th>\\n                                      <th>Detected</th>\\n                                      <th>Result</th>\\n                                      <th>Update</th>\\n                                      <th>Version</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for scan in results.scans %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ scan }}</td>\\n                                        <td>{{ results.scans[scan].detected }}</td>\\n                                        <td>{{ results.scans[scan].result }}</td>\\n                                        <td>{{ results.scans[scan].update }}</td>\\n                                        <td>{{ results.scans[scan].version }}</td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n\\n{% if results.scans %}\\n$(\\"#vt_in_scans\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n    \\n{% endif %}\\n\\n</script>"}]	module_processor
2	1	IrisMISP	iris_misp_module	Provides an interface between MISP and IRIS	1.3.0	1.2.0	2026-10-27 21:39:38.826865	f	f	{}	[{"param_name": "misp_config", "param_human_name": "MISP configuration", "param_description": "Configure one or several MISP instances", "default": "{\\n   \\"name\\": \\"Public_MISP\\",\\n   \\"type\\":\\"public\\",\\n   \\"url\\":[\\"https://URL\\"],\\n   \\"key\\":[\\"APIKEY\\"],\\n   \\"ssl\\":[false]\\n}", "mandatory": true, "type": "textfield_json", "value": "{\\n   \\"name\\": \\"Public_MISP\\",\\n   \\"type\\":\\"public\\",\\n   \\"url\\":[\\"https://URL\\"],\\n   \\"key\\":[\\"APIKEY\\"],\\n   \\"ssl\\":[false]\\n}"}, {"param_name": "misp_http_proxy", "param_human_name": "MISP HTTP Proxy", "param_description": "HTTP Proxy parameter", "default": null, "mandatory": false, "type": "string"}, {"param_name": "misp_https_proxy", "param_human_name": "MISP HTTPS Proxy", "param_description": "HTTPS Proxy parameter", "default": null, "mandatory": false, "type": "string"}, {"param_name": "misp_report_as_attribute", "param_human_name": "Add MISP report as new IOC attribute", "param_description": "Creates a new attribute on the IOC, base on the MISP report. Attributes are based on the templates of this configuration", "default": true, "mandatory": true, "type": "bool", "section": "Insights", "value": true}, {"param_name": "misp_domain_report_template", "param_human_name": "Domain report template", "param_description": "Domain report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> "}, {"param_name": "misp_ip_report_template", "param_human_name": "IP report template", "param_description": "IP report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> "}, {"param_name": "misp_hash_report_template", "param_human_name": "Hash report template", "param_description": "Hash report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> "}, {"param_name": "misp_ja3_report_template", "param_human_name": "JA3 report template", "param_description": "JA3 report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> "}, {"param_name": "misp_manual_hook_enabled", "param_human_name": "Manual triggers on IOCs", "param_description": "Set to True to offers possibility to manually triggers the module via the UI", "default": true, "mandatory": true, "type": "bool", "section": "Triggers", "value": true}, {"param_name": "misp_on_create_hook_enabled", "param_human_name": "Triggers automatically on IOC create", "param_description": "Set to True to automatically add a MISP insight each time an IOC is created", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "misp_on_update_hook_enabled", "param_human_name": "Triggers automatically on IOC update", "param_description": "Set to True to automatically add a MISP insight each time an IOC is updated", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}]	module_processor
3	1	IrisCheck	iris_check_module	Provides a simple check module that replies to every hooks	1.0.1	1.2.0	2026-10-27 21:39:38.853457	f	f	{}	[{"param_name": "check_log_received_hook", "param_human_name": "Log received hook", "param_description": "Logs every hook received if set to true. Otherwise do nothing.", "default": true, "mandatory": true, "type": "bool", "value": true}]	module_processor
4	1	IrisWebHooks	iris_webhooks_module	Provides webhooks for IRIS. See https://docs.dfir-iris.org/operations/modules/natives/IrisWebHooks/	1.0.8	1.2.0	2026-10-27 21:39:39.141867	f	f	{}	[{"param_name": "wh_configuration", "param_human_name": "Webhooks configuration", "param_description": "JSON Webhooks configuration", "default": "{}", "mandatory": true, "type": "textfield_json", "value": "{}"}]	module_processor
5	1	Iris IntelOwl	iris_intelowl_module	Provides a connector with IntelOwl - allows to pull insights from IntelOwl analyzers	0.1.0	1.2.0	2026-10-27 21:39:39.153487	f	f	{}	[{"param_name": "intelowl_url", "param_human_name": "IntelOwl URL", "param_description": "", "default": null, "mandatory": true, "type": "string"}, {"param_name": "intelowl_key", "param_human_name": "IntelOwl API key", "param_description": "IntelOwl API key", "default": null, "mandatory": true, "type": "sensitive_string"}, {"param_name": "intelowl_should_use_proxy", "param_human_name": "Set global proxy settings for IntelOwl module", "param_description": "Set true or false to decide whether or not the global proxy settings should be set for IntelOwl usage", "default": false, "mandatory": true, "type": "bool", "value": false}, {"param_name": "intelowl_maxtime", "param_human_name": "Maximum job time (minutes)", "param_description": "Set the maximum time the IRIS task should wait until the end of the IntelOwl job", "default": 15, "mandatory": false, "type": "integer", "value": 15}, {"param_name": "intelowl_manual_hook_enabled", "param_human_name": "Manual triggers on IOCs", "param_description": "Set to True to offers possibility to manually triggers the module via the UI", "default": true, "mandatory": true, "type": "bool", "section": "Triggers", "value": true}, {"param_name": "intelowl_on_create_hook_enabled", "param_human_name": "Triggers automatically on IOC create", "param_description": "Set to True to automatically add a IntelOwl insight each time an IOC is created", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "intelowl_on_update_hook_enabled", "param_human_name": "Triggers automatically on IOC update", "param_description": "Set to True to automatically add a IntelOwl insight each time an IOC is updated", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "intelowl_report_as_attribute", "param_human_name": "Add IntelOwl report as new IOC attribute", "param_description": "Creates a new attribute on the IOC, base on the IntelOwl report. Attributes are based on the templates of this configuration", "default": true, "mandatory": true, "type": "bool", "section": "Insights", "value": true}, {"param_name": "intelowl_domain_report_template", "param_human_name": "Domain report template", "param_description": "Domain report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}, {"param_name": "intelowl_ip_report_template", "param_human_name": "IP report template", "param_description": "IP report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}, {"param_name": "intelowl_url_report_template", "param_human_name": "URL report template", "param_description": "URL report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}, {"param_name": "intelowl_hash_report_template", "param_human_name": "Hash report template", "param_description": "Hash report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}, {"param_name": "intelowl_generic_report_template", "param_human_name": "Generic ioc report template", "param_description": "Generic ioc report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}]	module_processor
\.


--
-- Data for Name: iris_module_hooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_module_hooks (id, module_id, hook_id, is_manual_hook, manual_hook_ui_name, retry_on_fail, max_retry, run_asynchronously, wait_till_return) FROM stdin;
1	1	36	t	Get VT insight	\N	0	t	f
2	3	1	f	\N	\N	0	t	f
3	3	2	f	\N	\N	0	t	f
4	3	3	f	\N	\N	0	t	f
5	3	4	f	\N	\N	0	t	f
6	3	5	f	\N	\N	0	t	f
7	3	6	f	\N	\N	0	t	f
8	3	7	f	\N	\N	0	t	f
9	3	8	f	\N	\N	0	t	f
10	3	9	t	iris_check_module::on_manual_trigger_alert	\N	0	t	f
11	3	10	f	\N	\N	0	t	f
12	3	11	f	\N	\N	0	t	f
13	3	12	f	\N	\N	0	t	f
14	3	13	f	\N	\N	0	t	f
15	3	14	f	\N	\N	0	t	f
16	3	15	t	iris_check_module::on_manual_trigger_case	\N	0	t	f
17	3	16	f	\N	\N	0	t	f
18	3	17	f	\N	\N	0	t	f
19	3	18	f	\N	\N	0	t	f
20	3	19	f	\N	\N	0	t	f
21	3	20	f	\N	\N	0	t	f
22	3	21	f	\N	\N	0	t	f
23	3	22	t	iris_check_module::on_manual_trigger_asset	\N	0	t	f
24	3	23	f	\N	\N	0	t	f
25	3	24	f	\N	\N	0	t	f
26	3	25	f	\N	\N	0	t	f
27	3	26	f	\N	\N	0	t	f
28	3	27	f	\N	\N	0	t	f
29	3	28	f	\N	\N	0	t	f
30	3	29	t	iris_check_module::on_manual_trigger_note	\N	0	t	f
31	3	30	f	\N	\N	0	t	f
32	3	31	f	\N	\N	0	t	f
33	3	32	f	\N	\N	0	t	f
34	3	33	f	\N	\N	0	t	f
35	3	34	f	\N	\N	0	t	f
36	3	35	f	\N	\N	0	t	f
37	3	36	t	iris_check_module::on_manual_trigger_ioc	\N	0	t	f
38	3	37	f	\N	\N	0	t	f
39	3	38	f	\N	\N	0	t	f
40	3	39	f	\N	\N	0	t	f
41	3	40	f	\N	\N	0	t	f
42	3	41	f	\N	\N	0	t	f
43	3	42	f	\N	\N	0	t	f
44	3	43	f	\N	\N	0	t	f
45	3	44	t	iris_check_module::on_manual_trigger_event	\N	0	t	f
46	3	45	f	\N	\N	0	t	f
47	3	46	f	\N	\N	0	t	f
48	3	47	f	\N	\N	0	t	f
49	3	48	f	\N	\N	0	t	f
50	3	49	f	\N	\N	0	t	f
51	3	50	f	\N	\N	0	t	f
52	3	51	t	iris_check_module::on_manual_trigger_evidence	\N	0	t	f
53	3	52	f	\N	\N	0	t	f
54	3	53	f	\N	\N	0	t	f
55	3	54	f	\N	\N	0	t	f
56	3	55	f	\N	\N	0	t	f
57	3	56	f	\N	\N	0	t	f
58	3	57	f	\N	\N	0	t	f
59	3	58	t	iris_check_module::on_manual_trigger_task	\N	0	t	f
60	3	59	f	\N	\N	0	t	f
61	3	60	f	\N	\N	0	t	f
62	3	61	f	\N	\N	0	t	f
63	3	62	f	\N	\N	0	t	f
64	3	63	f	\N	\N	0	t	f
65	3	64	f	\N	\N	0	t	f
66	3	65	t	iris_check_module::on_manual_trigger_global_task	\N	0	t	f
67	3	66	f	\N	\N	0	t	f
68	3	67	f	\N	\N	0	t	f
69	3	68	f	\N	\N	0	t	f
70	3	69	f	\N	\N	0	t	f
71	3	70	f	\N	\N	0	t	f
72	3	71	f	\N	\N	0	t	f
73	3	72	f	\N	\N	0	t	f
74	3	73	f	\N	\N	0	t	f
75	3	74	f	\N	\N	0	t	f
76	3	75	f	\N	\N	0	t	f
77	3	76	f	\N	\N	0	t	f
78	3	77	f	\N	\N	0	t	f
79	3	78	f	\N	\N	0	t	f
80	3	79	f	\N	\N	0	t	f
81	3	80	f	\N	\N	0	t	f
82	3	81	f	\N	\N	0	t	f
83	3	82	f	\N	\N	0	t	f
84	3	83	f	\N	\N	0	t	f
85	3	84	f	\N	\N	0	t	f
86	3	85	f	\N	\N	0	t	f
87	3	86	f	\N	\N	0	t	f
88	3	87	f	\N	\N	0	t	f
89	3	88	f	\N	\N	0	t	f
90	3	89	f	\N	\N	0	t	f
91	3	90	f	\N	\N	0	t	f
\.


--
-- Data for Name: iris_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_reports (report_id, case_id, report_title, report_date, report_content, user_id) FROM stdin;
\.


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.languages (id, name, code) FROM stdin;
1	french	FR
2	english	EN
3	german	DE
4	bulgarian	BG
5	croatian	HR
6	danish	DK
7	dutch	NL
8	estonian	EE
9	finnish	FI
10	greek	GR
11	hungarian	HU
12	irish	IE
13	italian	IT
14	latvian	LV
15	lithuanian	LT
16	maltese	MT
17	polish	PL
18	portuguese	PT
19	romanian	RO
20	slovak	SK
21	slovenian	SI
22	spanish	ES
23	swedish	SE
24	indian	IN
25	chinese	CN
26	korean	KR
27	arabic	AR
28	japanese	JP
29	turkish	TR
30	vietnamese	VN
31	thai	TH
32	hebrew	IL
33	czech	CZ
34	norwegian	NO
35	brazilian	BR
36	ukrainian	UA
37	catalan	CA
38	serbian	RS
39	persian	IR
40	afrikaans	ZA
41	albanian	AL
42	armenian	AM
\.


--
-- Data for Name: note_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.note_comments (id, comment_id, comment_note_id) FROM stdin;
\.


--
-- Data for Name: note_directory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.note_directory (id, name, parent_id, case_id) FROM stdin;
\.


--
-- Data for Name: note_revisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.note_revisions (revision_id, note_id, revision_number, note_title, note_content, note_user, revision_timestamp) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notes (note_id, note_uuid, note_title, note_content, note_user, note_creationdate, note_lastupdate, note_case_id, custom_attributes, directory_id, modification_history) FROM stdin;
\.


--
-- Data for Name: notes_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notes_group (group_id, group_uuid, group_title, group_user, group_creationdate, group_lastupdate, group_case_id) FROM stdin;
\.


--
-- Data for Name: notes_group_link; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notes_group_link (link_id, group_id, note_id, case_id) FROM stdin;
\.


--
-- Data for Name: object_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.object_state (object_id, object_case_id, object_updated_by_id, object_name, object_state, object_last_update) FROM stdin;
1	1	1	timeline	0	2026-10-27 21:39:39.180088
2	1	1	tasks	0	2026-10-27 21:39:39.18193
3	1	1	evidences	0	2026-10-27 21:39:39.183054
4	1	1	ioc	0	2026-10-27 21:39:39.183973
5	1	1	assets	0	2026-10-27 21:39:39.184872
6	1	1	notes	0	2026-10-27 21:39:39.185737
\.


--
-- Data for Name: organisation_case_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organisation_case_access (id, org_id, case_id, access_level) FROM stdin;
\.


--
-- Data for Name: organisations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organisations (org_id, org_uuid, org_name, org_description, org_url, org_logo, org_email, org_nationality, org_sector, org_type) FROM stdin;
1	b0868f0a-c659-4bf9-abd6-f2be76455b3d	Default Org	Default Organisation						
\.


--
-- Data for Name: os_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.os_type (type_id, type_name) FROM stdin;
1	Windows
2	Linux
3	AIX
4	MacOS
5	Apple iOS
6	Cisco iOS
7	Android
\.


--
-- Data for Name: report_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_type (id, name) FROM stdin;
1	Investigation
2	Activities
\.


--
-- Data for Name: review_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_status (id, status_name) FROM stdin;
1	No review required
2	Not reviewed
3	Pending review
4	Review in progress
5	Reviewed
\.


--
-- Data for Name: saved_filters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saved_filters (filter_id, created_by, filter_name, filter_description, filter_data, filter_is_private, filter_type) FROM stdin;
\.


--
-- Data for Name: server_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.server_settings (id, https_proxy, http_proxy, prevent_post_mod_repush, prevent_post_objects_repush, has_updates_available, enable_updates_check, password_policy_min_length, password_policy_upper_case, password_policy_lower_case, password_policy_digit, password_policy_special_chars, enforce_mfa) FROM stdin;
1			f	f	\N	\N	12	t	t	t		f
\.


--
-- Data for Name: severities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.severities (severity_id, severity_name, severity_description) FROM stdin;
1	Medium	Medium
2	Unspecified	Unspecified
3	Informational	Informational
4	Low	Low
5	High	High
6	Critical	Critical
\.


--
-- Data for Name: silent_ridge_receipts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.silent_ridge_receipts (key, remote) FROM stdin;
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T01	1
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T02	2
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T03	3
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T04	4
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T05	5
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T06	6
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T08	7
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T10	8
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T06-Q1	1
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T06-Q2	2
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T06-Q3	3
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T06-Q4	4
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T07	9
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T10-Q1	5
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T10-Q2	6
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T10-Q3	7
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T10-Q4	8
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T08-Q1	9
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T08-Q2	10
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T08-Q3	11
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T01-Q1	12
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T08-Q4	13
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T09	10
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T04-Q1	14
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T04-Q2	15
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T04-Q3	16
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T04-Q4	17
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T01-Q1	18
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T01-Q2	19
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T01-Q3	20
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T01-Q4	21
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T02-Q1	22
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T02-Q2	23
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T02-Q3	24
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T02-Q4	25
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T03-Q1	26
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T03-Q2	27
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T03-Q3	28
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T03-Q4	29
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T07-Q1	30
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T01-Q1	31
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T07-Q2	32
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T07-Q3	33
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T07-Q4	34
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T05-Q1	35
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T05-Q2	36
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T05-Q3	37
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T05-Q4	38
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T09-Q1	39
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T09-Q2	40
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T01-Q1	41
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T09-Q3	42
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T09-Q4	43
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T11	11
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T12	12
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T13	13
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T14	14
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T15	15
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T01-Q2	44
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T11-Q1	45
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T11-Q2	46
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T11-Q3	47
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T11-Q4	48
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T12-Q1	49
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T12-Q2	50
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T12-Q3	51
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T12-Q4	52
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T13-Q1	53
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T13-Q2	54
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T01-Q2	55
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T13-Q3	56
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T13-Q4	57
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T14-Q1	58
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T14-Q2	59
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T01-Q3	60
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T14-Q3	61
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T14-Q4	62
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T15-Q1	63
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T15-Q2	64
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T15-Q3	65
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T15-Q4	66
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T16	16
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T17	17
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T18	18
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T19	19
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T17-Q1	71
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T19-Q4	82
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T01-Q3	84
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T20-Q1	86
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T20-Q3	88
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T20-Q4	89
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T02-Q1	95
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T16-Q1	67
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T16-Q3	69
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T17-Q2	72
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T17-Q4	74
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T18-Q3	77
75a9d067-2529-4e19-92bb-46507fed4fb9:ticket:T20	20
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T20-Q2	87
75a9d067-2529-4e19-92bb-46507fed4fb9:assessment:final:team-05	90
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T01-Q2	92
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T02-Q2	94
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T16-Q2	68
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T16-Q4	70
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T17-Q3	73
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T18-Q1	75
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T18-Q4	78
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T19-Q2	80
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T01-Q4	91
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T02-Q2	96
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T18-Q2	76
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T19-Q1	79
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-05:T19-Q3	81
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T01-Q3	83
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T01-Q4	85
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T02-Q1	93
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T01-Q4	97
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T02-Q1	98
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T02-Q2	99
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T02-Q3	100
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T02-Q3	101
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T02-Q4	102
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T03-Q1	103
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T03-Q2	104
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T02-Q4	105
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T03-Q3	106
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T02-Q3	107
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T03-Q4	108
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T02-Q4	109
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T01-Q1	110
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T01-Q2	111
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T02-Q1	112
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T02-Q2	113
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T03-Q1	114
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T03-Q2	115
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T01-Q1	116
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T01-Q2	117
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T02-Q3	118
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T01-Q3	119
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T06-Q1	120
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T01-Q4	121
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T06-Q2	122
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T06-Q3	123
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T04-Q1	124
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T01-Q3	125
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T01-Q4	126
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T02-Q1	127
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T06-Q4	128
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T02-Q4	129
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T02-Q2	130
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T03-Q4	131
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T02-Q3	132
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T02-Q4	133
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T04-Q2	134
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T04-Q3	135
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T10-Q3	136
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T04-Q4	137
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T04-Q1	138
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T03-Q1	139
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T04-Q2	140
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T03-Q2	141
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T03-Q1	142
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T03-Q2	143
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T10-Q1	144
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T04-Q3	145
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T05-Q1	146
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T03-Q3	147
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T05-Q2	148
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T03-Q4	149
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T05-Q3	150
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T05-Q4	151
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T03-Q4	152
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T10-Q2	153
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T01-Q1	154
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T03-Q3	155
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T04-Q4	156
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T07-Q1	157
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T06-Q1	158
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T07-Q2	159
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T01-Q2	160
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T04-Q1	161
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T05-Q1	162
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T05-Q2	163
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T07-Q3	164
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T05-Q3	165
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T05-Q4	166
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T06-Q2	167
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T01-Q3	168
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T06-Q3	169
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T10-Q4	170
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T06-Q4	171
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T06-Q1	172
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T04-Q2	173
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T10-Q4	177
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T04-Q3	184
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T08-Q4	188
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T05-Q1	190
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T05-Q3	193
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T08-Q2	196
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T06-Q3	201
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T07-Q1	204
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T09-Q2	207
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T06-Q4	209
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T06-Q4	214
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T07-Q1	217
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T08-Q1	225
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T03-Q2	227
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T07-Q4	174
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T06-Q1	175
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T07-Q1	181
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T04-Q4	186
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T05-Q4	194
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T06-Q2	199
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T06-Q4	202
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T09-Q3	205
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T09-Q1	208
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T06-Q3	211
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T02-Q3	215
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T08-Q1	216
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T06-Q3	220
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T06-Q2	223
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T04-Q1	176
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T01-Q4	180
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T10-Q2	185
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T07-Q2	187
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T07-Q3	189
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T05-Q2	191
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T03-Q3	197
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T09-Q4	200
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T02-Q1	203
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T07-Q4	206
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T06-Q2	210
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T02-Q2	213
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T02-Q4	218
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T08-Q1	221
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T07-Q3	224
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T03-Q1	226
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T04-Q2	178
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T04-Q3	179
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T10-Q1	182
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T10-Q3	183
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T08-Q3	192
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T06-Q1	195
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T08-Q1	198
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T07-Q3	212
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T07-Q2	219
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T05-Q1	222
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T05-Q2	228
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T03-Q3	229
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T05-Q3	230
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T03-Q4	231
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T08-Q2	232
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T08-Q3	233
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T08-Q4	234
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T04-Q1	235
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T05-Q4	236
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T08-Q2	237
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T04-Q2	238
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T04-Q3	239
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T08-Q3	240
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T09-Q1	241
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T08-Q4	242
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T07-Q1	243
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T09-Q2	244
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T08-Q2	245
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T09-Q3	246
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T09-Q4	247
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T08-Q3	248
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T08-Q4	249
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T09-Q1	250
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T09-Q2	251
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T09-Q3	252
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T09-Q4	253
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T07-Q2	254
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T10-Q1	255
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T04-Q4	256
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T10-Q2	257
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T10-Q3	258
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T10-Q4	259
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T05-Q1	260
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T05-Q2	261
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T07-Q3	262
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T05-Q3	263
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T05-Q4	264
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T11-Q1	265
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T11-Q2	266
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T09-Q1	267
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T09-Q2	268
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T07-Q2	269
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T09-Q3	270
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T04-Q4	271
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T07-Q4	272
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T09-Q4	273
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T07-Q4	274
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T11-Q3	275
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T11-Q4	276
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T08-Q1	277
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T10-Q1	278
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T08-Q2	279
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T11-Q2	280
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T10-Q2	281
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T07-Q4	282
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T10-Q3	283
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T08-Q3	284
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T10-Q1	285
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T08-Q4	286
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T10-Q4	287
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T10-Q2	288
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T03-Q1	289
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T10-Q3	290
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T11-Q1	291
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T12-Q1	292
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T03-Q2	293
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T10-Q4	294
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T11-Q2	295
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T11-Q3	296
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T03-Q4	297
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T09-Q1	298
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T06-Q1	299
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T09-Q3	302
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T12-Q1	304
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T09-Q2	300
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T09-Q4	303
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T11-Q4	305
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T03-Q3	301
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T06-Q2	306
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T12-Q2	307
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T12-Q3	308
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T10-Q1	309
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T12-Q2	310
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T13-Q1	311
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T06-Q3	312
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T10-Q2	313
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T12-Q4	314
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T12-Q3	315
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T10-Q3	316
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T13-Q1	317
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T10-Q4	318
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T12-Q1	319
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T13-Q2	320
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T13-Q3	321
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T13-Q4	322
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T04-Q2	323
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T14-Q1	324
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T04-Q1	325
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T14-Q2	326
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T04-Q3	327
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T15-Q1	328
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T12-Q2	329
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T06-Q4	330
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T14-Q4	331
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T12-Q3	332
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T15-Q2	333
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T05-Q1	334
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T14-Q3	335
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T15-Q3	336
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T04-Q4	337
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T05-Q2	338
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T05-Q3	339
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T12-Q4	340
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T05-Q4	341
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T07-Q1	342
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T15-Q4	343
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T07-Q2	344
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T08-Q1	345
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T07-Q3	346
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T12-Q4	347
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T08-Q4	348
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T07-Q4	349
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T14-Q1	350
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T11-Q1	351
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T13-Q1	352
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T08-Q3	353
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T14-Q2	354
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T08-Q2	355
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T13-Q2	356
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T14-Q3	357
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T09-Q1	358
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T16-Q1	359
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T14-Q4	360
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T13-Q3	361
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T09-Q2	362
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T16-Q2	363
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T16-Q3	364
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T09-Q3	365
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T09-Q4	366
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T16-Q4	367
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T13-Q4	368
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T15-Q1	369
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T19-Q1	370
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T15-Q2	371
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T14-Q1	372
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T14-Q2	373
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T14-Q3	374
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T13-Q3	375
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T14-Q4	376
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T15-Q1	377
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T17-Q1	378
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T15-Q2	379
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T15-Q3	380
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T11-Q1	381
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T17-Q2	382
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T15-Q3	383
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T11-Q2	384
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T11-Q1	385
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T12-Q1	386
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T18-Q1	390
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T17-Q3	387
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T13-Q1	388
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T17-Q4	389
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T19-Q2	391
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T12-Q2	392
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T11-Q2	393
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T11-Q3	394
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T12-Q3	395
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T11-Q4	396
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T13-Q2	397
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T11-Q3	398
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T15-Q4	399
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T12-Q4	400
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T11-Q4	401
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T13-Q4	402
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T19-Q3	403
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T14-Q4	404
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T14-Q1	405
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T15-Q1	406
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T15-Q2	407
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T14-Q2	408
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T13-Q1	409
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T15-Q3	410
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T18-Q3	411
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T18-Q2	412
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T14-Q3	413
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T18-Q4	414
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T13-Q2	415
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T19-Q4	416
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T15-Q4	417
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T15-Q4	418
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T20-Q1	419
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T16-Q1	420
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T18-Q1	421
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T12-Q1	422
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T16-Q2	423
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T16-Q3	424
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T17-Q1	425
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-02:T16-Q1	426
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T16-Q4	427
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T13-Q3	428
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T20-Q2	429
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T12-Q2	430
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T12-Q3	431
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T13-Q4	432
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T19-Q1	433
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T12-Q4	434
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T18-Q2	435
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T19-Q2	436
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T19-Q3	437
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T14-Q1	438
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T14-Q2	439
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T19-Q4	440
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T14-Q3	441
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T20-Q3	442
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T14-Q4	443
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-08:T20-Q4	444
75a9d067-2529-4e19-92bb-46507fed4fb9:assessment:final:team-08	445
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T15-Q1	446
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T15-Q2	447
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T11-Q1	448
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T15-Q3	449
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T15-Q4	450
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T18-Q3	451
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T11-Q2	452
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T17-Q4	453
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T11-Q3	454
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T11-Q4	455
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T18-Q4	456
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T17-Q2	457
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T17-Q3	458
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T20-Q4	459
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T12-Q1	460
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T20-Q3	461
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T20-Q2	462
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-06:T20-Q1	463
75a9d067-2529-4e19-92bb-46507fed4fb9:assessment:final:team-06	464
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T12-Q2	465
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T12-Q3	466
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T12-Q4	467
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T13-Q1	468
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T13-Q2	469
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T13-Q3	470
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T13-Q4	471
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T14-Q2	473
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T16-Q4	483
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T14-Q1	472
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T15-Q2	477
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T16-Q2	481
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T14-Q3	474
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T15-Q1	476
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T16-Q1	480
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T14-Q4	475
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T15-Q3	478
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T15-Q4	479
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T16-Q3	482
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-04:T17-Q1	484
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T11-Q3	485
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T11-Q4	486
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T13-Q2	487
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T13-Q3	488
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T13-Q4	489
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T16-Q2	490
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T17-Q1	491
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T16-Q1	492
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T16-Q3	493
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T16-Q2	494
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T16-Q4	495
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T17-Q2	496
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T17-Q3	497
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T17-Q4	498
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T16-Q1	499
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T18-Q1	500
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T18-Q2	501
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T17-Q4	502
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T18-Q3	503
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T18-Q4	504
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T19-Q1	505
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T16-Q4	506
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T19-Q2	507
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T19-Q3	508
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T17-Q1	509
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T19-Q4	510
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T18-Q1	511
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T17-Q2	512
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T16-Q3	513
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T20-Q1	514
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T17-Q3	515
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T20-Q2	516
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T20-Q3	517
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-09:T20-Q4	518
75a9d067-2529-4e19-92bb-46507fed4fb9:assessment:final:team-09	519
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T18-Q2	520
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T18-Q3	521
75a9d067-2529-4e19-92bb-46507fed4fb9:finding:team-03:T18-Q4	522
\.


--
-- Data for Name: silent_ridge_work_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.silent_ridge_work_status (user_id, ticket, status) FROM stdin;
7	T06	working
5	T01	working
5	T02	working
10	T01	working
11	T01	working
5	T03	working
5	T10	working
5	T17	working
\.


--
-- Data for Name: similar_alerts_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.similar_alerts_cache (id, customer_id, asset_name, ioc_value, alert_id, created_at, asset_type_id, ioc_type_id) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (id, tag_title, tag_creation_date, tag_namespace) FROM stdin;
\.


--
-- Data for Name: task_assignee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_assignee (id, user_id, task_id) FROM stdin;
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_comments (id, comment_id, comment_task_id) FROM stdin;
1	1	6
2	2	6
3	3	6
4	4	6
5	5	8
6	6	8
7	7	8
8	8	8
9	9	7
10	10	7
11	11	7
12	12	1
13	13	7
14	14	4
15	15	4
16	16	4
17	17	4
18	18	1
19	19	1
20	20	1
21	21	1
22	22	2
23	23	2
24	24	2
25	25	2
26	26	3
27	27	3
28	28	3
29	29	3
30	30	9
31	31	1
32	32	9
33	33	9
34	34	9
35	35	5
36	36	5
37	37	5
38	38	5
39	39	10
40	40	10
41	41	1
42	42	10
43	43	10
44	44	1
45	45	11
46	46	11
47	47	11
48	48	11
49	49	12
50	50	12
51	51	12
52	52	12
53	53	13
54	54	13
55	55	1
56	56	13
57	57	13
58	58	14
59	59	14
60	60	1
61	61	14
62	62	14
63	63	15
64	64	15
65	65	15
66	66	15
67	67	16
68	68	16
69	69	16
70	70	16
71	71	17
72	72	17
73	73	17
74	74	17
75	75	18
76	76	18
77	77	18
78	78	18
79	79	19
80	80	19
81	81	19
82	82	19
83	83	1
84	84	1
85	85	1
86	86	20
87	87	20
88	88	20
89	89	20
90	90	20
91	91	1
92	92	1
93	93	2
94	94	2
95	95	2
96	96	2
97	97	1
98	98	2
99	99	2
100	100	2
101	101	2
102	102	2
103	103	3
104	104	3
105	105	2
106	106	3
107	107	2
108	108	3
109	109	2
110	110	1
111	111	1
112	112	2
113	113	2
114	114	3
115	115	3
116	116	1
117	117	1
118	118	2
119	119	1
120	120	6
121	121	1
122	122	6
123	123	6
124	124	4
125	125	1
126	126	1
127	127	2
128	128	6
129	129	2
130	130	2
131	131	3
132	132	2
133	133	2
134	134	4
135	135	4
136	136	8
137	137	4
138	138	4
139	139	3
140	140	4
141	141	3
142	142	3
143	143	3
144	144	8
145	145	4
146	146	5
147	147	3
148	148	5
149	149	3
150	150	5
151	151	5
152	152	3
153	153	8
154	154	1
155	155	3
156	156	4
157	157	9
158	158	6
160	160	1
168	168	1
170	170	8
159	159	9
162	162	5
165	165	5
172	172	6
173	173	4
161	161	4
163	163	5
166	166	5
171	171	6
164	164	9
167	167	6
169	169	6
174	174	9
175	175	6
176	176	4
177	177	8
178	178	4
179	179	4
180	180	1
181	181	9
182	182	8
183	183	8
184	184	4
185	185	8
186	186	4
187	187	9
188	188	7
189	189	9
190	190	5
191	191	5
192	192	7
193	193	5
194	194	5
195	195	6
196	196	7
197	197	3
198	198	7
199	199	6
200	200	10
201	201	6
202	202	6
203	203	2
204	204	9
205	205	10
206	206	9
207	207	10
208	208	10
209	209	6
210	210	6
211	211	6
212	212	9
213	213	2
214	214	6
215	215	2
216	216	7
217	217	9
218	218	2
219	219	9
220	220	6
221	221	7
222	222	5
223	223	6
224	224	9
225	225	7
226	226	3
227	227	3
228	228	5
229	229	3
230	230	5
231	231	3
232	232	7
233	233	7
234	234	7
235	235	4
236	236	5
237	237	7
238	238	4
239	239	4
240	240	7
241	241	10
242	242	7
243	243	9
244	244	10
245	245	7
246	246	10
247	247	10
248	248	7
249	249	7
250	250	10
251	251	10
252	252	10
253	253	10
254	254	9
255	255	8
256	256	4
257	257	8
258	258	8
259	259	8
260	260	5
261	261	5
262	262	9
263	263	5
264	264	5
265	265	11
266	266	11
267	267	10
268	268	10
269	269	9
270	270	10
271	271	4
272	272	9
273	273	10
274	274	9
275	275	11
276	276	11
277	277	7
278	278	8
279	279	7
280	280	11
281	281	8
282	282	9
283	283	8
284	284	7
285	285	8
286	286	7
287	287	8
288	288	8
289	289	3
290	290	8
291	291	11
292	292	12
293	293	3
294	294	8
295	295	11
296	296	11
297	297	3
298	298	10
299	299	6
300	300	10
301	301	3
302	302	10
303	303	10
304	304	12
305	305	11
306	306	6
307	307	12
308	308	12
309	309	8
310	310	12
311	311	13
312	312	6
313	313	8
314	314	12
315	315	12
316	316	8
317	317	13
318	318	8
319	319	12
320	320	13
321	321	13
322	322	13
323	323	4
324	324	14
325	325	4
326	326	14
327	327	4
328	328	15
335	335	14
342	342	9
344	344	9
347	347	12
349	349	9
351	351	11
354	354	14
357	357	14
361	361	13
364	364	16
368	368	13
371	371	15
377	377	15
380	380	15
383	383	15
386	386	12
390	390	18
396	396	11
399	399	15
404	404	14
329	329	12
332	332	12
336	336	15
339	339	5
343	343	15
352	352	13
355	355	7
358	358	10
365	365	10
374	374	14
378	378	17
384	384	11
387	387	17
393	393	11
400	400	12
402	402	13
405	405	14
408	408	14
330	330	6
333	333	15
337	337	4
340	340	12
345	345	7
348	348	7
350	350	14
353	353	7
356	356	13
359	359	16
362	362	10
366	366	10
369	369	15
372	372	14
375	375	13
381	381	11
385	385	11
388	388	13
391	391	19
394	394	11
397	397	13
401	401	11
403	403	19
406	406	15
331	331	14
334	334	5
338	338	5
341	341	5
346	346	9
360	360	14
363	363	16
367	367	16
370	370	19
373	373	14
376	376	14
379	379	15
382	382	17
389	389	17
392	392	12
395	395	12
398	398	11
407	407	15
409	409	13
410	410	15
411	411	18
412	412	18
413	413	14
414	414	18
415	415	13
416	416	19
417	417	15
418	418	15
419	419	20
420	420	16
421	421	18
422	422	12
423	423	16
424	424	16
425	425	17
426	426	16
427	427	16
428	428	13
429	429	20
430	430	12
431	431	12
432	432	13
433	433	19
434	434	12
435	435	18
436	436	19
437	437	19
438	438	14
439	439	14
440	440	19
441	441	14
442	442	20
443	443	14
444	444	20
445	445	20
446	446	15
447	447	15
448	448	11
449	449	15
450	450	15
451	451	18
452	452	11
453	453	17
454	454	11
455	455	11
456	456	18
457	457	17
458	458	17
459	459	20
460	460	12
461	461	20
462	462	20
463	463	20
464	464	20
465	465	12
466	466	12
467	467	12
468	468	13
469	469	13
470	470	13
471	471	13
472	472	14
473	473	14
474	474	14
475	475	14
476	476	15
477	477	15
478	478	15
479	479	15
480	480	16
481	481	16
482	482	16
483	483	16
484	484	17
485	485	11
486	486	11
487	487	13
488	488	13
489	489	13
490	490	16
491	491	17
492	492	16
493	493	16
494	494	16
495	495	16
496	496	17
497	497	17
498	498	17
499	499	16
500	500	18
501	501	18
502	502	17
503	503	18
504	504	18
505	505	19
506	506	16
507	507	19
508	508	19
509	509	17
510	510	19
511	511	18
512	512	17
513	513	16
514	514	20
515	515	17
516	516	20
517	517	20
518	518	20
519	519	20
520	520	18
521	521	18
522	522	18
\.


--
-- Data for Name: task_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_status (id, status_name, status_description, status_bscolor) FROM stdin;
1	To do		danger
2	In progress		warning
3	On hold		muted
4	Done		success
5	Canceled		muted
\.


--
-- Data for Name: tlp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tlp (tlp_id, tlp_name, tlp_bscolor) FROM stdin;
1	red	danger
2	amber	warning
3	green	success
4	clear	black
5	amber+strict	warning
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, "user", name, email, uuid, password, ctx_case, ctx_human_case, active, api_key, external_id, in_dark_mode, has_mini_sidebar, has_deletion_confirmation, is_service_account, mfa_secrets, webauthn_credentials, mfa_setup_complete) FROM stdin;
1	admin	admin	administrator@localhost	debfc9d4-8143-45d9-b643-7d35328f38a3	$2b$12$wvkBzXf.n1Tobo9XaAv1DeB/FZvpJMqXrR5C4DvskPf8ck6/wreVe	\N	\N	t	dIBG0kp3bKUJHQUjGR77Wv7DwvKpaQPGlYPrLubIAJJ3rpKQs9Sm08uWWXkNRFCdKMoQV6eh7dNfzvwo91ZrvA	\N	\N	f	f	f	\N	[]	f
2	silent-ridge-service	Silent Ridge Integration	silent-ridge-service@silent-ridge.invalid	bdf1e723-be1b-4d0a-bac3-c2c492d3f01e	$2b$12$55n3Vge9bwNOMQBD906vXuo2tNoGoCX7zAhvJJBJBifBxc9MHobgm	\N	\N	t	\N	\N	\N	f	f	f	\N	[]	f
3	team-01	FLUFFY	team-01@silent-ridge.invalid	346f0a7a-27fe-45b1-9daf-2828894a17c0	$2b$12$DvxAu.ROACiQPS79NCGByOXk0Sy6Daoa20uDqPRriOYn1TfVqHrgG	\N	\N	t	\N	\N	\N	f	f	f	\N	[]	f
4	team-02	Enterprise-1	team-02@silent-ridge.invalid	b4daecef-a5e9-4845-9a4b-7b5754ec34f8	$2b$12$B61IfpEIN.URzfq5DF97I.HG3JAdZONHIzzaXQgB4AGfv9mrTSdlW	\N	\N	t	\N	\N	\N	f	f	f	\N	[]	f
8	team-06	westpoint graduates	team-06@silent-ridge.invalid	684537f1-fb09-43ac-83ee-b28b644f7999	$2b$12$IaialIaB.2J7gvB0UZwht.drVWcI/oQnOXdIuRtYuNIA5t23mHqMe	\N	\N	t	\N	\N	\N	f	f	f	\N	[]	f
6	team-04	CHUDS	team-04@silent-ridge.invalid	27ab8e93-cb4d-409b-aa9c-07d49ab2c175	$2b$12$qKumW5Ycw2QvlNbR3Z4EbuhTraT.JeYqaBqNxNhuQ7lEiz7AG2sie	1	#1 - Initial Demo	t	\N	\N	\N	f	f	f	\N	[]	f
7	team-05	n0_L0g2_N0_Crim3	team-05@silent-ridge.invalid	0033bb02-66ca-4206-96fd-2a5bd8d0557c	$2b$12$bPEGZISYFFdN1hAHIO.FNuFZU6cPXAyBnFlwZ.u48FuhK21uM9mAy	1	#1 - Initial Demo	t	\N	\N	\N	f	f	f	\N	[]	f
9	team-07	Goopy Gremlins	team-07@silent-ridge.invalid	09a48200-b71b-4c28-a3ce-0cc9f898638a	$2b$12$OZP5g9seTjNVcSLEJV9iKuhyLY0bWDyyQ6oZuxj1tVw.i7FPHmf/2	\N	\N	t	\N	\N	\N	f	f	f	\N	[]	f
5	team-03	MFKiLLG	team-03@silent-ridge.invalid	6da10f8a-21aa-4354-a9e9-ee479b34134e	$2b$12$.5gd4hvzkvyOpa9uBawGi.GI3WirBAme.ahO6CIvUtz79wUXqWK5S	1	#1 - Initial Demo	t	\N	\N	\N	f	f	f	\N	[]	f
10	team-08	BOO	team-08@silent-ridge.invalid	32945cad-9208-4cb7-a613-bd394cecb380	$2b$12$Paflt5WYjfoDrKGlkYYOf.ZbmesNf0hGp6H7eZ9U/4lyHTuuXsIBe	1	#1 - Initial Demo	t	\N	\N	\N	f	f	f	\N	[]	f
11	team-09	thingthing1	team-09@silent-ridge.invalid	aa20cf23-b96c-454d-853b-9ae3f07b3737	$2b$12$ONyHTspQZBxGQq9nhtUAx.e3bZKyz6c8X/l8d/t0OIQ7NvFDXTb3u	1	#1 - Initial Demo	t	\N	\N	\N	f	f	f	\N	[]	f
\.


--
-- Data for Name: user_activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_activity (id, user_id, case_id, activity_date, activity_desc, user_input, is_from_api, display_in_ui) FROM stdin;
1	\N	\N	2026-10-28 12:05:24.482015	Wrong login password for user 'team-04' using local auth	f	f	f
2	\N	\N	2026-10-28 12:05:29.232008	Wrong login password for user 'team-04' using local auth	f	f	f
3	\N	\N	2026-10-28 12:05:57.264013	Wrong login password for user 'team-04' using local auth	f	f	f
4	\N	\N	2026-10-28 12:06:08.641318	Wrong login password for user 'team-04' using local auth	f	f	f
5	6	\N	2026-10-28 12:07:20.690028	User 'team-04' successfully logged-in	f	f	f
6	6	\N	2026-10-28 12:09:26.418565	User 'team-04' successfully logged-in	f	f	f
7	7	\N	2026-10-28 12:11:30.97772	User 'team-05' successfully logged-in	f	f	f
8	\N	\N	2026-10-28 12:23:24.33181	Someone tried to log in with user 'team-03-p01', which does not exist	f	f	f
9	5	\N	2026-10-28 12:23:52.879732	User 'team-03' successfully logged-in	f	f	f
10	5	\N	2026-10-28 12:31:36.890479	User 'team-03' successfully logged-in	f	f	f
11	10	\N	2026-10-28 13:07:30.463794	User 'team-08' successfully logged-in	f	f	f
12	\N	\N	2026-10-28 13:08:33.022059	Someone tried to log in with user 'team-09-p01', which does not exist	f	f	f
13	11	\N	2026-10-28 13:28:38.409234	User 'team-09' successfully logged-in	f	f	f
\.


--
-- Data for Name: user_case_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_case_access (id, user_id, case_id, access_level) FROM stdin;
1	3	2	2
2	4	2	2
3	5	2	2
4	6	2	2
5	7	2	2
6	8	2	2
7	9	2	2
8	10	2	2
9	11	2	2
\.


--
-- Data for Name: user_case_effective_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_case_effective_access (id, user_id, case_id, access_level) FROM stdin;
15	3	2	2
18	4	2	2
21	5	2	2
24	6	2	2
27	7	2	2
30	8	2	2
33	9	2	2
36	10	2	2
38	1	1	4
39	11	2	2
\.


--
-- Data for Name: user_client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_client (id, user_id, client_id, access_level, allow_alerts) FROM stdin;
\.


--
-- Data for Name: user_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_group (id, user_id, group_id) FROM stdin;
1	1	1
\.


--
-- Data for Name: user_organisation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_organisation (id, user_id, org_id, is_primary_org) FROM stdin;
1	1	1	t
\.


--
-- Name: alert_resolution_status_resolution_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_resolution_status_resolution_status_id_seq', 6, true);


--
-- Name: alert_similarity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_similarity_id_seq', 1, false);


--
-- Name: alert_status_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_status_status_id_seq', 8, true);


--
-- Name: alerts_alert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alerts_alert_id_seq', 1, false);


--
-- Name: analysis_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analysis_status_id_seq', 6, true);


--
-- Name: asset_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.asset_comments_id_seq', 1, false);


--
-- Name: assets_type_asset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.assets_type_asset_id_seq', 21, true);


--
-- Name: case_assets_asset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_assets_asset_id_seq', 1, false);


--
-- Name: case_classification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_classification_id_seq', 36, true);


--
-- Name: case_events_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_events_assets_id_seq', 1, false);


--
-- Name: case_events_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_events_category_id_seq', 1, false);


--
-- Name: case_events_ioc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_events_ioc_id_seq', 1, false);


--
-- Name: case_graph_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_graph_assets_id_seq', 1, false);


--
-- Name: case_graph_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_graph_links_id_seq', 1, false);


--
-- Name: case_protagonist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_protagonist_id_seq', 1, false);


--
-- Name: case_received_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_received_file_id_seq', 1, false);


--
-- Name: case_state_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_state_state_id_seq', 9, true);


--
-- Name: case_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_tasks_id_seq', 20, true);


--
-- Name: case_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_template_id_seq', 1, false);


--
-- Name: case_template_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.case_template_report_id_seq', 1, false);


--
-- Name: cases_assets_ext_asset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cases_assets_ext_asset_id_seq', 1, false);


--
-- Name: cases_case_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cases_case_id_seq', 2, true);


--
-- Name: cases_events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cases_events_event_id_seq', 1, false);


--
-- Name: client_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_client_id_seq', 2, true);


--
-- Name: comments_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comments_comment_id_seq', 522, true);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_id_seq', 1, false);


--
-- Name: custom_attribute_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_attribute_attribute_id_seq', 8, true);


--
-- Name: data_store_file_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.data_store_file_file_id_seq', 1, false);


--
-- Name: data_store_path_path_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.data_store_path_path_id_seq', 1, false);


--
-- Name: event_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_category_id_seq', 15, true);


--
-- Name: event_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_comments_id_seq', 1, false);


--
-- Name: evidence_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.evidence_comments_id_seq', 1, false);


--
-- Name: evidence_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.evidence_type_id_seq', 58, true);


--
-- Name: global_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.global_tasks_id_seq', 1, false);


--
-- Name: group_case_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.group_case_access_id_seq', 30, true);


--
-- Name: groups_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.groups_group_id_seq', 3, true);


--
-- Name: ioc_asset_link_ioc_asset_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ioc_asset_link_ioc_asset_link_id_seq', 1, false);


--
-- Name: ioc_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ioc_comments_id_seq', 1, false);


--
-- Name: ioc_ioc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ioc_ioc_id_seq', 1, false);


--
-- Name: ioc_link_ioc_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ioc_link_ioc_link_id_seq', 1, false);


--
-- Name: ioc_type_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ioc_type_type_id_seq', 160, true);


--
-- Name: iris_hooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.iris_hooks_id_seq', 90, true);


--
-- Name: iris_module_hooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.iris_module_hooks_id_seq', 91, true);


--
-- Name: iris_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.iris_module_id_seq', 5, true);


--
-- Name: iris_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.iris_reports_id_seq', 1, false);


--
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.languages_id_seq', 42, true);


--
-- Name: note_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.note_comments_id_seq', 1, false);


--
-- Name: note_directory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.note_directory_id_seq', 1, false);


--
-- Name: note_revisions_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.note_revisions_revision_id_seq', 1, false);


--
-- Name: notes_group_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notes_group_group_id_seq', 1, false);


--
-- Name: notes_group_link_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notes_group_link_link_id_seq', 1, false);


--
-- Name: notes_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notes_note_id_seq', 1, false);


--
-- Name: object_state_object_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.object_state_object_id_seq', 6, true);


--
-- Name: organisation_case_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organisation_case_access_id_seq', 1, false);


--
-- Name: organisations_org_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organisations_org_id_seq', 1, true);


--
-- Name: os_type_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.os_type_type_id_seq', 7, true);


--
-- Name: report_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_type_id_seq', 2, true);


--
-- Name: review_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_status_id_seq', 5, true);


--
-- Name: saved_filters_filter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.saved_filters_filter_id_seq', 1, false);


--
-- Name: server_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.server_settings_id_seq', 1, true);


--
-- Name: severities_severity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.severities_severity_id_seq', 6, true);


--
-- Name: similar_alerts_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.similar_alerts_cache_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: task_assignee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_assignee_id_seq', 1, false);


--
-- Name: task_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_comments_id_seq', 522, true);


--
-- Name: task_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_status_id_seq', 5, true);


--
-- Name: tlp_tlp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tlp_tlp_id_seq', 5, true);


--
-- Name: user_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_activity_id_seq', 13, true);


--
-- Name: user_case_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_case_access_id_seq', 9, true);


--
-- Name: user_case_effective_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_case_effective_access_id_seq', 39, true);


--
-- Name: user_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_client_id_seq', 1, false);


--
-- Name: user_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_group_id_seq', 1, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 11, true);


--
-- Name: user_organisation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_organisation_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: iris
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alert_assets_association alert_assets_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_assets_association
    ADD CONSTRAINT alert_assets_association_pkey PRIMARY KEY (alert_id, asset_id);


--
-- Name: alert_case_association alert_case_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_case_association
    ADD CONSTRAINT alert_case_association_pkey PRIMARY KEY (alert_id, case_id);


--
-- Name: alert_iocs_association alert_iocs_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_iocs_association
    ADD CONSTRAINT alert_iocs_association_pkey PRIMARY KEY (alert_id, ioc_id);


--
-- Name: alert_resolution_status alert_resolution_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_resolution_status
    ADD CONSTRAINT alert_resolution_status_pkey PRIMARY KEY (resolution_status_id);


--
-- Name: alert_resolution_status alert_resolution_status_resolution_status_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_resolution_status
    ADD CONSTRAINT alert_resolution_status_resolution_status_name_key UNIQUE (resolution_status_name);


--
-- Name: alert_similarity alert_similarity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_pkey PRIMARY KEY (id);


--
-- Name: alert_status alert_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_status
    ADD CONSTRAINT alert_status_pkey PRIMARY KEY (status_id);


--
-- Name: alert_status alert_status_status_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_status
    ADD CONSTRAINT alert_status_status_name_key UNIQUE (status_name);


--
-- Name: alerts alerts_alert_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_uuid_key UNIQUE (alert_uuid);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (alert_id);


--
-- Name: analysis_status analysis_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analysis_status
    ADD CONSTRAINT analysis_status_pkey PRIMARY KEY (id);


--
-- Name: asset_comments asset_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asset_comments
    ADD CONSTRAINT asset_comments_pkey PRIMARY KEY (id);


--
-- Name: assets_type assets_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets_type
    ADD CONSTRAINT assets_type_pkey PRIMARY KEY (asset_id);


--
-- Name: case_assets case_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_pkey PRIMARY KEY (asset_id);


--
-- Name: case_classification case_classification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_classification
    ADD CONSTRAINT case_classification_pkey PRIMARY KEY (id);


--
-- Name: case_events_assets case_events_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_assets
    ADD CONSTRAINT case_events_assets_pkey PRIMARY KEY (id);


--
-- Name: case_events_category case_events_category_event_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_category
    ADD CONSTRAINT case_events_category_event_id_key UNIQUE (event_id);


--
-- Name: case_events_category case_events_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_category
    ADD CONSTRAINT case_events_category_pkey PRIMARY KEY (id);


--
-- Name: case_events_ioc case_events_ioc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_ioc
    ADD CONSTRAINT case_events_ioc_pkey PRIMARY KEY (id);


--
-- Name: case_graph_assets case_graph_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_assets
    ADD CONSTRAINT case_graph_assets_pkey PRIMARY KEY (id);


--
-- Name: case_graph_links case_graph_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_links
    ADD CONSTRAINT case_graph_links_pkey PRIMARY KEY (id);


--
-- Name: case_kanban case_kanban_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_kanban
    ADD CONSTRAINT case_kanban_pkey PRIMARY KEY (case_id);


--
-- Name: case_protagonist case_protagonist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_protagonist
    ADD CONSTRAINT case_protagonist_pkey PRIMARY KEY (id);


--
-- Name: case_received_file case_received_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_received_file
    ADD CONSTRAINT case_received_file_pkey PRIMARY KEY (id);


--
-- Name: case_state case_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_state
    ADD CONSTRAINT case_state_pkey PRIMARY KEY (state_id);


--
-- Name: case_tags case_tags_case_id_tag_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tags
    ADD CONSTRAINT case_tags_case_id_tag_id_key PRIMARY KEY (case_id, tag_id);


--
-- Name: case_tasks case_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_pkey PRIMARY KEY (id);


--
-- Name: case_template case_template_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template
    ADD CONSTRAINT case_template_pkey PRIMARY KEY (id);


--
-- Name: case_template_report case_template_report_internal_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_internal_reference_key UNIQUE (internal_reference);


--
-- Name: case_template_report case_template_report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_pkey PRIMARY KEY (id);


--
-- Name: cases_assets_ext cases_assets_ext_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_assets_ext
    ADD CONSTRAINT cases_assets_ext_pkey PRIMARY KEY (asset_id);


--
-- Name: cases_events cases_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_events
    ADD CONSTRAINT cases_events_pkey PRIMARY KEY (event_id);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (case_id);


--
-- Name: client client_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_name_key UNIQUE (name);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (client_id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (comment_id);


--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (id);


--
-- Name: custom_attribute custom_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_attribute
    ADD CONSTRAINT custom_attribute_pkey PRIMARY KEY (attribute_id);


--
-- Name: data_store_file data_store_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_file
    ADD CONSTRAINT data_store_file_pkey PRIMARY KEY (file_id);


--
-- Name: data_store_path data_store_path_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_path
    ADD CONSTRAINT data_store_path_pkey PRIMARY KEY (path_id);


--
-- Name: event_category event_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_category
    ADD CONSTRAINT event_category_pkey PRIMARY KEY (id);


--
-- Name: event_comments event_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_pkey PRIMARY KEY (id);


--
-- Name: evidence_comments evidence_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence_comments
    ADD CONSTRAINT evidence_comments_pkey PRIMARY KEY (id);


--
-- Name: evidence_type evidence_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence_type
    ADD CONSTRAINT evidence_type_pkey PRIMARY KEY (id);


--
-- Name: global_tasks global_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_pkey PRIMARY KEY (id);


--
-- Name: group_case_access group_case_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_case_access
    ADD CONSTRAINT group_case_access_pkey PRIMARY KEY (id);


--
-- Name: groups groups_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_group_name_key UNIQUE (group_name);


--
-- Name: groups groups_group_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_group_uuid_key UNIQUE (group_uuid);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (group_id);


--
-- Name: ioc_asset_link ioc_asset_link_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_asset_link
    ADD CONSTRAINT ioc_asset_link_pkey PRIMARY KEY (ioc_asset_link_id);


--
-- Name: ioc_comments ioc_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_comments
    ADD CONSTRAINT ioc_comments_pkey PRIMARY KEY (id);


--
-- Name: ioc_link ioc_link_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_link
    ADD CONSTRAINT ioc_link_pkey PRIMARY KEY (ioc_link_id);


--
-- Name: ioc ioc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc
    ADD CONSTRAINT ioc_pkey PRIMARY KEY (ioc_id);


--
-- Name: ioc_type ioc_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_type
    ADD CONSTRAINT ioc_type_pkey PRIMARY KEY (type_id);


--
-- Name: iris_hooks iris_hooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_hooks
    ADD CONSTRAINT iris_hooks_pkey PRIMARY KEY (id);


--
-- Name: iris_module_hooks iris_module_hooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_module_hooks
    ADD CONSTRAINT iris_module_hooks_pkey PRIMARY KEY (id);


--
-- Name: iris_module iris_module_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_module
    ADD CONSTRAINT iris_module_pkey PRIMARY KEY (id);


--
-- Name: iris_reports iris_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_reports
    ADD CONSTRAINT iris_reports_pkey PRIMARY KEY (report_id);


--
-- Name: languages languages_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_code_key UNIQUE (code);


--
-- Name: languages languages_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_name_key UNIQUE (name);


--
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: note_comments note_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_comments
    ADD CONSTRAINT note_comments_pkey PRIMARY KEY (id);


--
-- Name: note_directory note_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_directory
    ADD CONSTRAINT note_directory_pkey PRIMARY KEY (id);


--
-- Name: note_revisions note_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_revisions
    ADD CONSTRAINT note_revisions_pkey PRIMARY KEY (revision_id);


--
-- Name: notes_group_link notes_group_link_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group_link
    ADD CONSTRAINT notes_group_link_pkey PRIMARY KEY (link_id);


--
-- Name: notes_group notes_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group
    ADD CONSTRAINT notes_group_pkey PRIMARY KEY (group_id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (note_id);


--
-- Name: object_state object_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.object_state
    ADD CONSTRAINT object_state_pkey PRIMARY KEY (object_id);


--
-- Name: organisation_case_access organisation_case_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organisation_case_access
    ADD CONSTRAINT organisation_case_access_pkey PRIMARY KEY (id);


--
-- Name: organisations organisations_org_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organisations
    ADD CONSTRAINT organisations_org_name_key UNIQUE (org_name);


--
-- Name: organisations organisations_org_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organisations
    ADD CONSTRAINT organisations_org_uuid_key UNIQUE (org_uuid);


--
-- Name: organisations organisations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organisations
    ADD CONSTRAINT organisations_pkey PRIMARY KEY (org_id);


--
-- Name: os_type os_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.os_type
    ADD CONSTRAINT os_type_pkey PRIMARY KEY (type_id);


--
-- Name: report_type report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_type
    ADD CONSTRAINT report_type_name_key UNIQUE (name);


--
-- Name: report_type report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_type
    ADD CONSTRAINT report_type_pkey PRIMARY KEY (id);


--
-- Name: review_status review_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_status
    ADD CONSTRAINT review_status_pkey PRIMARY KEY (id);


--
-- Name: saved_filters saved_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_filters
    ADD CONSTRAINT saved_filters_pkey PRIMARY KEY (filter_id);


--
-- Name: server_settings server_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.server_settings
    ADD CONSTRAINT server_settings_pkey PRIMARY KEY (id);


--
-- Name: severities severities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.severities
    ADD CONSTRAINT severities_pkey PRIMARY KEY (severity_id);


--
-- Name: severities severities_severity_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.severities
    ADD CONSTRAINT severities_severity_name_key UNIQUE (severity_name);


--
-- Name: silent_ridge_receipts silent_ridge_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silent_ridge_receipts
    ADD CONSTRAINT silent_ridge_receipts_pkey PRIMARY KEY (key);


--
-- Name: silent_ridge_work_status silent_ridge_work_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silent_ridge_work_status
    ADD CONSTRAINT silent_ridge_work_status_pkey PRIMARY KEY (user_id, ticket);


--
-- Name: similar_alerts_cache similar_alerts_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_tag_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_tag_title_key UNIQUE (tag_title);


--
-- Name: tags tags_tag_title_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_tag_title_key1 UNIQUE (tag_title);


--
-- Name: task_assignee task_assignee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignee
    ADD CONSTRAINT task_assignee_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: task_status task_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_pkey PRIMARY KEY (id);


--
-- Name: tlp tlp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tlp
    ADD CONSTRAINT tlp_pkey PRIMARY KEY (tlp_id);


--
-- Name: user_activity user_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity
    ADD CONSTRAINT user_activity_pkey PRIMARY KEY (id);


--
-- Name: user user_api_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_api_key_key UNIQUE (api_key);


--
-- Name: user_case_access user_case_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_case_access
    ADD CONSTRAINT user_case_access_pkey PRIMARY KEY (id);


--
-- Name: user_case_effective_access user_case_effective_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_case_effective_access
    ADD CONSTRAINT user_case_effective_access_pkey PRIMARY KEY (id);


--
-- Name: user_client user_client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_client
    ADD CONSTRAINT user_client_pkey PRIMARY KEY (id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_external_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_external_id_key UNIQUE (external_id);


--
-- Name: user_group user_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_pkey PRIMARY KEY (id);


--
-- Name: user_organisation user_organisation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_organisation
    ADD CONSTRAINT user_organisation_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user user_user_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_user_key UNIQUE ("user");


--
-- Name: user user_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_uuid_key UNIQUE (uuid);


--
-- Name: idx_alert_source_ref; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alert_source_ref ON public.alerts USING btree (alert_source_ref);


--
-- Name: idx_alerts_creation_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alerts_creation_time ON public.alerts USING btree (alert_creation_time);


--
-- Name: idx_alerts_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alerts_customer_id ON public.alerts USING btree (alert_customer_id);


--
-- Name: idx_alerts_source_event_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alerts_source_event_time ON public.alerts USING btree (alert_source_event_time);


--
-- Name: idx_alerts_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alerts_title ON public.alerts USING btree (alert_title);


--
-- Name: idx_case_assets_case_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_case_assets_case_id ON public.case_assets USING btree (case_id);


--
-- Name: idx_case_assets_date_added; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_case_assets_date_added ON public.case_assets USING btree (date_added);


--
-- Name: idx_case_assets_date_update; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_case_assets_date_update ON public.case_assets USING btree (date_update);


--
-- Name: idx_case_assets_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_case_assets_name ON public.case_assets USING btree (asset_name);


--
-- Name: idx_ioc_tags; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ioc_tags ON public.ioc USING btree (ioc_tags);


--
-- Name: idx_ioc_value_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ioc_value_hash ON public.ioc USING btree (md5(ioc_value));


--
-- Name: ix_alert_case_association_case_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_alert_case_association_case_id ON public.alert_case_association USING btree (case_id);


--
-- Name: ix_case_tags_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_case_tags_tag_id ON public.case_tags USING btree (tag_id);


--
-- Name: alert_assets_association alert_assets_association_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_assets_association
    ADD CONSTRAINT alert_assets_association_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alert_assets_association alert_assets_association_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_assets_association
    ADD CONSTRAINT alert_assets_association_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: alert_case_association alert_case_association_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_case_association
    ADD CONSTRAINT alert_case_association_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alert_case_association alert_case_association_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_case_association
    ADD CONSTRAINT alert_case_association_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: alert_iocs_association alert_iocs_association_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_iocs_association
    ADD CONSTRAINT alert_iocs_association_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alert_iocs_association alert_iocs_association_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_iocs_association
    ADD CONSTRAINT alert_iocs_association_ioc_id_fkey FOREIGN KEY (ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: alert_similarity alert_similarity_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alert_similarity alert_similarity_matching_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_matching_asset_id_fkey FOREIGN KEY (matching_asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: alert_similarity alert_similarity_matching_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_matching_ioc_id_fkey FOREIGN KEY (matching_ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: alert_similarity alert_similarity_similar_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_similar_alert_id_fkey FOREIGN KEY (similar_alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alerts alerts_alert_classification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_classification_id_fkey FOREIGN KEY (alert_classification_id) REFERENCES public.case_classification(id);


--
-- Name: alerts alerts_alert_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_customer_id_fkey FOREIGN KEY (alert_customer_id) REFERENCES public.client(client_id);


--
-- Name: alerts alerts_alert_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_owner_id_fkey FOREIGN KEY (alert_owner_id) REFERENCES public."user"(id);


--
-- Name: alerts alerts_alert_resolution_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_resolution_status_id_fkey FOREIGN KEY (alert_resolution_status_id) REFERENCES public.alert_resolution_status(resolution_status_id);


--
-- Name: alerts alerts_alert_severity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_severity_id_fkey FOREIGN KEY (alert_severity_id) REFERENCES public.severities(severity_id);


--
-- Name: alerts alerts_alert_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_status_id_fkey FOREIGN KEY (alert_status_id) REFERENCES public.alert_status(status_id);


--
-- Name: asset_comments asset_comments_comment_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asset_comments
    ADD CONSTRAINT asset_comments_comment_asset_id_fkey FOREIGN KEY (comment_asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: asset_comments asset_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asset_comments
    ADD CONSTRAINT asset_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: case_assets case_assets_analysis_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_analysis_status_id_fkey FOREIGN KEY (analysis_status_id) REFERENCES public.analysis_status(id);


--
-- Name: case_assets case_assets_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES public.assets_type(asset_id);


--
-- Name: case_assets case_assets_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_assets case_assets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: case_classification case_classification_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_classification
    ADD CONSTRAINT case_classification_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public."user"(id);


--
-- Name: case_events_assets case_events_assets_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_assets
    ADD CONSTRAINT case_events_assets_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: case_events_assets case_events_assets_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_assets
    ADD CONSTRAINT case_events_assets_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_events_assets case_events_assets_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_assets
    ADD CONSTRAINT case_events_assets_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.cases_events(event_id);


--
-- Name: case_events_category case_events_category_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_category
    ADD CONSTRAINT case_events_category_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.event_category(id);


--
-- Name: case_events_category case_events_category_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_category
    ADD CONSTRAINT case_events_category_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.cases_events(event_id);


--
-- Name: case_events_ioc case_events_ioc_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_ioc
    ADD CONSTRAINT case_events_ioc_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_events_ioc case_events_ioc_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_ioc
    ADD CONSTRAINT case_events_ioc_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.cases_events(event_id);


--
-- Name: case_events_ioc case_events_ioc_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_events_ioc
    ADD CONSTRAINT case_events_ioc_ioc_id_fkey FOREIGN KEY (ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: case_graph_assets case_graph_assets_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_assets
    ADD CONSTRAINT case_graph_assets_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES public.assets_type(asset_id);


--
-- Name: case_graph_assets case_graph_assets_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_assets
    ADD CONSTRAINT case_graph_assets_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_graph_links case_graph_links_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_links
    ADD CONSTRAINT case_graph_links_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_graph_links case_graph_links_dest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_links
    ADD CONSTRAINT case_graph_links_dest_id_fkey FOREIGN KEY (dest_id) REFERENCES public.case_graph_assets(id);


--
-- Name: case_graph_links case_graph_links_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_graph_links
    ADD CONSTRAINT case_graph_links_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.case_graph_assets(id);


--
-- Name: case_kanban case_kanban_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_kanban
    ADD CONSTRAINT case_kanban_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_protagonist case_protagonist_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_protagonist
    ADD CONSTRAINT case_protagonist_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_protagonist case_protagonist_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_protagonist
    ADD CONSTRAINT case_protagonist_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: case_received_file case_received_file_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_received_file
    ADD CONSTRAINT case_received_file_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_received_file case_received_file_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_received_file
    ADD CONSTRAINT case_received_file_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.evidence_type(id);


--
-- Name: case_received_file case_received_file_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_received_file
    ADD CONSTRAINT case_received_file_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: case_tags case_tags_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tags
    ADD CONSTRAINT case_tags_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_tags case_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tags
    ADD CONSTRAINT case_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: case_tasks case_tasks_task_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_case_id_fkey FOREIGN KEY (task_case_id) REFERENCES public.cases(case_id);


--
-- Name: case_tasks case_tasks_task_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_status_id_fkey FOREIGN KEY (task_status_id) REFERENCES public.task_status(id);


--
-- Name: case_tasks case_tasks_task_userid_close_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_userid_close_fkey FOREIGN KEY (task_userid_close) REFERENCES public."user"(id);


--
-- Name: case_tasks case_tasks_task_userid_open_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_userid_open_fkey FOREIGN KEY (task_userid_open) REFERENCES public."user"(id);


--
-- Name: case_tasks case_tasks_task_userid_update_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_userid_update_fkey FOREIGN KEY (task_userid_update) REFERENCES public."user"(id);


--
-- Name: case_template case_template_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template
    ADD CONSTRAINT case_template_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public."user"(id);


--
-- Name: case_template_report case_template_report_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public."user"(id);


--
-- Name: case_template_report case_template_report_language_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_language_id_fkey FOREIGN KEY (language_id) REFERENCES public.languages(id);


--
-- Name: case_template_report case_template_report_report_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_report_type_id_fkey FOREIGN KEY (report_type_id) REFERENCES public.report_type(id);


--
-- Name: cases_assets_ext cases_assets_ext_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_assets_ext
    ADD CONSTRAINT cases_assets_ext_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: cases_assets_ext cases_assets_ext_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_assets_ext
    ADD CONSTRAINT cases_assets_ext_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.assets_type(asset_id);


--
-- Name: cases cases_classification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_classification_id_fkey FOREIGN KEY (classification_id) REFERENCES public.case_classification(id);


--
-- Name: cases cases_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: cases_events cases_events_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_events
    ADD CONSTRAINT cases_events_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: cases_events cases_events_parent_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_events
    ADD CONSTRAINT cases_events_parent_event_id_fkey FOREIGN KEY (parent_event_id) REFERENCES public.cases_events(event_id);


--
-- Name: cases_events cases_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases_events
    ADD CONSTRAINT cases_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: cases cases_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public."user"(id);


--
-- Name: cases cases_review_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_review_status_id_fkey FOREIGN KEY (review_status_id) REFERENCES public.review_status(id);


--
-- Name: cases cases_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public."user"(id);


--
-- Name: cases cases_severity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_severity_id_fkey FOREIGN KEY (severity_id) REFERENCES public.severities(severity_id);


--
-- Name: cases cases_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_state_id_fkey FOREIGN KEY (state_id) REFERENCES public.case_state(state_id);


--
-- Name: cases cases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: client client_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_created_by_fkey FOREIGN KEY (created_by) REFERENCES public."user"(id);


--
-- Name: comments comments_comment_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_comment_alert_id_fkey FOREIGN KEY (comment_alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: comments comments_comment_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_comment_case_id_fkey FOREIGN KEY (comment_case_id) REFERENCES public.cases(case_id);


--
-- Name: comments comments_comment_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_comment_user_id_fkey FOREIGN KEY (comment_user_id) REFERENCES public."user"(id);


--
-- Name: contact contact_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: data_store_file data_store_file_added_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_file
    ADD CONSTRAINT data_store_file_added_by_user_id_fkey FOREIGN KEY (added_by_user_id) REFERENCES public."user"(id);


--
-- Name: data_store_file data_store_file_file_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_file
    ADD CONSTRAINT data_store_file_file_case_id_fkey FOREIGN KEY (file_case_id) REFERENCES public.cases(case_id);


--
-- Name: data_store_file data_store_file_file_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_file
    ADD CONSTRAINT data_store_file_file_parent_id_fkey FOREIGN KEY (file_parent_id) REFERENCES public.data_store_path(path_id);


--
-- Name: data_store_path data_store_path_path_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_path
    ADD CONSTRAINT data_store_path_path_case_id_fkey FOREIGN KEY (path_case_id) REFERENCES public.cases(case_id);


--
-- Name: event_comments event_comments_comment_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_comment_event_id_fkey FOREIGN KEY (comment_event_id) REFERENCES public.cases_events(event_id);


--
-- Name: event_comments event_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: evidence_comments evidence_comments_comment_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence_comments
    ADD CONSTRAINT evidence_comments_comment_evidence_id_fkey FOREIGN KEY (comment_evidence_id) REFERENCES public.case_received_file(id);


--
-- Name: evidence_comments evidence_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence_comments
    ADD CONSTRAINT evidence_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: evidence_type evidence_type_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence_type
    ADD CONSTRAINT evidence_type_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public."user"(id);


--
-- Name: global_tasks global_tasks_task_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_assignee_id_fkey FOREIGN KEY (task_assignee_id) REFERENCES public."user"(id);


--
-- Name: global_tasks global_tasks_task_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_status_id_fkey FOREIGN KEY (task_status_id) REFERENCES public.task_status(id);


--
-- Name: global_tasks global_tasks_task_userid_close_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_userid_close_fkey FOREIGN KEY (task_userid_close) REFERENCES public."user"(id);


--
-- Name: global_tasks global_tasks_task_userid_open_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_userid_open_fkey FOREIGN KEY (task_userid_open) REFERENCES public."user"(id);


--
-- Name: global_tasks global_tasks_task_userid_update_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_userid_update_fkey FOREIGN KEY (task_userid_update) REFERENCES public."user"(id);


--
-- Name: group_case_access group_case_access_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_case_access
    ADD CONSTRAINT group_case_access_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: group_case_access group_case_access_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_case_access
    ADD CONSTRAINT group_case_access_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(group_id);


--
-- Name: ioc_asset_link ioc_asset_link_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_asset_link
    ADD CONSTRAINT ioc_asset_link_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: ioc_asset_link ioc_asset_link_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_asset_link
    ADD CONSTRAINT ioc_asset_link_ioc_id_fkey FOREIGN KEY (ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: ioc_comments ioc_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_comments
    ADD CONSTRAINT ioc_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: ioc_comments ioc_comments_comment_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_comments
    ADD CONSTRAINT ioc_comments_comment_ioc_id_fkey FOREIGN KEY (comment_ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: ioc ioc_ioc_tlp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc
    ADD CONSTRAINT ioc_ioc_tlp_id_fkey FOREIGN KEY (ioc_tlp_id) REFERENCES public.tlp(tlp_id);


--
-- Name: ioc ioc_ioc_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc
    ADD CONSTRAINT ioc_ioc_type_id_fkey FOREIGN KEY (ioc_type_id) REFERENCES public.ioc_type(type_id);


--
-- Name: ioc_link ioc_link_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_link
    ADD CONSTRAINT ioc_link_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: ioc_link ioc_link_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc_link
    ADD CONSTRAINT ioc_link_ioc_id_fkey FOREIGN KEY (ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: ioc ioc_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ioc
    ADD CONSTRAINT ioc_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: iris_module iris_module_added_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_module
    ADD CONSTRAINT iris_module_added_by_id_fkey FOREIGN KEY (added_by_id) REFERENCES public."user"(id);


--
-- Name: iris_module_hooks iris_module_hooks_hook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_module_hooks
    ADD CONSTRAINT iris_module_hooks_hook_id_fkey FOREIGN KEY (hook_id) REFERENCES public.iris_hooks(id);


--
-- Name: iris_module_hooks iris_module_hooks_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_module_hooks
    ADD CONSTRAINT iris_module_hooks_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.iris_module(id);


--
-- Name: iris_reports iris_reports_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_reports
    ADD CONSTRAINT iris_reports_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: iris_reports iris_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_reports
    ADD CONSTRAINT iris_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: note_comments note_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_comments
    ADD CONSTRAINT note_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: note_comments note_comments_comment_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_comments
    ADD CONSTRAINT note_comments_comment_note_id_fkey FOREIGN KEY (comment_note_id) REFERENCES public.notes(note_id);


--
-- Name: note_directory note_directory_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_directory
    ADD CONSTRAINT note_directory_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: note_directory note_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_directory
    ADD CONSTRAINT note_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.note_directory(id);


--
-- Name: note_revisions note_revisions_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_revisions
    ADD CONSTRAINT note_revisions_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(note_id);


--
-- Name: note_revisions note_revisions_note_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note_revisions
    ADD CONSTRAINT note_revisions_note_user_fkey FOREIGN KEY (note_user) REFERENCES public."user"(id);


--
-- Name: notes notes_directory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_directory_id_fkey FOREIGN KEY (directory_id) REFERENCES public.note_directory(id);


--
-- Name: notes_group notes_group_group_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group
    ADD CONSTRAINT notes_group_group_case_id_fkey FOREIGN KEY (group_case_id) REFERENCES public.cases(case_id);


--
-- Name: notes_group notes_group_group_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group
    ADD CONSTRAINT notes_group_group_user_fkey FOREIGN KEY (group_user) REFERENCES public."user"(id);


--
-- Name: notes_group_link notes_group_link_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group_link
    ADD CONSTRAINT notes_group_link_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: notes_group_link notes_group_link_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group_link
    ADD CONSTRAINT notes_group_link_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.notes_group(group_id);


--
-- Name: notes_group_link notes_group_link_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes_group_link
    ADD CONSTRAINT notes_group_link_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(note_id);


--
-- Name: notes notes_note_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_note_case_id_fkey FOREIGN KEY (note_case_id) REFERENCES public.cases(case_id);


--
-- Name: notes notes_note_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_note_user_fkey FOREIGN KEY (note_user) REFERENCES public."user"(id);


--
-- Name: object_state object_state_object_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.object_state
    ADD CONSTRAINT object_state_object_case_id_fkey FOREIGN KEY (object_case_id) REFERENCES public.cases(case_id);


--
-- Name: object_state object_state_object_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.object_state
    ADD CONSTRAINT object_state_object_updated_by_id_fkey FOREIGN KEY (object_updated_by_id) REFERENCES public."user"(id);


--
-- Name: organisation_case_access organisation_case_access_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organisation_case_access
    ADD CONSTRAINT organisation_case_access_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: organisation_case_access organisation_case_access_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organisation_case_access
    ADD CONSTRAINT organisation_case_access_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organisations(org_id);


--
-- Name: saved_filters saved_filters_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_filters
    ADD CONSTRAINT saved_filters_created_by_fkey FOREIGN KEY (created_by) REFERENCES public."user"(id);


--
-- Name: similar_alerts_cache similar_alerts_cache_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: similar_alerts_cache similar_alerts_cache_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES public.assets_type(asset_id);


--
-- Name: similar_alerts_cache similar_alerts_cache_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.client(client_id);


--
-- Name: similar_alerts_cache similar_alerts_cache_ioc_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_ioc_type_id_fkey FOREIGN KEY (ioc_type_id) REFERENCES public.ioc_type(type_id);


--
-- Name: task_assignee task_assignee_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignee
    ADD CONSTRAINT task_assignee_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.case_tasks(id);


--
-- Name: task_assignee task_assignee_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignee
    ADD CONSTRAINT task_assignee_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: task_comments task_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: task_comments task_comments_comment_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_comment_task_id_fkey FOREIGN KEY (comment_task_id) REFERENCES public.case_tasks(id);


--
-- Name: user_activity user_activity_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity
    ADD CONSTRAINT user_activity_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: user_activity user_activity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity
    ADD CONSTRAINT user_activity_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_case_access user_case_access_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_case_access
    ADD CONSTRAINT user_case_access_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: user_case_access user_case_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_case_access
    ADD CONSTRAINT user_case_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_case_effective_access user_case_effective_access_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_case_effective_access
    ADD CONSTRAINT user_case_effective_access_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: user_case_effective_access user_case_effective_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_case_effective_access
    ADD CONSTRAINT user_case_effective_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_client user_client_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_client
    ADD CONSTRAINT user_client_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: user_client user_client_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_client
    ADD CONSTRAINT user_client_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_group user_group_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(group_id);


--
-- Name: user_group user_group_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_organisation user_organisation_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_organisation
    ADD CONSTRAINT user_organisation_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organisations(org_id);


--
-- Name: user_organisation user_organisation_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_organisation
    ADD CONSTRAINT user_organisation_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- PostgreSQL database dump complete
--

