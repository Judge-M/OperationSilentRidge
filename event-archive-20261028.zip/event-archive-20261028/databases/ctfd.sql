/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.19-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ctfd
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES
('a49ad66aa0f1');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `awards`
--

DROP TABLE IF EXISTS `awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `awards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `name` varchar(80) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `category` varchar(80) DEFAULT NULL,
  `icon` text DEFAULT NULL,
  `requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requirements`)),
  `type` varchar(80) DEFAULT 'standard',
  PRIMARY KEY (`id`),
  KEY `awards_ibfk_1` (`team_id`),
  KEY `awards_ibfk_2` (`user_id`),
  CONSTRAINT `awards_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `awards_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=519 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `awards`
--

LOCK TABLES `awards` WRITE;
/*!40000 ALTER TABLE `awards` DISABLE KEYS */;
INSERT INTO `awards` VALUES
(1,NULL,5,'T06-Q1','Silent Ridge accepted answer 533d10d6-f443-4f44-ba5c-31153d1d6366','2026-10-28 12:16:29.134958',4,'Silent Ridge',NULL,NULL,'standard'),
(2,NULL,5,'T06-Q2','Silent Ridge accepted answer ffddfb11-b84f-4794-b8f2-b83d7f128033','2026-10-28 12:16:42.582039',4,'Silent Ridge',NULL,NULL,'standard'),
(3,NULL,5,'T06-Q3','Silent Ridge accepted answer bf192868-8739-47c8-a09b-5ba0e3216471','2026-10-28 12:16:52.056294',4,'Silent Ridge',NULL,NULL,'standard'),
(4,NULL,5,'T06-Q4','Silent Ridge accepted answer 81c5fbd0-a8fc-4fc5-a5c2-c7e629efbede','2026-10-28 12:17:00.590051',4,'Silent Ridge',NULL,NULL,'standard'),
(5,NULL,5,'T10-Q1','Silent Ridge accepted answer e181bad1-cef3-41a3-9d9e-cd1a83a67fd2','2026-10-28 12:17:11.649328',4,'Silent Ridge',NULL,NULL,'standard'),
(6,NULL,5,'T10-Q2','Silent Ridge accepted answer 43c370f0-e811-49f6-915a-f7ea8a299d70','2026-10-28 12:17:20.465043',4,'Silent Ridge',NULL,NULL,'standard'),
(7,NULL,5,'T10-Q3','Silent Ridge accepted answer 63438147-3176-480c-90b7-26affea4ea7d','2026-10-28 12:17:31.335466',4,'Silent Ridge',NULL,NULL,'standard'),
(8,NULL,5,'T10-Q4','Silent Ridge accepted answer a15fdb0e-284b-4b25-b0e7-199a61b5fb31','2026-10-28 12:17:39.837841',4,'Silent Ridge',NULL,NULL,'standard'),
(9,NULL,5,'T08-Q1','Silent Ridge accepted answer 9295a1a8-a6a8-49e1-9866-760ed3999a27','2026-10-28 12:17:48.328289',4,'Silent Ridge',NULL,NULL,'standard'),
(10,NULL,5,'T08-Q2','Silent Ridge accepted answer 28299af5-bcea-4c0e-8b8f-db028d5c173a','2026-10-28 12:18:06.268908',4,'Silent Ridge',NULL,NULL,'standard'),
(11,NULL,5,'T08-Q3','Silent Ridge accepted answer 6ca6cee4-607f-4394-8fdf-15bdd8746465','2026-10-28 12:18:14.926371',4,'Silent Ridge',NULL,NULL,'standard'),
(12,NULL,2,'T01-Q1','Silent Ridge accepted answer 55b90e7f-1b75-4594-bb94-16bfe26f135e','2026-10-28 12:18:19.370493',4,'Silent Ridge',NULL,NULL,'standard'),
(13,NULL,5,'T08-Q4','Silent Ridge accepted answer 6b93bd4b-69a2-427a-a30a-37a82d396677','2026-10-28 12:18:22.672453',4,'Silent Ridge',NULL,NULL,'standard'),
(14,NULL,5,'T04-Q1','Silent Ridge accepted answer 28c80775-de01-4e25-b622-a853743f5bcb','2026-10-28 12:18:32.283579',4,'Silent Ridge',NULL,NULL,'standard'),
(15,NULL,5,'T04-Q2','Silent Ridge accepted answer 9e038df3-1201-43cf-9324-95b4eac841c4','2026-10-28 12:18:42.850976',4,'Silent Ridge',NULL,NULL,'standard'),
(16,NULL,5,'T04-Q3','Silent Ridge accepted answer ffa0a3c0-480c-4715-aeb7-3fc6f8788461','2026-10-28 12:19:24.563829',4,'Silent Ridge',NULL,NULL,'standard'),
(17,NULL,5,'T04-Q4','Silent Ridge accepted answer f29553b5-a279-425c-8e1c-f82d81c68882','2026-10-28 12:19:58.859077',4,'Silent Ridge',NULL,NULL,'standard'),
(18,NULL,5,'T01-Q1','Silent Ridge accepted answer 93430919-525f-4ca0-85cd-a6621ba45cbf','2026-10-28 12:21:14.657953',4,'Silent Ridge',NULL,NULL,'standard'),
(19,NULL,5,'T01-Q2','Silent Ridge accepted answer 35db250f-853d-4e48-a412-cb2d8e055289','2026-10-28 12:21:24.448966',4,'Silent Ridge',NULL,NULL,'standard'),
(20,NULL,5,'T01-Q3','Silent Ridge accepted answer d59b5fa4-4fe9-4ea4-b9d3-7158a650ed8e','2026-10-28 12:21:35.008144',4,'Silent Ridge',NULL,NULL,'standard'),
(21,NULL,5,'T01-Q4','Silent Ridge accepted answer 75a6ce55-921e-47d3-b724-bba2f731ba24','2026-10-28 12:21:46.534161',4,'Silent Ridge',NULL,NULL,'standard'),
(22,NULL,5,'T02-Q1','Silent Ridge accepted answer 95517442-3072-4f56-a155-9b6d20d52366','2026-10-28 12:22:00.417172',4,'Silent Ridge',NULL,NULL,'standard'),
(23,NULL,5,'T02-Q2','Silent Ridge accepted answer d8a97405-27ce-4566-8192-5db0c742e58f','2026-10-28 12:22:13.254260',4,'Silent Ridge',NULL,NULL,'standard'),
(24,NULL,5,'T02-Q3','Silent Ridge accepted answer 5fd5730b-759f-497e-a432-a6bf76fe2cc7','2026-10-28 12:22:22.683749',4,'Silent Ridge',NULL,NULL,'standard'),
(25,NULL,5,'T02-Q4','Silent Ridge accepted answer ca8bc95c-3884-48fa-b711-3fbfb7b48900','2026-10-28 12:22:33.483926',4,'Silent Ridge',NULL,NULL,'standard'),
(26,NULL,5,'T03-Q1','Silent Ridge accepted answer 2163f566-4e3c-44a8-b00a-fea44accc557','2026-10-28 12:22:44.578086',4,'Silent Ridge',NULL,NULL,'standard'),
(27,NULL,5,'T03-Q2','Silent Ridge accepted answer 682d0725-6304-4c9c-94ed-929320a70906','2026-10-28 12:22:53.442686',4,'Silent Ridge',NULL,NULL,'standard'),
(28,NULL,5,'T03-Q3','Silent Ridge accepted answer 62a762c0-c8e8-43a1-93b6-50b4696c1e60','2026-10-28 12:23:05.275325',4,'Silent Ridge',NULL,NULL,'standard'),
(29,NULL,5,'T03-Q4','Silent Ridge accepted answer 883df682-864f-44bb-a728-f029cf258600','2026-10-28 12:23:19.269758',4,'Silent Ridge',NULL,NULL,'standard'),
(30,NULL,5,'T07-Q1','Silent Ridge accepted answer 43c2c7c7-610a-4369-a5dc-225ac769cb5b','2026-10-28 12:23:30.158276',4,'Silent Ridge',NULL,NULL,'standard'),
(31,NULL,6,'T01-Q1','Silent Ridge accepted answer b2534cd8-6283-47e9-9a7d-f08966ca6169','2026-10-28 12:24:08.850055',4,'Silent Ridge',NULL,NULL,'standard'),
(32,NULL,5,'T07-Q2','Silent Ridge accepted answer 03c079c8-c932-453a-bcf8-d23d7d6dc7ba','2026-10-28 12:24:32.753171',4,'Silent Ridge',NULL,NULL,'standard'),
(33,NULL,5,'T07-Q3','Silent Ridge accepted answer e98b59d0-2762-49e6-b4bc-c183a92cac26','2026-10-28 12:24:41.258882',4,'Silent Ridge',NULL,NULL,'standard'),
(34,NULL,5,'T07-Q4','Silent Ridge accepted answer 77d6dfc5-ae76-4b1f-89a9-5cdf378ff85d','2026-10-28 12:26:59.298051',4,'Silent Ridge',NULL,NULL,'standard'),
(35,NULL,5,'T05-Q1','Silent Ridge accepted answer 474f8ff4-c98a-44da-97ae-019d6a9ff6b1','2026-10-28 12:27:15.103904',4,'Silent Ridge',NULL,NULL,'standard'),
(36,NULL,5,'T05-Q2','Silent Ridge accepted answer d82dc3d3-84b8-44d2-a600-b3c728b09bf5','2026-10-28 12:27:33.743199',4,'Silent Ridge',NULL,NULL,'standard'),
(37,NULL,5,'T05-Q3','Silent Ridge accepted answer a1ee8226-825a-462d-bae2-a1fa3e3e00fb','2026-10-28 12:27:46.229597',4,'Silent Ridge',NULL,NULL,'standard'),
(38,NULL,5,'T05-Q4','Silent Ridge accepted answer b8ba6244-5b0e-4680-8609-f2de9b640a20','2026-10-28 12:28:00.765274',4,'Silent Ridge',NULL,NULL,'standard'),
(39,NULL,5,'T09-Q1','Silent Ridge accepted answer cb3b4b73-0e33-450d-9ca7-68dbeddefd92','2026-10-28 12:28:12.322784',4,'Silent Ridge',NULL,NULL,'standard'),
(40,NULL,5,'T09-Q2','Silent Ridge accepted answer 521588b7-08f9-4cef-958b-5dac1932490a','2026-10-28 12:28:23.924936',4,'Silent Ridge',NULL,NULL,'standard'),
(41,NULL,4,'T01-Q1','Silent Ridge accepted answer f02a2aa8-fe82-4885-94d7-00899336b573','2026-10-28 12:28:36.446321',4,'Silent Ridge',NULL,NULL,'standard'),
(42,NULL,5,'T09-Q3','Silent Ridge accepted answer e910cf05-d3b2-45c6-bfc3-ef633cb2a9b0','2026-10-28 12:28:36.679729',4,'Silent Ridge',NULL,NULL,'standard'),
(43,NULL,5,'T09-Q4','Silent Ridge accepted answer 4b4e9aa2-8bad-47c2-90e3-c1d35b6ff472','2026-10-28 12:28:53.316020',4,'Silent Ridge',NULL,NULL,'standard'),
(44,NULL,4,'T01-Q2','Silent Ridge accepted answer 4479a22e-08b0-4c74-bc5a-88ea12dacb22','2026-10-28 12:29:49.573025',4,'Silent Ridge',NULL,NULL,'standard'),
(45,NULL,5,'T11-Q1','Silent Ridge accepted answer 1316037d-3648-4036-93fc-a4a4c526e483','2026-10-28 12:31:44.822846',4,'Silent Ridge',NULL,NULL,'standard'),
(46,NULL,5,'T11-Q2','Silent Ridge accepted answer 66d34069-b749-4435-be50-cef6ea2798ef','2026-10-28 12:32:00.419091',4,'Silent Ridge',NULL,NULL,'standard'),
(47,NULL,5,'T11-Q3','Silent Ridge accepted answer 48ae530c-a9d9-431e-a831-b8307b11dbcf','2026-10-28 12:33:39.139538',4,'Silent Ridge',NULL,NULL,'standard'),
(48,NULL,5,'T11-Q4','Silent Ridge accepted answer 89672e91-c8b2-4a3d-859e-22ee756c32cc','2026-10-28 12:33:51.732237',4,'Silent Ridge',NULL,NULL,'standard'),
(49,NULL,5,'T12-Q1','Silent Ridge accepted answer 69255792-06b6-42af-aad4-6330a64c86f1','2026-10-28 12:34:10.438202',4,'Silent Ridge',NULL,NULL,'standard'),
(50,NULL,5,'T12-Q2','Silent Ridge accepted answer 3ae28fda-d2b5-4416-94fe-dcdf4ec3f606','2026-10-28 12:34:22.883364',4,'Silent Ridge',NULL,NULL,'standard'),
(51,NULL,5,'T12-Q3','Silent Ridge accepted answer 64f6b36f-4085-4619-a4d1-98faea1c994b','2026-10-28 12:34:36.527862',4,'Silent Ridge',NULL,NULL,'standard'),
(52,NULL,5,'T12-Q4','Silent Ridge accepted answer 1b0f5726-62ff-4882-bdfd-b46827daa75e','2026-10-28 12:34:49.995399',4,'Silent Ridge',NULL,NULL,'standard'),
(53,NULL,5,'T13-Q1','Silent Ridge accepted answer 13df3ccf-31e0-41fa-a692-b37f6a1d71a2','2026-10-28 12:35:02.438559',4,'Silent Ridge',NULL,NULL,'standard'),
(54,NULL,5,'T13-Q2','Silent Ridge accepted answer a1586145-22b9-488c-bf76-c81d1c447bb1','2026-10-28 12:35:14.983065',4,'Silent Ridge',NULL,NULL,'standard'),
(55,NULL,2,'T01-Q2','Silent Ridge accepted answer c0ce5ad3-1d9b-42ae-86d4-4576d13c3c1a','2026-10-28 12:35:22.453068',1,'Silent Ridge',NULL,NULL,'standard'),
(56,NULL,5,'T13-Q3','Silent Ridge accepted answer 0297646d-b3ee-4c68-97f2-d0fac94a23e9','2026-10-28 12:35:28.823142',4,'Silent Ridge',NULL,NULL,'standard'),
(57,NULL,5,'T13-Q4','Silent Ridge accepted answer c4f4b06e-884e-4ee6-ba2a-34a9133df561','2026-10-28 12:35:41.333051',4,'Silent Ridge',NULL,NULL,'standard'),
(58,NULL,5,'T14-Q1','Silent Ridge accepted answer e40779ea-bc2c-4c99-ade7-11dfbf749a8a','2026-10-28 12:35:54.921737',4,'Silent Ridge',NULL,NULL,'standard'),
(59,NULL,5,'T14-Q2','Silent Ridge accepted answer 40206bf8-09e9-42fe-8e0b-663ef1194685','2026-10-28 12:36:29.903758',4,'Silent Ridge',NULL,NULL,'standard'),
(60,NULL,6,'T01-Q3','Silent Ridge accepted answer 282ddbd4-c331-418c-ab9b-4d408cbb081d','2026-10-28 12:36:41.409101',4,'Silent Ridge',NULL,NULL,'standard'),
(61,NULL,5,'T14-Q3','Silent Ridge accepted answer d980dc68-f256-48f7-8e3a-e11be6fb8575','2026-10-28 12:36:44.698348',4,'Silent Ridge',NULL,NULL,'standard'),
(62,NULL,5,'T14-Q4','Silent Ridge accepted answer a02e3f20-db6a-4369-8797-32fddd347f7b','2026-10-28 12:36:56.232613',4,'Silent Ridge',NULL,NULL,'standard'),
(63,NULL,5,'T15-Q1','Silent Ridge accepted answer 4c851af6-2800-44e3-a823-fa39db47eb4d','2026-10-28 12:37:09.956241',4,'Silent Ridge',NULL,NULL,'standard'),
(64,NULL,5,'T15-Q2','Silent Ridge accepted answer f09fce7c-c1fa-4a00-94c2-f178c7c8d28d','2026-10-28 12:37:22.542765',4,'Silent Ridge',NULL,NULL,'standard'),
(65,NULL,5,'T15-Q3','Silent Ridge accepted answer 3baede41-6af0-4c3c-96ed-1aafeaf24290','2026-10-28 12:37:35.235431',4,'Silent Ridge',NULL,NULL,'standard'),
(66,NULL,5,'T15-Q4','Silent Ridge accepted answer fef236f1-3ea7-4df4-a03b-ce1fab149e71','2026-10-28 12:37:49.860854',4,'Silent Ridge',NULL,NULL,'standard'),
(67,NULL,5,'T16-Q1','Silent Ridge accepted answer 97c75d41-5609-4aa9-a13f-6bbad41c4ca2','2026-10-28 12:39:20.047299',4,'Silent Ridge',NULL,NULL,'standard'),
(68,NULL,5,'T16-Q2','Silent Ridge accepted answer 39b45621-c300-4f2b-9850-5b7e92db32df','2026-10-28 12:39:31.526350',4,'Silent Ridge',NULL,NULL,'standard'),
(69,NULL,5,'T16-Q3','Silent Ridge accepted answer 92afd239-cd9c-4762-bb11-a12aa7a7ccf4','2026-10-28 12:39:41.979734',4,'Silent Ridge',NULL,NULL,'standard'),
(70,NULL,5,'T16-Q4','Silent Ridge accepted answer 4b66089f-928c-4b2c-b03c-d2c7eeb0fb45','2026-10-28 12:39:54.517430',4,'Silent Ridge',NULL,NULL,'standard'),
(71,NULL,5,'T17-Q1','Silent Ridge accepted answer ed1b3928-d3ad-4a78-b1ba-3ea9049d4d41','2026-10-28 12:40:10.177531',4,'Silent Ridge',NULL,NULL,'standard'),
(72,NULL,5,'T17-Q2','Silent Ridge accepted answer e916f246-1810-4b01-8732-be5df3cb6fa0','2026-10-28 12:40:19.752281',4,'Silent Ridge',NULL,NULL,'standard'),
(73,NULL,5,'T17-Q3','Silent Ridge accepted answer cd6c119d-e037-4f2b-890c-0d88e02728b9','2026-10-28 12:40:32.347850',4,'Silent Ridge',NULL,NULL,'standard'),
(74,NULL,5,'T17-Q4','Silent Ridge accepted answer 383f4cab-faef-4c57-805c-07a0515343ee','2026-10-28 12:40:41.720058',4,'Silent Ridge',NULL,NULL,'standard'),
(75,NULL,5,'T18-Q1','Silent Ridge accepted answer 3202a50b-55d1-49ee-af5d-324b42cdd638','2026-10-28 12:40:51.250916',4,'Silent Ridge',NULL,NULL,'standard'),
(76,NULL,5,'T18-Q2','Silent Ridge accepted answer 66dc4983-eaeb-406a-b0e0-51bc2caa2a60','2026-10-28 12:41:01.682515',4,'Silent Ridge',NULL,NULL,'standard'),
(77,NULL,5,'T18-Q3','Silent Ridge accepted answer c362cb4a-19e5-4ec1-b516-ae57ab5238b9','2026-10-28 12:41:10.075664',4,'Silent Ridge',NULL,NULL,'standard'),
(78,NULL,5,'T18-Q4','Silent Ridge accepted answer 7c74cedb-03f8-4271-839f-800a3c6503ba','2026-10-28 12:41:20.543797',4,'Silent Ridge',NULL,NULL,'standard'),
(79,NULL,5,'T19-Q1','Silent Ridge accepted answer d48a5261-62cb-41c0-ae35-46a4c2ea0f41','2026-10-28 12:41:30.976259',4,'Silent Ridge',NULL,NULL,'standard'),
(80,NULL,5,'T19-Q2','Silent Ridge accepted answer b38b5360-03e8-4c1e-b1ac-8cb41d228684','2026-10-28 12:41:40.399048',4,'Silent Ridge',NULL,NULL,'standard'),
(81,NULL,5,'T19-Q3','Silent Ridge accepted answer 48b728ff-dfdb-4b49-988f-0c16d8e53dcc','2026-10-28 12:41:50.842815',4,'Silent Ridge',NULL,NULL,'standard'),
(82,NULL,5,'T19-Q4','Silent Ridge accepted answer 8f3787f9-b610-44cf-90b8-898dd53d62c5','2026-10-28 12:42:00.225383',4,'Silent Ridge',NULL,NULL,'standard'),
(83,NULL,2,'T01-Q3','Silent Ridge accepted answer 2d1489ea-605b-42c7-8795-30b0bff070a6','2026-10-28 12:42:08.737693',4,'Silent Ridge',NULL,NULL,'standard'),
(84,NULL,4,'T01-Q3','Silent Ridge accepted answer d298c221-9b6f-47af-882a-e68068789b68','2026-10-28 12:42:19.292945',4,'Silent Ridge',NULL,NULL,'standard'),
(85,NULL,4,'T01-Q4','Silent Ridge accepted answer 33b7a059-7c7c-4156-9748-fca344fbbd8b','2026-10-28 12:42:44.062156',4,'Silent Ridge',NULL,NULL,'standard'),
(86,NULL,5,'T20-Q1','Silent Ridge accepted answer d870a382-e378-45e0-b91a-f1d3ab09dda3','2026-10-28 12:43:09.799814',4,'Silent Ridge',NULL,NULL,'standard'),
(87,NULL,5,'T20-Q2','Silent Ridge accepted answer b068cac2-70c4-4c8d-84e5-ef1ea11b8726','2026-10-28 12:43:27.561067',4,'Silent Ridge',NULL,NULL,'standard'),
(88,NULL,5,'T20-Q3','Silent Ridge accepted answer da9f274b-bfd1-429d-9ec3-173381b326fc','2026-10-28 12:43:37.097976',4,'Silent Ridge',NULL,NULL,'standard'),
(89,NULL,5,'T20-Q4','Silent Ridge accepted answer d80de267-9346-42f3-81c7-7a8805f85c16','2026-10-28 12:43:48.600088',4,'Silent Ridge',NULL,NULL,'standard'),
(90,NULL,6,'T01-Q4','Silent Ridge accepted answer b7e9f891-544e-44af-934c-24ee4016d574','2026-10-28 12:43:48.992500',4,'Silent Ridge',NULL,NULL,'standard'),
(91,NULL,6,'T01-Q2','Silent Ridge accepted answer 8d39980c-927d-4a4b-a1de-dcc856f81451','2026-10-28 12:46:25.093919',4,'Silent Ridge',NULL,NULL,'standard'),
(92,NULL,4,'T02-Q1','Silent Ridge accepted answer cd194113-dde3-43c6-affb-beead6901e15','2026-10-28 12:46:58.037561',4,'Silent Ridge',NULL,NULL,'standard'),
(93,NULL,4,'T02-Q2','Silent Ridge accepted answer 22631812-8343-4e7f-96c4-fdcdda993118','2026-10-28 12:47:06.439892',4,'Silent Ridge',NULL,NULL,'standard'),
(94,NULL,2,'T02-Q1','Silent Ridge accepted answer 2840f77a-d862-4b74-bab3-d7629e44699d','2026-10-28 12:48:05.087574',4,'Silent Ridge',NULL,NULL,'standard'),
(95,NULL,6,'T02-Q2','Silent Ridge accepted answer ebe5e305-6f25-46f8-8ab0-6bccf40c8676','2026-10-28 12:48:47.261051',4,'Silent Ridge',NULL,NULL,'standard'),
(96,NULL,2,'T01-Q4','Silent Ridge accepted answer 819d2668-64d7-478d-815d-f9429f7b3531','2026-10-28 12:50:41.294047',4,'Silent Ridge',NULL,NULL,'standard'),
(97,NULL,6,'T02-Q1','Silent Ridge accepted answer c36086dc-060d-46f9-9264-19920a264dea','2026-10-28 12:52:31.298664',4,'Silent Ridge',NULL,NULL,'standard'),
(98,NULL,2,'T02-Q2','Silent Ridge accepted answer 9067fab6-1533-4ffc-8854-11e3863ae11c','2026-10-28 12:54:20.779993',4,'Silent Ridge',NULL,NULL,'standard'),
(99,NULL,6,'T02-Q3','Silent Ridge accepted answer 3801a954-096a-4657-9dbf-0fdde524411a','2026-10-28 12:54:44.511897',4,'Silent Ridge',NULL,NULL,'standard'),
(100,NULL,2,'T02-Q3','Silent Ridge accepted answer 653a4a51-4c17-426f-a34a-f1c2aee16401','2026-10-28 12:55:06.168766',4,'Silent Ridge',NULL,NULL,'standard'),
(101,NULL,2,'T02-Q4','Silent Ridge accepted answer 2164ec9c-25a4-4550-a53b-e363e551aa9f','2026-10-28 12:55:47.311855',4,'Silent Ridge',NULL,NULL,'standard'),
(102,NULL,2,'T03-Q1','Silent Ridge accepted answer f93be7a5-9cdf-4fa3-97ec-6d02aab08db7','2026-10-28 12:58:16.421951',4,'Silent Ridge',NULL,NULL,'standard'),
(103,NULL,2,'T03-Q2','Silent Ridge accepted answer 0b7b7cf0-c731-4a61-9a21-99f4aa3c41af','2026-10-28 13:00:02.868196',4,'Silent Ridge',NULL,NULL,'standard'),
(104,NULL,6,'T02-Q4','Silent Ridge accepted answer c555c14b-3269-48cc-a6e4-0dde64232ada','2026-10-28 13:01:49.431950',4,'Silent Ridge',NULL,NULL,'standard'),
(105,NULL,2,'T03-Q3','Silent Ridge accepted answer 31474734-cee4-4a91-a6c8-d6b043a77995','2026-10-28 13:02:05.022485',4,'Silent Ridge',NULL,NULL,'standard'),
(106,NULL,4,'T02-Q3','Silent Ridge accepted answer 9a073119-101f-4f31-bc89-375ce3730038','2026-10-28 13:02:31.845006',4,'Silent Ridge',NULL,NULL,'standard'),
(107,NULL,2,'T03-Q4','Silent Ridge accepted answer a8f3c88f-7db1-48b0-b7fe-faca3b20a9e1','2026-10-28 13:02:41.387012',4,'Silent Ridge',NULL,NULL,'standard'),
(108,NULL,4,'T02-Q4','Silent Ridge accepted answer 39449789-c9d7-4319-9521-9f4d9f86ca31','2026-10-28 13:04:35.539142',4,'Silent Ridge',NULL,NULL,'standard'),
(109,NULL,3,'T01-Q1','Silent Ridge accepted answer 6ca92d3d-2488-4cbd-ab88-8fe7ba323fac','2026-10-28 13:05:53.931234',4,'Silent Ridge',NULL,NULL,'standard'),
(110,NULL,3,'T01-Q2','Silent Ridge accepted answer 6e552c37-d7d6-4068-8f5c-07322eb7d817','2026-10-28 13:11:57.437438',4,'Silent Ridge',NULL,NULL,'standard'),
(111,NULL,3,'T02-Q1','Silent Ridge accepted answer 6529c2c0-959b-41e7-944d-c01f5d796292','2026-10-28 13:21:52.064044',4,'Silent Ridge',NULL,NULL,'standard'),
(112,NULL,3,'T02-Q2','Silent Ridge accepted answer 538d8917-ab21-4f2f-a759-523d52a87fe7','2026-10-28 13:24:19.450006',4,'Silent Ridge',NULL,NULL,'standard'),
(113,NULL,4,'T03-Q1','Silent Ridge accepted answer 6af05e20-7155-42e4-9bea-763912150d1d','2026-10-28 13:25:23.312606',4,'Silent Ridge',NULL,NULL,'standard'),
(114,NULL,4,'T03-Q2','Silent Ridge accepted answer 6ce411ed-8990-4280-8404-45689fb0f6f9','2026-10-28 13:26:08.685299',4,'Silent Ridge',NULL,NULL,'standard'),
(115,NULL,8,'T01-Q1','Silent Ridge accepted answer 16a7529c-34f7-4b2d-b7a4-906344b217eb','2026-10-28 13:28:23.281968',4,'Silent Ridge',NULL,NULL,'standard'),
(116,NULL,8,'T01-Q2','Silent Ridge accepted answer 3c2d8799-5062-4e3b-966d-f483162da93a','2026-10-28 13:31:47.329621',4,'Silent Ridge',NULL,NULL,'standard'),
(117,NULL,3,'T02-Q3','Silent Ridge accepted answer 8dd67a7d-fc6c-43b0-bbe3-2540b0520f68','2026-10-28 13:31:59.867881',4,'Silent Ridge',NULL,NULL,'standard'),
(118,NULL,8,'T01-Q3','Silent Ridge accepted answer 47835746-ae03-4d62-a884-a111ef7a407a','2026-10-28 13:32:08.300035',4,'Silent Ridge',NULL,NULL,'standard'),
(119,NULL,6,'T06-Q1','Silent Ridge accepted answer 649201d5-d422-4a65-af5c-74e73d8ade25','2026-10-28 13:32:18.883005',4,'Silent Ridge',NULL,NULL,'standard'),
(120,NULL,8,'T01-Q4','Silent Ridge accepted answer 9ddccbbf-8229-4013-9d6f-8aef8a447a29','2026-10-28 13:33:24.612237',4,'Silent Ridge',NULL,NULL,'standard'),
(121,NULL,6,'T06-Q2','Silent Ridge accepted answer 2d45bd3a-691c-4e73-a099-6afca7cb0aac','2026-10-28 13:34:38.521596',4,'Silent Ridge',NULL,NULL,'standard'),
(122,NULL,6,'T06-Q3','Silent Ridge accepted answer 3db50541-c8f9-4840-a34a-669b133b91b5','2026-10-28 13:36:18.888632',4,'Silent Ridge',NULL,NULL,'standard'),
(123,NULL,2,'T04-Q1','Silent Ridge accepted answer d723cad5-3f73-4d53-a6dd-4e71832df359','2026-10-28 13:37:42.068877',4,'Silent Ridge',NULL,NULL,'standard'),
(124,NULL,3,'T01-Q3','Silent Ridge accepted answer 9144b82a-2d84-4cbd-b963-6bc3c684e24a','2026-10-28 13:37:42.337121',4,'Silent Ridge',NULL,NULL,'standard'),
(125,NULL,3,'T01-Q4','Silent Ridge accepted answer bc3dff24-0ff7-4d6a-9548-971f7fdabbb9','2026-10-28 13:38:16.478526',4,'Silent Ridge',NULL,NULL,'standard'),
(126,NULL,8,'T02-Q1','Silent Ridge accepted answer 7b0e759d-421f-4110-a609-528803367788','2026-10-28 13:39:00.728993',4,'Silent Ridge',NULL,NULL,'standard'),
(127,NULL,6,'T06-Q4','Silent Ridge accepted answer e9f724ae-6ae4-4f72-bd56-a29cbeaa62f7','2026-10-28 13:39:09.140295',4,'Silent Ridge',NULL,NULL,'standard'),
(128,NULL,3,'T02-Q4','Silent Ridge accepted answer cc881095-0fb7-455f-a2cc-336fbd93b0de','2026-10-28 13:39:51.577235',4,'Silent Ridge',NULL,NULL,'standard'),
(129,NULL,8,'T02-Q2','Silent Ridge accepted answer a9916532-8398-4829-b3ce-235a7dd9ae76','2026-10-28 13:40:14.382125',4,'Silent Ridge',NULL,NULL,'standard'),
(130,NULL,4,'T03-Q4','Silent Ridge accepted answer a7507305-ab1a-4019-9644-8fcb19691ef2','2026-10-28 13:40:48.413411',4,'Silent Ridge',NULL,NULL,'standard'),
(131,NULL,8,'T02-Q3','Silent Ridge accepted answer 7af954e3-13b0-4b51-aa49-ede8ada6b156','2026-10-28 13:41:46.163541',4,'Silent Ridge',NULL,NULL,'standard'),
(132,NULL,8,'T02-Q4','Silent Ridge accepted answer 65adc50f-4b19-42ff-aee3-5c765c2fc925','2026-10-28 13:42:05.757512',4,'Silent Ridge',NULL,NULL,'standard'),
(133,NULL,2,'T04-Q2','Silent Ridge accepted answer 277d163e-7792-4eb3-8e1a-444c62bc5b7f','2026-10-28 13:45:50.736061',4,'Silent Ridge',NULL,NULL,'standard'),
(134,NULL,2,'T04-Q3','Silent Ridge accepted answer dbf76bbf-31cc-43a3-a233-992955258a4d','2026-10-28 13:46:35.883273',4,'Silent Ridge',NULL,NULL,'standard'),
(135,NULL,6,'T10-Q3','Silent Ridge accepted answer a95177a0-ec28-44f6-b610-6c04410569c6','2026-10-28 13:49:04.129448',4,'Silent Ridge',NULL,NULL,'standard'),
(136,NULL,2,'T04-Q4','Silent Ridge accepted answer f497dab5-7461-46d0-998f-e126009c02bf','2026-10-28 13:49:35.099419',4,'Silent Ridge',NULL,NULL,'standard'),
(137,NULL,3,'T04-Q1','Silent Ridge accepted answer 1de8f1ed-2808-4ef9-89ca-6be26e294078','2026-10-28 13:50:10.090815',4,'Silent Ridge',NULL,NULL,'standard'),
(138,NULL,3,'T03-Q1','Silent Ridge accepted answer 8a54aba8-059b-4497-a94d-bb9c4364781c','2026-10-28 13:50:12.363587',4,'Silent Ridge',NULL,NULL,'standard'),
(139,NULL,3,'T04-Q2','Silent Ridge accepted answer bf716871-5e3e-4fd2-8baa-95adaf18b913','2026-10-28 13:50:52.555854',4,'Silent Ridge',NULL,NULL,'standard'),
(140,NULL,3,'T03-Q2','Silent Ridge accepted answer 1f375816-ce2a-40d1-ad82-4c16aa1b6fca','2026-10-28 13:51:11.245282',4,'Silent Ridge',NULL,NULL,'standard'),
(141,NULL,9,'T03-Q1','Silent Ridge accepted answer a80d62a3-5606-45b0-b211-3083d067f951','2026-10-28 13:51:11.478386',4,'Silent Ridge',NULL,NULL,'standard'),
(142,NULL,9,'T03-Q2','Silent Ridge accepted answer 5577893e-aba7-45dc-9d8a-36328ecf6552','2026-10-28 13:52:48.841065',4,'Silent Ridge',NULL,NULL,'standard'),
(143,NULL,6,'T10-Q1','Silent Ridge accepted answer 104e2d90-05a7-4815-a678-c6922e85d162','2026-10-28 13:53:19.726549',4,'Silent Ridge',NULL,NULL,'standard'),
(144,NULL,3,'T04-Q3','Silent Ridge accepted answer aaff7d9c-2c62-4173-b0c2-e5aed5bda097','2026-10-28 13:53:25.127745',4,'Silent Ridge',NULL,NULL,'standard'),
(145,NULL,2,'T05-Q1','Silent Ridge accepted answer 5a362aa4-bc3d-48dd-a632-ff30bece08ba','2026-10-28 13:54:00.233772',4,'Silent Ridge',NULL,NULL,'standard'),
(146,NULL,9,'T03-Q3','Silent Ridge accepted answer 81456cdf-c57d-4ae0-b5b1-e2b18d58077f','2026-10-28 13:54:01.479443',4,'Silent Ridge',NULL,NULL,'standard'),
(147,NULL,2,'T05-Q2','Silent Ridge accepted answer 8283ce27-3160-40f0-a00f-7349f6d7e978','2026-10-28 13:54:48.948179',4,'Silent Ridge',NULL,NULL,'standard'),
(148,NULL,3,'T03-Q4','Silent Ridge accepted answer 372f3304-7778-4907-849e-353c26a8c3f4','2026-10-28 13:55:01.654516',4,'Silent Ridge',NULL,NULL,'standard'),
(149,NULL,2,'T05-Q3','Silent Ridge accepted answer 4279880b-c0ac-43aa-875d-4c04a3dbe5df','2026-10-28 13:55:03.944786',4,'Silent Ridge',NULL,NULL,'standard'),
(150,NULL,2,'T05-Q4','Silent Ridge accepted answer 58448d21-0021-40a2-b626-dbbf4a4483f7','2026-10-28 13:55:14.460411',4,'Silent Ridge',NULL,NULL,'standard'),
(151,NULL,9,'T03-Q4','Silent Ridge accepted answer ecc7486f-f79c-403d-bcf4-4d9d51889a82','2026-10-28 13:55:38.291624',4,'Silent Ridge',NULL,NULL,'standard'),
(152,NULL,6,'T10-Q2','Silent Ridge accepted answer 416c2a5f-b8cb-4c79-aa75-a2899f963645','2026-10-28 13:59:12.932408',4,'Silent Ridge',NULL,NULL,'standard'),
(153,NULL,9,'T01-Q1','Silent Ridge accepted answer 8852eab3-5464-4152-ab43-ab1f957b1373','2026-10-28 14:00:41.524630',4,'Silent Ridge',NULL,NULL,'standard'),
(154,NULL,4,'T03-Q3','Silent Ridge accepted answer cd165223-c037-4602-b3f9-0b1fd881a7dd','2026-10-28 14:01:24.611597',4,'Silent Ridge',NULL,NULL,'standard'),
(155,NULL,3,'T04-Q4','Silent Ridge accepted answer 54d3cd31-2b3b-4c96-884a-813ca9343700','2026-10-28 14:01:55.594785',4,'Silent Ridge',NULL,NULL,'standard'),
(156,NULL,6,'T07-Q1','Silent Ridge accepted answer 3a55ca5d-20a1-4114-8dfe-1b9bbd2951f5','2026-10-28 14:02:09.114234',4,'Silent Ridge',NULL,NULL,'standard'),
(157,NULL,2,'T06-Q1','Silent Ridge accepted answer f7596c0a-e909-401a-85e5-70befb11dab8','2026-10-28 14:03:17.076940',4,'Silent Ridge',NULL,NULL,'standard'),
(158,NULL,6,'T07-Q2','Silent Ridge accepted answer 3bdccf48-a3b9-4ee1-8847-168a6b9fbcfe','2026-10-28 14:04:16.891121',4,'Silent Ridge',NULL,NULL,'standard'),
(159,NULL,9,'T01-Q2','Silent Ridge accepted answer 142c394a-a14e-4340-819d-1bff621ca086','2026-10-28 14:04:20.191718',4,'Silent Ridge',NULL,NULL,'standard'),
(160,NULL,4,'T04-Q1','Silent Ridge accepted answer 6b7e94ac-7010-4a89-aee8-dba859551749','2026-10-28 14:04:34.801565',4,'Silent Ridge',NULL,NULL,'standard'),
(161,NULL,3,'T05-Q1','Silent Ridge accepted answer f0a3f654-73ed-4689-a4d6-c1d37f46e1e8','2026-10-28 14:04:43.291232',4,'Silent Ridge',NULL,NULL,'standard'),
(162,NULL,3,'T05-Q2','Silent Ridge accepted answer 1e6b4f81-b65e-4337-ad3e-953eb5dbbe84','2026-10-28 14:05:07.231971',4,'Silent Ridge',NULL,NULL,'standard'),
(163,NULL,6,'T07-Q3','Silent Ridge accepted answer c5eaacde-3720-455a-bfa7-c57fbbe2dc99','2026-10-28 14:05:09.740523',4,'Silent Ridge',NULL,NULL,'standard'),
(164,NULL,3,'T05-Q3','Silent Ridge accepted answer bf56aa80-498a-42a2-bf18-3d63deacde02','2026-10-28 14:05:26.400973',4,'Silent Ridge',NULL,NULL,'standard'),
(165,NULL,3,'T05-Q4','Silent Ridge accepted answer 49ac612d-3f1a-4db5-b208-a29a2d1b4513','2026-10-28 14:05:41.127731',4,'Silent Ridge',NULL,NULL,'standard'),
(166,NULL,2,'T06-Q2','Silent Ridge accepted answer fdb0aed4-8d8d-481e-89c7-670fe78085c8','2026-10-28 14:05:53.608458',4,'Silent Ridge',NULL,NULL,'standard'),
(167,NULL,9,'T01-Q3','Silent Ridge accepted answer c994cb60-8746-4232-9240-f7ac5d0a5f36','2026-10-28 14:06:21.331584',4,'Silent Ridge',NULL,NULL,'standard'),
(168,NULL,2,'T06-Q3','Silent Ridge accepted answer 05150a21-774a-454f-8486-3356ccaa7e17','2026-10-28 14:07:01.392347',4,'Silent Ridge',NULL,NULL,'standard'),
(169,NULL,6,'T10-Q4','Silent Ridge accepted answer c2de8242-40d4-4875-9a93-6330dc3209a5','2026-10-28 14:07:20.012448',4,'Silent Ridge',NULL,NULL,'standard'),
(170,NULL,2,'T06-Q4','Silent Ridge accepted answer 69d7096d-6e18-4f21-b65d-d64cc3056656','2026-10-28 14:08:15.440068',4,'Silent Ridge',NULL,NULL,'standard'),
(171,NULL,3,'T06-Q1','Silent Ridge accepted answer a41998cd-412b-4d4d-8e9f-6410d305d0ea','2026-10-28 14:09:16.998935',4,'Silent Ridge',NULL,NULL,'standard'),
(172,NULL,4,'T04-Q2','Silent Ridge accepted answer cba511ec-99bf-4b83-9b23-723b2a8f6e31','2026-10-28 14:10:41.905197',4,'Silent Ridge',NULL,NULL,'standard'),
(173,NULL,6,'T07-Q4','Silent Ridge accepted answer a3fed4df-e64d-4215-b464-de0af0687b18','2026-10-28 14:11:52.529390',4,'Silent Ridge',NULL,NULL,'standard'),
(174,NULL,8,'T06-Q1','Silent Ridge accepted answer bcc740f9-1601-4f71-9a07-c84fdc79b881','2026-10-28 14:12:27.406577',4,'Silent Ridge',NULL,NULL,'standard'),
(175,NULL,9,'T04-Q1','Silent Ridge accepted answer 1796ca25-3fc0-4754-aea4-d2b152647588','2026-10-28 14:13:30.806791',4,'Silent Ridge',NULL,NULL,'standard'),
(176,NULL,8,'T10-Q4','Silent Ridge accepted answer 84670b38-19ae-4cd9-8fa9-4469d2d930e8','2026-10-28 14:13:51.377044',4,'Silent Ridge',NULL,NULL,'standard'),
(177,NULL,9,'T04-Q2','Silent Ridge accepted answer 423467a5-9c80-48e6-804b-dbd78d506146','2026-10-28 14:14:43.724894',4,'Silent Ridge',NULL,NULL,'standard'),
(178,NULL,9,'T04-Q3','Silent Ridge accepted answer 183ba1a7-2846-43e3-8e9f-018094973da3','2026-10-28 14:15:33.994631',4,'Silent Ridge',NULL,NULL,'standard'),
(179,NULL,9,'T01-Q4','Silent Ridge accepted answer f07cc93d-b66c-4d1d-b2fa-d99be1b2c4ea','2026-10-28 14:15:57.840140',1,'Silent Ridge',NULL,NULL,'standard'),
(180,NULL,2,'T07-Q1','Silent Ridge accepted answer b938a8bf-65a5-4921-9654-5f3f5284b3a3','2026-10-28 14:16:08.264799',4,'Silent Ridge',NULL,NULL,'standard'),
(181,NULL,8,'T10-Q1','Silent Ridge accepted answer 94b622b6-b570-4deb-b2ed-23ce07d69579','2026-10-28 14:18:20.207850',4,'Silent Ridge',NULL,NULL,'standard'),
(182,NULL,8,'T10-Q3','Silent Ridge accepted answer cb6e5a0a-ecbf-4e61-80a7-236e32b62cbb','2026-10-28 14:19:01.355493',4,'Silent Ridge',NULL,NULL,'standard'),
(183,NULL,4,'T04-Q3','Silent Ridge accepted answer 23ea4da0-5213-4e5a-ab29-473ad969ae53','2026-10-28 14:19:01.570059',4,'Silent Ridge',NULL,NULL,'standard'),
(184,NULL,8,'T10-Q2','Silent Ridge accepted answer f9a346e3-18d3-4ca4-be42-e3e1192c9222','2026-10-28 14:19:28.431848',4,'Silent Ridge',NULL,NULL,'standard'),
(185,NULL,4,'T04-Q4','Silent Ridge accepted answer 0acdb658-7664-4178-80df-081e3386c7df','2026-10-28 14:20:15.036852',4,'Silent Ridge',NULL,NULL,'standard'),
(186,NULL,2,'T07-Q2','Silent Ridge accepted answer 347e8062-eef2-4fcb-94c7-04c43db08044','2026-10-28 14:20:19.335684',4,'Silent Ridge',NULL,NULL,'standard'),
(187,NULL,8,'T08-Q4','Silent Ridge accepted answer fdb13663-b333-4b98-8679-3080d81c14ee','2026-10-28 14:20:43.044786',4,'Silent Ridge',NULL,NULL,'standard'),
(188,NULL,2,'T07-Q3','Silent Ridge accepted answer 413042c3-b30e-448d-b634-6f29437f2619','2026-10-28 14:21:16.017440',4,'Silent Ridge',NULL,NULL,'standard'),
(189,NULL,4,'T05-Q1','Silent Ridge accepted answer cbcafef8-f358-47e0-bd7b-30ebb030ad97','2026-10-28 14:21:57.392667',4,'Silent Ridge',NULL,NULL,'standard'),
(190,NULL,4,'T05-Q2','Silent Ridge accepted answer bf9fc798-a892-4965-a5ed-31c070ae6902','2026-10-28 14:22:08.848243',4,'Silent Ridge',NULL,NULL,'standard'),
(191,NULL,8,'T08-Q3','Silent Ridge accepted answer 53038c8a-c111-421a-b2d1-3769b0dc87df','2026-10-28 14:22:11.195998',4,'Silent Ridge',NULL,NULL,'standard'),
(192,NULL,4,'T05-Q3','Silent Ridge accepted answer af10dd18-ecce-48ed-a882-a7e07cefe9fe','2026-10-28 14:22:17.557862',4,'Silent Ridge',NULL,NULL,'standard'),
(193,NULL,4,'T05-Q4','Silent Ridge accepted answer e77d46eb-7c21-43a5-9fb2-54313f8b83ca','2026-10-28 14:22:28.096513',4,'Silent Ridge',NULL,NULL,'standard'),
(194,NULL,4,'T06-Q1','Silent Ridge accepted answer 0acace20-ae97-47e6-a119-d1dc40c99a82','2026-10-28 14:22:46.717088',4,'Silent Ridge',NULL,NULL,'standard'),
(195,NULL,8,'T08-Q2','Silent Ridge accepted answer 2622056b-729c-4704-9251-82ee2183faa7','2026-10-28 14:22:54.087902',4,'Silent Ridge',NULL,NULL,'standard'),
(196,NULL,3,'T03-Q3','Silent Ridge accepted answer 5e8e20d1-7e98-4b9d-80d9-602b71b3e150','2026-10-28 14:23:06.656660',4,'Silent Ridge',NULL,NULL,'standard'),
(197,NULL,8,'T08-Q1','Silent Ridge accepted answer 79896809-21f8-45fa-96f7-7109fa792baf','2026-10-28 14:23:25.224424',4,'Silent Ridge',NULL,NULL,'standard'),
(198,NULL,4,'T06-Q2','Silent Ridge accepted answer 1fbf7643-8525-45b1-9a42-c2b6d394da96','2026-10-28 14:23:40.728947',4,'Silent Ridge',NULL,NULL,'standard'),
(199,NULL,8,'T09-Q4','Silent Ridge accepted answer 64e42dc1-e017-4c27-b0f0-beca435ae1eb','2026-10-28 14:24:00.402958',4,'Silent Ridge',NULL,NULL,'standard'),
(200,NULL,4,'T06-Q3','Silent Ridge accepted answer f4f0c2a7-9c26-4bd4-b6b1-302f0240baf9','2026-10-28 14:24:05.721349',4,'Silent Ridge',NULL,NULL,'standard'),
(201,NULL,4,'T06-Q4','Silent Ridge accepted answer 4c4a8d02-1483-4e28-9584-1e1bd61e9f33','2026-10-28 14:24:17.141663',4,'Silent Ridge',NULL,NULL,'standard'),
(202,NULL,9,'T02-Q1','Silent Ridge accepted answer 0d80b8ec-ee84-43d8-9666-0fd2d90e03ad','2026-10-28 14:24:22.460395',4,'Silent Ridge',NULL,NULL,'standard'),
(203,NULL,4,'T07-Q1','Silent Ridge accepted answer 12c41106-1718-4728-bdb3-4b5e4fc79ddb','2026-10-28 14:24:47.140719',4,'Silent Ridge',NULL,NULL,'standard'),
(204,NULL,8,'T09-Q3','Silent Ridge accepted answer c007149e-d4f5-4e43-ada6-14856f9c4709','2026-10-28 14:24:50.484512',4,'Silent Ridge',NULL,NULL,'standard'),
(205,NULL,2,'T07-Q4','Silent Ridge accepted answer 07d03e9c-63cd-4120-879c-4d6cec6a8384','2026-10-28 14:24:58.982876',4,'Silent Ridge',NULL,NULL,'standard'),
(206,NULL,8,'T09-Q2','Silent Ridge accepted answer 95b88618-3049-4c76-bbfb-2d4b63705476','2026-10-28 14:25:10.494563',4,'Silent Ridge',NULL,NULL,'standard'),
(207,NULL,8,'T09-Q1','Silent Ridge accepted answer 29190aa3-4c90-4d1f-b638-ea1649b46f00','2026-10-28 14:25:29.073566',4,'Silent Ridge',NULL,NULL,'standard'),
(208,NULL,8,'T06-Q4','Silent Ridge accepted answer b3d80741-d204-49b3-a48f-4bb27d64375a','2026-10-28 14:26:22.433794',4,'Silent Ridge',NULL,NULL,'standard'),
(209,NULL,3,'T06-Q2','Silent Ridge accepted answer c4076db1-faa5-423d-a989-fa0db57b5a64','2026-10-28 14:26:53.384195',4,'Silent Ridge',NULL,NULL,'standard'),
(210,NULL,3,'T06-Q3','Silent Ridge accepted answer 42fe5c17-83ff-4363-ad77-02280169b127','2026-10-28 14:27:57.063138',4,'Silent Ridge',NULL,NULL,'standard'),
(211,NULL,4,'T07-Q3','Silent Ridge accepted answer 924125ae-e924-4d16-9f22-83e8acfc58d8','2026-10-28 14:28:31.072047',4,'Silent Ridge',NULL,NULL,'standard'),
(212,NULL,9,'T02-Q2','Silent Ridge accepted answer fabd886b-e590-48f9-b2d8-bb68e5795fdc','2026-10-28 14:29:08.159957',4,'Silent Ridge',NULL,NULL,'standard'),
(213,NULL,3,'T06-Q4','Silent Ridge accepted answer a69a43bc-d282-4ef7-9ec3-4055a111c8ba','2026-10-28 14:29:55.617276',4,'Silent Ridge',NULL,NULL,'standard'),
(214,NULL,9,'T02-Q3','Silent Ridge accepted answer 4314a644-cbbf-4592-ae47-7be00727363f','2026-10-28 14:29:57.866220',4,'Silent Ridge',NULL,NULL,'standard'),
(215,NULL,4,'T08-Q1','Silent Ridge accepted answer 1aecf7fe-9c02-475d-8348-71073aa1d871','2026-10-28 14:31:24.942991',4,'Silent Ridge',NULL,NULL,'standard'),
(216,NULL,3,'T07-Q1','Silent Ridge accepted answer b4f26208-3bf3-49f6-8f67-24211223dd52','2026-10-28 14:32:06.070556',4,'Silent Ridge',NULL,NULL,'standard'),
(217,NULL,9,'T02-Q4','Silent Ridge accepted answer f3251922-3201-4b56-9491-e18abf305175','2026-10-28 14:32:49.176528',4,'Silent Ridge',NULL,NULL,'standard'),
(218,NULL,3,'T07-Q2','Silent Ridge accepted answer cf8a94f1-f546-4c5d-987a-f43acec53fd7','2026-10-28 14:32:59.704525',4,'Silent Ridge',NULL,NULL,'standard'),
(219,NULL,8,'T06-Q3','Silent Ridge accepted answer 7554dd8a-cf82-4573-b20e-2319fb279ee1','2026-10-28 14:33:08.122948',4,'Silent Ridge',NULL,NULL,'standard'),
(220,NULL,2,'T08-Q1','Silent Ridge accepted answer 68aba61e-8050-484f-a70d-ee9a43071c82','2026-10-28 14:33:16.577818',4,'Silent Ridge',NULL,NULL,'standard'),
(221,NULL,9,'T05-Q1','Silent Ridge accepted answer 4d48e2b6-6a34-453a-84f5-73b024887f8e','2026-10-28 14:33:22.980616',4,'Silent Ridge',NULL,NULL,'standard'),
(222,NULL,8,'T06-Q2','Silent Ridge accepted answer a5066d4d-9309-404f-b68a-174840521c70','2026-10-28 14:33:41.642099',4,'Silent Ridge',NULL,NULL,'standard'),
(223,NULL,3,'T07-Q3','Silent Ridge accepted answer c8ffa0cd-f5a7-4468-92c2-b27649196246','2026-10-28 14:33:59.237695',4,'Silent Ridge',NULL,NULL,'standard'),
(224,NULL,3,'T08-Q1','Silent Ridge accepted answer 043ed295-3cbf-427f-9fbe-b46405226d62','2026-10-28 14:34:31.245355',4,'Silent Ridge',NULL,NULL,'standard'),
(225,NULL,8,'T03-Q1','Silent Ridge accepted answer 384285bd-8ee6-4e39-bccf-f482e045fc63','2026-10-28 14:34:53.017730',4,'Silent Ridge',NULL,NULL,'standard'),
(226,NULL,8,'T03-Q2','Silent Ridge accepted answer 979f5554-05eb-41d3-b16f-edd2e20fbb0d','2026-10-28 14:35:10.653988',4,'Silent Ridge',NULL,NULL,'standard'),
(227,NULL,9,'T05-Q2','Silent Ridge accepted answer f07c4a83-24be-491a-91cc-b8532b5b2c9d','2026-10-28 14:35:23.291908',4,'Silent Ridge',NULL,NULL,'standard'),
(228,NULL,8,'T03-Q3','Silent Ridge accepted answer a859c3b3-fc85-49cb-9eac-71cafb4df7f1','2026-10-28 14:35:55.332490',4,'Silent Ridge',NULL,NULL,'standard'),
(229,NULL,9,'T05-Q3','Silent Ridge accepted answer 8294d4c2-1ebf-4d58-949d-e40a13bc7e67','2026-10-28 14:36:06.845146',4,'Silent Ridge',NULL,NULL,'standard'),
(230,NULL,8,'T03-Q4','Silent Ridge accepted answer 185e4d26-cc48-402d-966e-d6e352604933','2026-10-28 14:36:16.291395',4,'Silent Ridge',NULL,NULL,'standard'),
(231,NULL,4,'T08-Q2','Silent Ridge accepted answer 7a3a6ffd-c4c7-4137-a40c-e19de618a2b2','2026-10-28 14:36:18.558702',4,'Silent Ridge',NULL,NULL,'standard'),
(232,NULL,4,'T08-Q3','Silent Ridge accepted answer 506b68ce-c795-4106-bd88-640ec1407b7b','2026-10-28 14:36:44.240197',4,'Silent Ridge',NULL,NULL,'standard'),
(233,NULL,4,'T08-Q4','Silent Ridge accepted answer bba96550-c662-4954-8cf4-1ab43410990b','2026-10-28 14:37:12.091996',4,'Silent Ridge',NULL,NULL,'standard'),
(234,NULL,8,'T04-Q1','Silent Ridge accepted answer 78940dd3-01cb-4d06-8246-eba9be3e062b','2026-10-28 14:37:24.628084',4,'Silent Ridge',NULL,NULL,'standard'),
(235,NULL,9,'T05-Q4','Silent Ridge accepted answer 9ee71118-8db7-45f1-9281-6ec084a38e3a','2026-10-28 14:37:30.004974',4,'Silent Ridge',NULL,NULL,'standard'),
(236,NULL,2,'T08-Q2','Silent Ridge accepted answer 52012c68-6f3c-45da-964c-af4a65bbc83e','2026-10-28 14:38:02.922500',4,'Silent Ridge',NULL,NULL,'standard'),
(237,NULL,8,'T04-Q2','Silent Ridge accepted answer b039ee75-a861-4344-ad41-b77c0bd2a78e','2026-10-28 14:38:07.226002',4,'Silent Ridge',NULL,NULL,'standard'),
(238,NULL,8,'T04-Q3','Silent Ridge accepted answer d56a0d87-da8a-4828-a5e7-cf48d3198ca5','2026-10-28 14:38:56.642811',4,'Silent Ridge',NULL,NULL,'standard'),
(239,NULL,2,'T08-Q3','Silent Ridge accepted answer 7e2dcc1d-178d-42ed-89de-2780294740a0','2026-10-28 14:39:03.030045',4,'Silent Ridge',NULL,NULL,'standard'),
(240,NULL,4,'T09-Q1','Silent Ridge accepted answer 2b74cd97-2998-4008-a334-dadef59c8941','2026-10-28 14:39:20.707779',4,'Silent Ridge',NULL,NULL,'standard'),
(241,NULL,2,'T08-Q4','Silent Ridge accepted answer 11d343ca-01b9-4ab8-8ea1-35278f6e8aaa','2026-10-28 14:39:26.047568',4,'Silent Ridge',NULL,NULL,'standard'),
(242,NULL,8,'T07-Q1','Silent Ridge accepted answer 2f88eb57-0de2-4cd1-b20c-30d39902ed47','2026-10-28 14:39:38.578188',4,'Silent Ridge',NULL,NULL,'standard'),
(243,NULL,4,'T09-Q2','Silent Ridge accepted answer 1ba20cbf-57ee-42f0-a01d-9ad989818c1d','2026-10-28 14:39:56.213950',4,'Silent Ridge',NULL,NULL,'standard'),
(244,NULL,3,'T08-Q2','Silent Ridge accepted answer d871e96c-0deb-4c91-b766-d8cb57df21da','2026-10-28 14:40:18.026581',4,'Silent Ridge',NULL,NULL,'standard'),
(245,NULL,4,'T09-Q3','Silent Ridge accepted answer 0ebb59b5-079e-42e7-a420-3647a0ef570b','2026-10-28 14:40:33.599662',4,'Silent Ridge',NULL,NULL,'standard'),
(246,NULL,4,'T09-Q4','Silent Ridge accepted answer 0f796b53-6607-4e49-b141-bf074265257d','2026-10-28 14:40:42.121555',4,'Silent Ridge',NULL,NULL,'standard'),
(247,NULL,3,'T08-Q3','Silent Ridge accepted answer 352dfb6f-85a8-4101-a411-f392195ee36b','2026-10-28 14:42:09.605676',4,'Silent Ridge',NULL,NULL,'standard'),
(248,NULL,3,'T08-Q4','Silent Ridge accepted answer 59c3fc7a-6b2e-4087-93d6-b463d8ff734a','2026-10-28 14:42:53.939226',4,'Silent Ridge',NULL,NULL,'standard'),
(249,NULL,2,'T09-Q1','Silent Ridge accepted answer 8f763ffb-e5fc-47bc-b818-c646c97ee544','2026-10-28 14:43:15.867758',4,'Silent Ridge',NULL,NULL,'standard'),
(250,NULL,2,'T09-Q2','Silent Ridge accepted answer a963ffd4-e500-4004-a063-c2f54b33c71a','2026-10-28 14:43:45.902798',4,'Silent Ridge',NULL,NULL,'standard'),
(251,NULL,2,'T09-Q3','Silent Ridge accepted answer 19d7c0f0-4782-46c6-b243-60504d166839','2026-10-28 14:44:48.551343',4,'Silent Ridge',NULL,NULL,'standard'),
(252,NULL,2,'T09-Q4','Silent Ridge accepted answer 2b048a27-5829-4705-bbf8-610efe2667e1','2026-10-28 14:45:01.080603',4,'Silent Ridge',NULL,NULL,'standard'),
(253,NULL,8,'T07-Q2','Silent Ridge accepted answer 54a89377-a9a0-4c87-a82a-cfd9d11cb4b8','2026-10-28 14:46:05.934960',4,'Silent Ridge',NULL,NULL,'standard'),
(254,NULL,2,'T10-Q1','Silent Ridge accepted answer bb94e87d-02a1-4db0-b87c-d9e20818f714','2026-10-28 14:47:51.992716',4,'Silent Ridge',NULL,NULL,'standard'),
(255,NULL,8,'T04-Q4','Silent Ridge accepted answer 258c5a8b-9177-444c-9db5-8eb565567e1e','2026-10-28 14:48:42.782627',4,'Silent Ridge',NULL,NULL,'standard'),
(256,NULL,2,'T10-Q2','Silent Ridge accepted answer 34419ef6-22a1-4107-8efd-15fa11c8e42a','2026-10-28 14:48:45.314562',4,'Silent Ridge',NULL,NULL,'standard'),
(257,NULL,2,'T10-Q3','Silent Ridge accepted answer 755ac40a-d079-426b-a3b2-2a8ddcb1d9d9','2026-10-28 14:49:20.630561',4,'Silent Ridge',NULL,NULL,'standard'),
(258,NULL,2,'T10-Q4','Silent Ridge accepted answer 9107ff40-5ed7-4409-b0af-3868ef7fd2f6','2026-10-28 14:50:13.391863',4,'Silent Ridge',NULL,NULL,'standard'),
(259,NULL,8,'T05-Q1','Silent Ridge accepted answer 94d6bdd2-f5c4-49d2-84ae-e54e3b4f79be','2026-10-28 14:51:56.649543',4,'Silent Ridge',NULL,NULL,'standard'),
(260,NULL,8,'T05-Q2','Silent Ridge accepted answer 94be8454-609c-41cd-ad4d-3b687543f092','2026-10-28 14:52:11.304377',4,'Silent Ridge',NULL,NULL,'standard'),
(261,NULL,8,'T07-Q3','Silent Ridge accepted answer d69ccda4-5a31-4e67-8e28-afc475d15e72','2026-10-28 14:52:14.717279',4,'Silent Ridge',NULL,NULL,'standard'),
(262,NULL,8,'T05-Q3','Silent Ridge accepted answer 229a09a0-563e-40be-9c53-a88bfd8ff3e2','2026-10-28 14:52:22.200336',4,'Silent Ridge',NULL,NULL,'standard'),
(263,NULL,8,'T05-Q4','Silent Ridge accepted answer 52d0f16b-b42b-4f47-9442-1d6afd28781c','2026-10-28 14:52:32.937785',4,'Silent Ridge',NULL,NULL,'standard'),
(264,NULL,2,'T11-Q1','Silent Ridge accepted answer 3722052b-cb47-4e02-b377-3099f606ad8a','2026-10-28 14:52:44.372118',4,'Silent Ridge',NULL,NULL,'standard'),
(265,NULL,2,'T11-Q2','Silent Ridge accepted answer 4c1f44d3-d0dc-4d37-9504-ec3888dd59dc','2026-10-28 14:53:08.074966',4,'Silent Ridge',NULL,NULL,'standard'),
(266,NULL,3,'T09-Q1','Silent Ridge accepted answer e835fe79-3c1d-4cd7-8c4c-88eff65b34da','2026-10-28 14:54:15.922669',4,'Silent Ridge',NULL,NULL,'standard'),
(267,NULL,3,'T09-Q2','Silent Ridge accepted answer e624e403-30c5-4d22-be2f-76cd8a38f823','2026-10-28 14:54:39.785755',4,'Silent Ridge',NULL,NULL,'standard'),
(268,NULL,4,'T07-Q2','Silent Ridge accepted answer 0ec40d78-f569-44b2-9f12-5f0997660dd7','2026-10-28 14:54:41.149871',4,'Silent Ridge',NULL,NULL,'standard'),
(269,NULL,3,'T09-Q3','Silent Ridge accepted answer a4ab4818-1bbb-4fd2-b06e-9dc2abc063e3','2026-10-28 14:55:16.142293',4,'Silent Ridge',NULL,NULL,'standard'),
(270,NULL,9,'T04-Q4','Silent Ridge accepted answer c6c98267-8c27-4c54-8687-92bd9739c74a','2026-10-28 14:55:29.669044',4,'Silent Ridge',NULL,NULL,'standard'),
(271,NULL,8,'T07-Q4','Silent Ridge accepted answer 1cddd3eb-2aa1-4823-8e89-c93c8d538145','2026-10-28 14:55:37.090833',4,'Silent Ridge',NULL,NULL,'standard'),
(272,NULL,3,'T09-Q4','Silent Ridge accepted answer 46784096-ab17-4160-8bcc-f8d6ea45778a','2026-10-28 14:55:44.633976',4,'Silent Ridge',NULL,NULL,'standard'),
(273,NULL,3,'T07-Q4','Silent Ridge accepted answer e60f9c36-2f82-440b-b891-4a5713ce93e4','2026-10-28 14:56:36.092542',4,'Silent Ridge',NULL,NULL,'standard'),
(274,NULL,2,'T11-Q3','Silent Ridge accepted answer 0a65c2a2-48dc-46c1-9dcb-c336d0fa2685','2026-10-28 14:57:39.749292',4,'Silent Ridge',NULL,NULL,'standard'),
(275,NULL,2,'T11-Q4','Silent Ridge accepted answer 88010160-2c7d-4e93-98bd-e21bd548ce8e','2026-10-28 14:58:27.959448',4,'Silent Ridge',NULL,NULL,'standard'),
(276,NULL,9,'T08-Q1','Silent Ridge accepted answer f7dac219-d207-49e1-9756-5f9b4e7746bf','2026-10-28 14:59:04.249100',4,'Silent Ridge',NULL,NULL,'standard'),
(277,NULL,3,'T10-Q1','Silent Ridge accepted answer 34f3e861-b391-4b76-a9af-e41251e36556','2026-10-28 14:59:51.782078',4,'Silent Ridge',NULL,NULL,'standard'),
(278,NULL,9,'T08-Q2','Silent Ridge accepted answer 392380bf-0526-4806-8d1f-efe5edf243b2','2026-10-28 15:01:35.309892',4,'Silent Ridge',NULL,NULL,'standard'),
(279,NULL,8,'T11-Q2','Silent Ridge accepted answer f10a7a01-63bc-425c-a4f1-a6271c7562a1','2026-10-28 15:02:03.173227',4,'Silent Ridge',NULL,NULL,'standard'),
(280,NULL,3,'T10-Q2','Silent Ridge accepted answer 92164b9d-79d9-4f41-95df-706a8403e29e','2026-10-28 15:02:39.383842',4,'Silent Ridge',NULL,NULL,'standard'),
(281,NULL,4,'T07-Q4','Silent Ridge accepted answer 47caf4fc-355e-40c8-b3f4-c0dcd9f987ed','2026-10-28 15:03:02.355681',1,'Silent Ridge',NULL,NULL,'standard'),
(282,NULL,3,'T10-Q3','Silent Ridge accepted answer 7310990e-3cc9-4363-b5bc-759bed34ab64','2026-10-28 15:03:19.089165',4,'Silent Ridge',NULL,NULL,'standard'),
(283,NULL,9,'T08-Q3','Silent Ridge accepted answer 450d58cb-14f8-4074-872d-06a1870dba27','2026-10-28 15:04:32.178466',4,'Silent Ridge',NULL,NULL,'standard'),
(284,NULL,4,'T10-Q1','Silent Ridge accepted answer 14a57fea-5cf2-4f20-8993-3ee364676a7e','2026-10-28 15:04:40.717345',4,'Silent Ridge',NULL,NULL,'standard'),
(285,NULL,9,'T08-Q4','Silent Ridge accepted answer 1b07c96c-2a52-4423-9559-b93862510f99','2026-10-28 15:05:38.367873',4,'Silent Ridge',NULL,NULL,'standard'),
(286,NULL,3,'T10-Q4','Silent Ridge accepted answer 551f6c3f-a88d-4515-b159-bfa6d1a23583','2026-10-28 15:07:02.767553',4,'Silent Ridge',NULL,NULL,'standard'),
(287,NULL,4,'T10-Q2','Silent Ridge accepted answer 8059b7f0-5c20-4bc9-9975-dcddc54ba344','2026-10-28 15:08:16.524265',4,'Silent Ridge',NULL,NULL,'standard'),
(288,NULL,6,'T03-Q1','Silent Ridge accepted answer 59478292-0b9c-4ff1-bae4-be52d802dbdb','2026-10-28 15:08:23.875567',4,'Silent Ridge',NULL,NULL,'standard'),
(289,NULL,4,'T10-Q3','Silent Ridge accepted answer 8b81e8e1-ef2e-4f17-b6f1-0fa1989f2864','2026-10-28 15:08:50.698789',4,'Silent Ridge',NULL,NULL,'standard'),
(290,NULL,3,'T11-Q1','Silent Ridge accepted answer da507943-216e-48ff-8fd7-43f4b3fe9e65','2026-10-28 15:09:21.636655',4,'Silent Ridge',NULL,NULL,'standard'),
(291,NULL,2,'T12-Q1','Silent Ridge accepted answer 5fa5e086-f316-4716-bc34-36480633f82f','2026-10-28 15:09:45.490047',4,'Silent Ridge',NULL,NULL,'standard'),
(292,NULL,6,'T03-Q2','Silent Ridge accepted answer 0527a969-802c-4435-af8b-276ae44004ba','2026-10-28 15:09:58.983780',4,'Silent Ridge',NULL,NULL,'standard'),
(293,NULL,4,'T10-Q4','Silent Ridge accepted answer 831cc94a-dcfc-4bf4-8fc6-f1494550d010','2026-10-28 15:10:02.367794',4,'Silent Ridge',NULL,NULL,'standard'),
(294,NULL,3,'T11-Q2','Silent Ridge accepted answer d9fda9f5-8aea-47da-8426-35fd0ed71346','2026-10-28 15:10:23.132619',4,'Silent Ridge',NULL,NULL,'standard'),
(295,NULL,8,'T11-Q3','Silent Ridge accepted answer 37d4bdd5-c061-4a2e-80c2-c7bc9b3d0fcf','2026-10-28 15:10:33.632029',4,'Silent Ridge',NULL,NULL,'standard'),
(296,NULL,6,'T03-Q4','Silent Ridge accepted answer 640a2314-fcbf-42e7-8928-9d4bac4402c9','2026-10-28 15:10:37.039071',4,'Silent Ridge',NULL,NULL,'standard'),
(297,NULL,9,'T09-Q1','Silent Ridge accepted answer bce32caa-8bda-4602-9770-68c3fa078d1b','2026-10-28 15:11:06.303737',4,'Silent Ridge',NULL,NULL,'standard'),
(298,NULL,9,'T06-Q1','Silent Ridge accepted answer 3e4454e9-2e9b-4cc7-b399-1bd43327cd39','2026-10-28 15:11:52.621833',4,'Silent Ridge',NULL,NULL,'standard'),
(299,NULL,9,'T09-Q2','Silent Ridge accepted answer 8222ea99-a0e9-44ac-8772-8af6d2346644','2026-10-28 15:12:07.152058',4,'Silent Ridge',NULL,NULL,'standard'),
(300,NULL,6,'T03-Q3','Silent Ridge accepted answer 7f0e2eaa-a50d-48eb-90c5-9919dfb818f7','2026-10-28 15:12:32.970886',4,'Silent Ridge',NULL,NULL,'standard'),
(301,NULL,9,'T09-Q3','Silent Ridge accepted answer d09f5b66-904b-494f-a30b-7b70cbcaf815','2026-10-28 15:12:55.667862',4,'Silent Ridge',NULL,NULL,'standard'),
(302,NULL,9,'T09-Q4','Silent Ridge accepted answer 4a234880-12c3-482e-9774-eb344e4e040d','2026-10-28 15:13:36.902960',4,'Silent Ridge',NULL,NULL,'standard'),
(303,NULL,8,'T12-Q1','Silent Ridge accepted answer b2c673f1-2984-448d-8554-1a75af1d09af','2026-10-28 15:14:41.935239',4,'Silent Ridge',NULL,NULL,'standard'),
(304,NULL,8,'T11-Q4','Silent Ridge accepted answer 6892c2ee-2a40-47b7-872c-facdadbd03fe','2026-10-28 15:14:56.542542',4,'Silent Ridge',NULL,NULL,'standard'),
(305,NULL,9,'T06-Q2','Silent Ridge accepted answer d3819cef-e09c-4c95-85f7-9e66f3e67984','2026-10-28 15:15:43.001400',4,'Silent Ridge',NULL,NULL,'standard'),
(306,NULL,8,'T12-Q2','Silent Ridge accepted answer f544ed63-6c8f-4d33-8e78-5f52e1a1aa84','2026-10-28 15:16:15.000954',4,'Silent Ridge',NULL,NULL,'standard'),
(307,NULL,8,'T12-Q3','Silent Ridge accepted answer 2e3a205e-35d9-4522-90e9-2b6e34765091','2026-10-28 15:16:30.644782',4,'Silent Ridge',NULL,NULL,'standard'),
(308,NULL,9,'T10-Q1','Silent Ridge accepted answer e017681b-d19b-446c-a0c9-4e4f7fed53a5','2026-10-28 15:17:00.752090',4,'Silent Ridge',NULL,NULL,'standard'),
(309,NULL,2,'T12-Q2','Silent Ridge accepted answer 6bbff631-9e0e-47b9-9f24-dfa969c49314','2026-10-28 15:17:06.158747',4,'Silent Ridge',NULL,NULL,'standard'),
(310,NULL,3,'T13-Q1','Silent Ridge accepted answer be03dfac-52dc-41ce-8bf2-4443dd99ad10','2026-10-28 15:17:06.437206',4,'Silent Ridge',NULL,NULL,'standard'),
(311,NULL,9,'T06-Q3','Silent Ridge accepted answer 53ce79a1-0774-44b4-8a16-c38efaf7fbc7','2026-10-28 15:17:26.212624',4,'Silent Ridge',NULL,NULL,'standard'),
(312,NULL,9,'T10-Q2','Silent Ridge accepted answer f0f10e29-24e7-4ffb-a3eb-16bb26c9dcbf','2026-10-28 15:17:50.944615',4,'Silent Ridge',NULL,NULL,'standard'),
(313,NULL,8,'T12-Q4','Silent Ridge accepted answer a749de45-773f-4644-8bf1-a39d90c8ef4f','2026-10-28 15:18:16.848304',4,'Silent Ridge',NULL,NULL,'standard'),
(314,NULL,2,'T12-Q3','Silent Ridge accepted answer fba27b90-e92b-461c-b8df-a3b223d3a782','2026-10-28 15:18:26.261713',4,'Silent Ridge',NULL,NULL,'standard'),
(315,NULL,9,'T10-Q3','Silent Ridge accepted answer c38b6ffa-0e9f-4628-a5f4-36f41106bb1c','2026-10-28 15:18:36.762780',4,'Silent Ridge',NULL,NULL,'standard'),
(316,NULL,8,'T13-Q1','Silent Ridge accepted answer eaed8595-6179-4a24-b5c0-a59755c49d82','2026-10-28 15:19:26.030348',4,'Silent Ridge',NULL,NULL,'standard'),
(317,NULL,9,'T10-Q4','Silent Ridge accepted answer 5836b0ab-10fb-4bf1-ae13-4f11efe3489c','2026-10-28 15:19:32.420086',4,'Silent Ridge',NULL,NULL,'standard'),
(318,NULL,3,'T12-Q1','Silent Ridge accepted answer 1c218f91-5067-43f5-9cc4-16a47b3b418f','2026-10-28 15:19:36.745968',4,'Silent Ridge',NULL,NULL,'standard'),
(319,NULL,8,'T13-Q2','Silent Ridge accepted answer f5de6f41-ba99-4c5f-bab7-d7e8476cc6d2','2026-10-28 15:19:42.089863',4,'Silent Ridge',NULL,NULL,'standard'),
(320,NULL,8,'T13-Q3','Silent Ridge accepted answer f692385f-1194-4973-b6b5-91d2b304ba30','2026-10-28 15:20:13.022968',4,'Silent Ridge',NULL,NULL,'standard'),
(321,NULL,8,'T13-Q4','Silent Ridge accepted answer 399fde4e-f00a-402a-b476-683699bf966f','2026-10-28 15:21:16.765533',4,'Silent Ridge',NULL,NULL,'standard'),
(322,NULL,6,'T04-Q2','Silent Ridge accepted answer 230d72ca-1f3f-4f04-8140-df752473e8f0','2026-10-28 15:21:40.610905',4,'Silent Ridge',NULL,NULL,'standard'),
(323,NULL,8,'T14-Q1','Silent Ridge accepted answer e9081cd6-bb7d-4612-ab70-f8d00498a712','2026-10-28 15:21:56.290298',4,'Silent Ridge',NULL,NULL,'standard'),
(324,NULL,6,'T04-Q1','Silent Ridge accepted answer ed198359-c266-4b34-a4b8-5c11b1649181','2026-10-28 15:22:11.982401',4,'Silent Ridge',NULL,NULL,'standard'),
(325,NULL,8,'T14-Q2','Silent Ridge accepted answer ac2b0923-f26f-4efb-80bf-0f209dab512c','2026-10-28 15:22:29.542446',4,'Silent Ridge',NULL,NULL,'standard'),
(326,NULL,6,'T04-Q3','Silent Ridge accepted answer 200bf9ee-0228-4acc-a483-dee7fec1a4b6','2026-10-28 15:22:44.088536',4,'Silent Ridge',NULL,NULL,'standard'),
(327,NULL,8,'T15-Q1','Silent Ridge accepted answer 1628def4-0045-439f-9cbe-a33ea26fbfe1','2026-10-28 15:23:14.157814',4,'Silent Ridge',NULL,NULL,'standard'),
(328,NULL,3,'T12-Q2','Silent Ridge accepted answer 623e57b5-0b1b-4a97-a634-02407d2e2014','2026-10-28 15:23:18.471100',4,'Silent Ridge',NULL,NULL,'standard'),
(329,NULL,9,'T06-Q4','Silent Ridge accepted answer 01d9fcaa-e477-4926-9dae-02e069015766','2026-10-28 15:23:25.916128',4,'Silent Ridge',NULL,NULL,'standard'),
(330,NULL,8,'T14-Q4','Silent Ridge accepted answer e25bf1bd-e3e8-4ea8-9165-91ad2eb7821c','2026-10-28 15:23:33.378410',4,'Silent Ridge',NULL,NULL,'standard'),
(331,NULL,3,'T12-Q3','Silent Ridge accepted answer 68769668-3172-4700-a029-271130ddb23f','2026-10-28 15:23:39.771580',4,'Silent Ridge',NULL,NULL,'standard'),
(332,NULL,8,'T15-Q2','Silent Ridge accepted answer ffb2672c-c453-4a5b-aa81-bebf8e0d033f','2026-10-28 15:23:44.097983',4,'Silent Ridge',NULL,NULL,'standard'),
(333,NULL,6,'T05-Q1','Silent Ridge accepted answer 100f0442-2171-4f7b-b4e3-a05f02d634a8','2026-10-28 15:23:54.580467',4,'Silent Ridge',NULL,NULL,'standard'),
(334,NULL,8,'T14-Q3','Silent Ridge accepted answer 4f2302b2-cb1a-4f0a-8239-cb578fd253f2','2026-10-28 15:24:09.208110',4,'Silent Ridge',NULL,NULL,'standard'),
(335,NULL,8,'T15-Q3','Silent Ridge accepted answer 24c4411f-a07f-4d17-a437-1246b3a8dea0','2026-10-28 15:24:19.764717',4,'Silent Ridge',NULL,NULL,'standard'),
(336,NULL,6,'T04-Q4','Silent Ridge accepted answer 4c0ec12b-af08-437e-b2fe-cfd8301600bf','2026-10-28 15:24:25.071159',4,'Silent Ridge',NULL,NULL,'standard'),
(337,NULL,6,'T05-Q2','Silent Ridge accepted answer fc23c510-e68f-45f8-b00a-bf4e8b1b8b59','2026-10-28 15:24:25.302060',4,'Silent Ridge',NULL,NULL,'standard'),
(338,NULL,6,'T05-Q3','Silent Ridge accepted answer e1420972-e4bf-4d9b-acd5-887c6ec9944f','2026-10-28 15:24:40.980155',4,'Silent Ridge',NULL,NULL,'standard'),
(339,NULL,3,'T12-Q4','Silent Ridge accepted answer 423142be-0270-4f7d-b971-9a1fb33c0873','2026-10-28 15:24:52.520731',4,'Silent Ridge',NULL,NULL,'standard'),
(340,NULL,6,'T05-Q4','Silent Ridge accepted answer 231babd9-d982-42db-9179-56ae6444868f','2026-10-28 15:24:57.893276',4,'Silent Ridge',NULL,NULL,'standard'),
(341,NULL,9,'T07-Q1','Silent Ridge accepted answer 0857c9cf-c077-49cb-b2b1-0eeeb8f89b30','2026-10-28 15:25:05.407274',4,'Silent Ridge',NULL,NULL,'standard'),
(342,NULL,8,'T15-Q4','Silent Ridge accepted answer 50c48b10-e422-4f1d-b071-5615b2bbf26f','2026-10-28 15:25:10.751829',4,'Silent Ridge',NULL,NULL,'standard'),
(343,NULL,9,'T07-Q2','Silent Ridge accepted answer 60ba686f-53bd-4c60-a8da-3177ac3b2a3a','2026-10-28 15:27:06.468618',4,'Silent Ridge',NULL,NULL,'standard'),
(344,NULL,6,'T08-Q1','Silent Ridge accepted answer 766da67d-28df-47a1-ae64-7b65ab1411fa','2026-10-28 15:27:44.483610',4,'Silent Ridge',NULL,NULL,'standard'),
(345,NULL,9,'T07-Q3','Silent Ridge accepted answer a1b41c90-74f5-40d9-8791-962a1c94fb65','2026-10-28 15:27:44.718575',4,'Silent Ridge',NULL,NULL,'standard'),
(346,NULL,2,'T12-Q4','Silent Ridge accepted answer 6b0914a1-8d4b-4b27-b910-f70d45686f24','2026-10-28 15:28:02.306759',4,'Silent Ridge',NULL,NULL,'standard'),
(347,NULL,6,'T08-Q4','Silent Ridge accepted answer f66c738a-56f4-4eac-8fac-20c99769167d','2026-10-28 15:29:28.452733',4,'Silent Ridge',NULL,NULL,'standard'),
(348,NULL,9,'T07-Q4','Silent Ridge accepted answer 2eb58505-8af8-415e-b2f9-06af1f1a5064','2026-10-28 15:29:59.408059',1,'Silent Ridge',NULL,NULL,'standard'),
(349,NULL,3,'T14-Q1','Silent Ridge accepted answer 439e9652-425e-4eb0-bac5-6327db913f47','2026-10-28 15:31:32.115220',4,'Silent Ridge',NULL,NULL,'standard'),
(350,NULL,8,'T11-Q1','Silent Ridge accepted answer 77c48819-fca8-4354-b582-4b6f630dd96c','2026-10-28 15:31:49.963387',4,'Silent Ridge',NULL,NULL,'standard'),
(351,NULL,2,'T13-Q1','Silent Ridge accepted answer 6f1f82e0-3eb8-40b3-9bf9-f2ec7d920bd1','2026-10-28 15:32:07.637779',4,'Silent Ridge',NULL,NULL,'standard'),
(352,NULL,6,'T08-Q3','Silent Ridge accepted answer c212d67f-bab2-4543-aaf3-300983050ac7','2026-10-28 15:32:21.250115',4,'Silent Ridge',NULL,NULL,'standard'),
(353,NULL,3,'T14-Q2','Silent Ridge accepted answer 923354e9-bc4e-4537-96cb-321765daa0a8','2026-10-28 15:32:48.159596',4,'Silent Ridge',NULL,NULL,'standard'),
(354,NULL,6,'T08-Q2','Silent Ridge accepted answer 5daec0ba-4dc2-4222-89e0-0ee285f6bc1c','2026-10-28 15:33:13.996979',4,'Silent Ridge',NULL,NULL,'standard'),
(355,NULL,2,'T13-Q2','Silent Ridge accepted answer 832e12ab-175c-4634-94eb-c17a8cf7ac50','2026-10-28 15:33:18.294814',4,'Silent Ridge',NULL,NULL,'standard'),
(356,NULL,3,'T14-Q3','Silent Ridge accepted answer 9aefdbc0-48bb-499f-a98d-39ccf6c59386','2026-10-28 15:33:42.188587',4,'Silent Ridge',NULL,NULL,'standard'),
(357,NULL,6,'T09-Q1','Silent Ridge accepted answer 9e7303a9-1788-42aa-b16d-dc54658fe320','2026-10-28 15:34:21.255796',4,'Silent Ridge',NULL,NULL,'standard'),
(358,NULL,8,'T16-Q1','Silent Ridge accepted answer 6d9c7b6e-bb9c-4367-9231-9e999793584d','2026-10-28 15:34:24.589140',4,'Silent Ridge',NULL,NULL,'standard'),
(359,NULL,3,'T14-Q4','Silent Ridge accepted answer db67cd6e-9554-44c7-9753-ea5d71a7de5a','2026-10-28 15:34:31.032939',4,'Silent Ridge',NULL,NULL,'standard'),
(360,NULL,2,'T13-Q3','Silent Ridge accepted answer 5d3018ca-c9d7-4aa6-9f78-90dcd7ee6d50','2026-10-28 15:34:31.291003',4,'Silent Ridge',NULL,NULL,'standard'),
(361,NULL,6,'T09-Q2','Silent Ridge accepted answer 280b1e9d-b6ec-44b7-987c-2e97506a2b2e','2026-10-28 15:34:40.705837',4,'Silent Ridge',NULL,NULL,'standard'),
(362,NULL,8,'T16-Q2','Silent Ridge accepted answer 08c2451f-8145-4dc8-ab4b-f40314e740f2','2026-10-28 15:34:50.154426',4,'Silent Ridge',NULL,NULL,'standard'),
(363,NULL,8,'T16-Q3','Silent Ridge accepted answer 58b2fec2-665e-4377-935d-a57bc72de092','2026-10-28 15:35:01.651966',4,'Silent Ridge',NULL,NULL,'standard'),
(364,NULL,6,'T09-Q3','Silent Ridge accepted answer 43fb9f60-148c-4538-9976-cda3d50228d9','2026-10-28 15:35:04.975333',4,'Silent Ridge',NULL,NULL,'standard'),
(365,NULL,6,'T09-Q4','Silent Ridge accepted answer 32c14523-a321-4bca-850b-6c9dc90822b4','2026-10-28 15:35:13.525155',4,'Silent Ridge',NULL,NULL,'standard'),
(366,NULL,8,'T16-Q4','Silent Ridge accepted answer ec940232-633f-4773-987d-e63992d4c1e7','2026-10-28 15:35:28.073517',4,'Silent Ridge',NULL,NULL,'standard'),
(367,NULL,2,'T13-Q4','Silent Ridge accepted answer 67f5a512-55c9-4888-a9b8-fef2e4ca2bee','2026-10-28 15:35:33.394133',4,'Silent Ridge',NULL,NULL,'standard'),
(368,NULL,3,'T15-Q1','Silent Ridge accepted answer d63cb632-6d19-4ac7-bb86-bff13c573ede','2026-10-28 15:35:44.892952',4,'Silent Ridge',NULL,NULL,'standard'),
(369,NULL,8,'T19-Q1','Silent Ridge accepted answer 60ffe0cc-58ba-4852-8687-842134dc02a5','2026-10-28 15:36:02.489263',4,'Silent Ridge',NULL,NULL,'standard'),
(370,NULL,3,'T15-Q2','Silent Ridge accepted answer 185e918a-8968-4eee-a411-809cc9b4befd','2026-10-28 15:36:34.376581',4,'Silent Ridge',NULL,NULL,'standard'),
(371,NULL,2,'T14-Q1','Silent Ridge accepted answer 82705883-1b0d-447a-9458-23bfaa724411','2026-10-28 15:37:00.186911',4,'Silent Ridge',NULL,NULL,'standard'),
(372,NULL,2,'T14-Q2','Silent Ridge accepted answer da0ba757-27e2-4f82-bc48-eccafddc0514','2026-10-28 15:37:23.941064',4,'Silent Ridge',NULL,NULL,'standard'),
(373,NULL,2,'T14-Q3','Silent Ridge accepted answer 026e726f-11ae-44b0-8661-cd800f91e8d4','2026-10-28 15:37:47.950115',4,'Silent Ridge',NULL,NULL,'standard'),
(374,NULL,6,'T13-Q3','Silent Ridge accepted answer 6d6cf1eb-b9b2-4071-83b3-6b6ccc3024a7','2026-10-28 15:37:55.436569',4,'Silent Ridge',NULL,NULL,'standard'),
(375,NULL,2,'T14-Q4','Silent Ridge accepted answer 0dedee96-37d4-4189-9319-1fec90768e79','2026-10-28 15:38:08.072881',4,'Silent Ridge',NULL,NULL,'standard'),
(376,NULL,2,'T15-Q1','Silent Ridge accepted answer 9cf778c1-b785-4006-9548-bf34b87edf2a','2026-10-28 15:38:21.723945',4,'Silent Ridge',NULL,NULL,'standard'),
(377,NULL,8,'T17-Q1','Silent Ridge accepted answer 1b7b271a-1951-4dc2-901b-0857741a7550','2026-10-28 15:38:32.175269',4,'Silent Ridge',NULL,NULL,'standard'),
(378,NULL,2,'T15-Q2','Silent Ridge accepted answer a9c39301-ce92-425e-9ee2-6500f45908b7','2026-10-28 15:38:39.587879',4,'Silent Ridge',NULL,NULL,'standard'),
(379,NULL,2,'T15-Q3','Silent Ridge accepted answer bc641139-85c9-4e47-8986-65fbd9080caa','2026-10-28 15:39:28.015275',4,'Silent Ridge',NULL,NULL,'standard'),
(380,NULL,6,'T11-Q1','Silent Ridge accepted answer da739bc7-2e18-408e-bda5-929fa6a9b4ec','2026-10-28 15:40:08.034752',4,'Silent Ridge',NULL,NULL,'standard'),
(381,NULL,8,'T17-Q2','Silent Ridge accepted answer 29b36c8c-e106-4d14-8a11-87e05f1e44e0','2026-10-28 15:40:17.502464',4,'Silent Ridge',NULL,NULL,'standard'),
(382,NULL,3,'T15-Q3','Silent Ridge accepted answer 13754b47-4718-4b94-ad1a-b1c2f715d296','2026-10-28 15:40:30.063938',4,'Silent Ridge',NULL,NULL,'standard'),
(383,NULL,6,'T11-Q2','Silent Ridge accepted answer badb8e2c-271d-48b2-a2d7-61ce50eaf28b','2026-10-28 15:40:33.478857',4,'Silent Ridge',NULL,NULL,'standard'),
(384,NULL,9,'T11-Q1','Silent Ridge accepted answer 850edbbd-8915-4398-9a59-43fe4a6eeaaf','2026-10-28 15:40:33.745127',4,'Silent Ridge',NULL,NULL,'standard'),
(385,NULL,6,'T12-Q1','Silent Ridge accepted answer c71a2399-ad2b-4cea-8e59-9df31f0deaa6','2026-10-28 15:40:40.245549',4,'Silent Ridge',NULL,NULL,'standard'),
(386,NULL,8,'T17-Q3','Silent Ridge accepted answer 4aec56b4-0f54-49ad-9f9a-4d0c79c4caf6','2026-10-28 15:40:41.548668',4,'Silent Ridge',NULL,NULL,'standard'),
(387,NULL,6,'T13-Q1','Silent Ridge accepted answer 57520938-0f08-4ce5-9657-898e6211bb9f','2026-10-28 15:41:17.788839',4,'Silent Ridge',NULL,NULL,'standard'),
(388,NULL,8,'T17-Q4','Silent Ridge accepted answer 661e5076-0c4b-4dbd-a55d-3b3ba53755cb','2026-10-28 15:41:19.189577',4,'Silent Ridge',NULL,NULL,'standard'),
(389,NULL,8,'T18-Q1','Silent Ridge accepted answer cfe77e1e-b8a9-46f4-8c2e-d01dc25e9e54','2026-10-28 15:41:31.905571',4,'Silent Ridge',NULL,NULL,'standard'),
(390,NULL,8,'T19-Q2','Silent Ridge accepted answer 9cc6ec6b-4402-4dc8-84f5-aaf886e3aaed','2026-10-28 15:41:54.672713',4,'Silent Ridge',NULL,NULL,'standard'),
(391,NULL,6,'T12-Q2','Silent Ridge accepted answer 51f29ec7-d49f-4663-950b-b960958c99d2','2026-10-28 15:42:35.839269',4,'Silent Ridge',NULL,NULL,'standard'),
(392,NULL,9,'T11-Q2','Silent Ridge accepted answer d5450d1a-5028-4800-8cdf-fedf5ee4f09e','2026-10-28 15:42:43.160655',4,'Silent Ridge',NULL,NULL,'standard'),
(393,NULL,6,'T11-Q3','Silent Ridge accepted answer b053a444-2a3e-4621-a5c8-d054aae632bd','2026-10-28 15:42:56.672384',4,'Silent Ridge',NULL,NULL,'standard'),
(394,NULL,6,'T12-Q3','Silent Ridge accepted answer 8d640c1b-656a-4362-a699-ab263910ce16','2026-10-28 15:42:59.980557',4,'Silent Ridge',NULL,NULL,'standard'),
(395,NULL,6,'T11-Q4','Silent Ridge accepted answer 5d0d3a91-cf6b-49ed-93a7-b0d075fbdf12','2026-10-28 15:43:10.433657',4,'Silent Ridge',NULL,NULL,'standard'),
(396,NULL,6,'T13-Q2','Silent Ridge accepted answer 1bc14623-283b-49a0-8f59-d1970a816a99','2026-10-28 15:43:39.350183',4,'Silent Ridge',NULL,NULL,'standard'),
(397,NULL,9,'T11-Q3','Silent Ridge accepted answer c17c73e9-cbe0-40af-8937-39f99cf962d3','2026-10-28 15:43:43.658494',4,'Silent Ridge',NULL,NULL,'standard'),
(398,NULL,3,'T15-Q4','Silent Ridge accepted answer 77485381-4a99-4c12-868a-5b2fcec82383','2026-10-28 15:43:47.965646',4,'Silent Ridge',NULL,NULL,'standard'),
(399,NULL,6,'T12-Q4','Silent Ridge accepted answer 685fe2c2-6c41-43be-abeb-cbf4d0447c39','2026-10-28 15:43:54.367463',4,'Silent Ridge',NULL,NULL,'standard'),
(400,NULL,9,'T11-Q4','Silent Ridge accepted answer 380e8970-8952-49bc-babc-4a2db6a45faf','2026-10-28 15:44:22.477179',4,'Silent Ridge',NULL,NULL,'standard'),
(401,NULL,6,'T13-Q4','Silent Ridge accepted answer 8d8e6672-d8f2-4f29-b3ae-799c86bbbbc0','2026-10-28 15:45:53.153279',4,'Silent Ridge',NULL,NULL,'standard'),
(402,NULL,8,'T19-Q3','Silent Ridge accepted answer d2349e63-5b81-472b-92ba-7a56745ecb38','2026-10-28 15:46:28.203318',4,'Silent Ridge',NULL,NULL,'standard'),
(403,NULL,6,'T14-Q4','Silent Ridge accepted answer 855a3448-8b0f-4438-bc6e-840f277128c6','2026-10-28 15:46:39.763791',4,'Silent Ridge',NULL,NULL,'standard'),
(404,NULL,6,'T14-Q1','Silent Ridge accepted answer e50290f0-203c-494f-af9a-a251c3b2d013','2026-10-28 15:46:51.277588',4,'Silent Ridge',NULL,NULL,'standard'),
(405,NULL,6,'T15-Q1','Silent Ridge accepted answer 4ed65e49-8518-4907-a12a-af59fa137acd','2026-10-28 15:47:16.076556',4,'Silent Ridge',NULL,NULL,'standard'),
(406,NULL,6,'T15-Q2','Silent Ridge accepted answer 45016769-f7b5-4643-8765-db9fd623c8c3','2026-10-28 15:47:28.576540',4,'Silent Ridge',NULL,NULL,'standard'),
(407,NULL,6,'T14-Q2','Silent Ridge accepted answer 75edd4ce-58cb-43cb-84a0-333078c97173','2026-10-28 15:47:40.089682',4,'Silent Ridge',NULL,NULL,'standard'),
(408,NULL,9,'T13-Q1','Silent Ridge accepted answer cfb6c066-1282-4019-8424-859af143a1db','2026-10-28 15:47:48.498710',4,'Silent Ridge',NULL,NULL,'standard'),
(409,NULL,6,'T15-Q3','Silent Ridge accepted answer 6ab1c39e-ff04-490b-8caa-a1ba21791146','2026-10-28 15:47:50.784344',4,'Silent Ridge',NULL,NULL,'standard'),
(410,NULL,8,'T18-Q3','Silent Ridge accepted answer d170565c-6e27-4b12-a090-61a18f52f672','2026-10-28 15:48:08.419209',4,'Silent Ridge',NULL,NULL,'standard'),
(411,NULL,8,'T18-Q2','Silent Ridge accepted answer 87e4566a-9ee4-4607-aa3b-47d8b8eb2378','2026-10-28 15:48:17.043123',4,'Silent Ridge',NULL,NULL,'standard'),
(412,NULL,6,'T14-Q3','Silent Ridge accepted answer e0304a42-2e54-4266-97f4-fa2ec5381927','2026-10-28 15:48:28.582595',4,'Silent Ridge',NULL,NULL,'standard'),
(413,NULL,8,'T18-Q4','Silent Ridge accepted answer b3e4ff17-68e0-40b5-8146-7af9f10e95eb','2026-10-28 15:48:34.947090',4,'Silent Ridge',NULL,NULL,'standard'),
(414,NULL,9,'T13-Q2','Silent Ridge accepted answer 5067e7dd-b456-4cca-966a-301af9aded57','2026-10-28 15:49:45.721388',4,'Silent Ridge',NULL,NULL,'standard'),
(415,NULL,8,'T19-Q4','Silent Ridge accepted answer edfbb7ad-5645-47db-800e-3c701285ab15','2026-10-28 15:49:52.080713',4,'Silent Ridge',NULL,NULL,'standard'),
(416,NULL,2,'T15-Q4','Silent Ridge accepted answer 0152fa7e-700b-4c6b-bbc4-b71e3385888d','2026-10-28 15:50:21.215979',1,'Silent Ridge',NULL,NULL,'standard'),
(417,NULL,6,'T15-Q4','Silent Ridge accepted answer c5a66f13-8304-4241-98d8-4c1b49af6486','2026-10-28 15:50:25.555758',4,'Silent Ridge',NULL,NULL,'standard'),
(418,NULL,8,'T20-Q1','Silent Ridge accepted answer b3773f9d-5a81-4ea0-b270-713a14ead906','2026-10-28 15:51:23.989044',4,'Silent Ridge',NULL,NULL,'standard'),
(419,NULL,6,'T16-Q1','Silent Ridge accepted answer 476ba73f-1636-4606-881d-325a63c5df57','2026-10-28 15:51:33.447430',4,'Silent Ridge',NULL,NULL,'standard'),
(420,NULL,6,'T18-Q1','Silent Ridge accepted answer 9e856ffd-4169-4c99-84cd-d35361a7ead4','2026-10-28 15:51:56.142012',4,'Silent Ridge',NULL,NULL,'standard'),
(421,NULL,9,'T12-Q1','Silent Ridge accepted answer 6236b7ed-eba9-4b22-aba9-6730285ba5b1','2026-10-28 15:52:19.828173',4,'Silent Ridge',NULL,NULL,'standard'),
(422,NULL,6,'T16-Q2','Silent Ridge accepted answer 2843e216-5065-4cf5-96fb-2b06252e3320','2026-10-28 15:52:21.093425',4,'Silent Ridge',NULL,NULL,'standard'),
(423,NULL,6,'T16-Q3','Silent Ridge accepted answer 4269e357-5e73-4191-accc-1c670d8c291a','2026-10-28 15:52:29.597960',4,'Silent Ridge',NULL,NULL,'standard'),
(424,NULL,6,'T17-Q1','Silent Ridge accepted answer 1080c2f2-0a32-491e-88f1-8e00d3de3464','2026-10-28 15:53:11.737153',4,'Silent Ridge',NULL,NULL,'standard'),
(425,NULL,2,'T16-Q1','Silent Ridge accepted answer 6bce848a-e5a8-4e4b-a933-5d319947ee53','2026-10-28 15:53:32.350120',4,'Silent Ridge',NULL,NULL,'standard'),
(426,NULL,6,'T16-Q4','Silent Ridge accepted answer 29ff7993-7137-4172-a437-233c31802a79','2026-10-28 15:54:05.231843',4,'Silent Ridge',NULL,NULL,'standard'),
(427,NULL,9,'T13-Q3','Silent Ridge accepted answer 09f1cb49-2a4a-4340-b70d-099a7babbe42','2026-10-28 15:54:38.321556',4,'Silent Ridge',NULL,NULL,'standard'),
(428,NULL,8,'T20-Q2','Silent Ridge accepted answer 44e75ffe-eb61-4af3-82ee-68adc37acda6','2026-10-28 15:55:01.030151',4,'Silent Ridge',NULL,NULL,'standard'),
(429,NULL,9,'T12-Q2','Silent Ridge accepted answer 3bf1c9bf-d0a2-4aea-8ee2-3ab4e02c46f5','2026-10-28 15:55:01.268454',4,'Silent Ridge',NULL,NULL,'standard'),
(430,NULL,9,'T12-Q3','Silent Ridge accepted answer a1d1dcb3-fe31-4db1-b18c-0ccbb0ce6c3c','2026-10-28 15:55:16.786992',4,'Silent Ridge',NULL,NULL,'standard'),
(431,NULL,9,'T13-Q4','Silent Ridge accepted answer 2762254d-3c22-4113-988b-d94d621caacd','2026-10-28 15:55:35.709328',4,'Silent Ridge',NULL,NULL,'standard'),
(432,NULL,6,'T19-Q1','Silent Ridge accepted answer 505a81f0-f0e9-490e-8687-f5775fe0a1b6','2026-10-28 15:55:37.979904',4,'Silent Ridge',NULL,NULL,'standard'),
(433,NULL,9,'T12-Q4','Silent Ridge accepted answer 6191f951-aea6-4c7e-9bd7-ec44c1c28148','2026-10-28 15:56:19.376436',4,'Silent Ridge',NULL,NULL,'standard'),
(434,NULL,6,'T18-Q2','Silent Ridge accepted answer a80e7b96-8c77-4502-b861-9789afa299fc','2026-10-28 15:56:34.913290',4,'Silent Ridge',NULL,NULL,'standard'),
(435,NULL,6,'T19-Q2','Silent Ridge accepted answer 1c90edc5-d25d-40d2-9647-ea0aeeb11b99','2026-10-28 15:57:38.517692',4,'Silent Ridge',NULL,NULL,'standard'),
(436,NULL,6,'T19-Q3','Silent Ridge accepted answer 832699af-9bf4-4812-be4f-d397e4682010','2026-10-28 15:58:20.691826',4,'Silent Ridge',NULL,NULL,'standard'),
(437,NULL,9,'T14-Q1','Silent Ridge accepted answer f6025c10-cfc0-4db6-b2f2-0483768057bf','2026-10-28 15:58:36.294165',4,'Silent Ridge',NULL,NULL,'standard'),
(438,NULL,9,'T14-Q2','Silent Ridge accepted answer ce8608f6-e819-4152-bb7c-fdbf7a312e54','2026-10-28 15:59:21.665990',4,'Silent Ridge',NULL,NULL,'standard'),
(439,NULL,6,'T19-Q4','Silent Ridge accepted answer 114c4b10-c860-45aa-84b7-8bda669e2786','2026-10-28 15:59:58.799972',4,'Silent Ridge',NULL,NULL,'standard'),
(440,NULL,9,'T14-Q3','Silent Ridge accepted answer 88b07532-a68c-4462-9db7-bdec49390333','2026-10-28 16:00:08.221264',4,'Silent Ridge',NULL,NULL,'standard'),
(441,NULL,8,'T20-Q3','Silent Ridge accepted answer 4bdcfc06-8eac-463e-b976-a6afc78faae6','2026-10-28 16:00:17.726654',4,'Silent Ridge',NULL,NULL,'standard'),
(442,NULL,9,'T14-Q4','Silent Ridge accepted answer 16c61d48-7081-4bb9-ba00-4b861bbd9d8d','2026-10-28 16:01:07.151887',4,'Silent Ridge',NULL,NULL,'standard'),
(443,NULL,8,'T20-Q4','Silent Ridge accepted answer 38f841a4-9706-40d2-8b32-38553736c09b','2026-10-28 16:02:21.964690',4,'Silent Ridge',NULL,NULL,'standard'),
(444,NULL,9,'T15-Q1','Silent Ridge accepted answer 23fefcd9-e9aa-4cba-a7db-8a8ff40653a8','2026-10-28 16:02:36.690727',4,'Silent Ridge',NULL,NULL,'standard'),
(445,NULL,9,'T15-Q2','Silent Ridge accepted answer 07ba5cb9-e942-420a-b390-69347812eb92','2026-10-28 16:03:08.700305',4,'Silent Ridge',NULL,NULL,'standard'),
(446,NULL,4,'T11-Q1','Silent Ridge accepted answer a9f3fefe-7a6b-43af-b101-d0d02b726e76','2026-10-28 16:03:13.047175',4,'Silent Ridge',NULL,NULL,'standard'),
(447,NULL,9,'T15-Q3','Silent Ridge accepted answer 299468eb-ac50-49c3-9d6a-02573ee03d73','2026-10-28 16:03:27.576388',4,'Silent Ridge',NULL,NULL,'standard'),
(448,NULL,9,'T15-Q4','Silent Ridge accepted answer ae6fe7a0-55b0-43e6-b41b-129e75a453f9','2026-10-28 16:03:55.364747',4,'Silent Ridge',NULL,NULL,'standard'),
(449,NULL,6,'T18-Q3','Silent Ridge accepted answer 96be91ff-b47f-4384-90ea-f61c3a14432f','2026-10-28 16:04:33.509526',4,'Silent Ridge',NULL,NULL,'standard'),
(450,NULL,4,'T11-Q2','Silent Ridge accepted answer 8ca7da75-1c49-458e-b717-069fb538deb5','2026-10-28 16:05:27.345117',4,'Silent Ridge',NULL,NULL,'standard'),
(451,NULL,6,'T17-Q4','Silent Ridge accepted answer fbd7ce9e-f00d-46d6-93f6-2f8339f209cb','2026-10-28 16:05:31.923003',4,'Silent Ridge',NULL,NULL,'standard'),
(452,NULL,4,'T11-Q3','Silent Ridge accepted answer 55e37570-ae33-4a69-a997-3ecce32f7fdc','2026-10-28 16:05:42.433457',4,'Silent Ridge',NULL,NULL,'standard'),
(453,NULL,4,'T11-Q4','Silent Ridge accepted answer 890d5d16-ff51-4968-81c0-e7309fbccedb','2026-10-28 16:05:48.833364',4,'Silent Ridge',NULL,NULL,'standard'),
(454,NULL,6,'T18-Q4','Silent Ridge accepted answer 53bea327-b8e0-4dd6-88bb-9c167fb51df6','2026-10-28 16:06:04.444597',4,'Silent Ridge',NULL,NULL,'standard'),
(455,NULL,6,'T17-Q2','Silent Ridge accepted answer c6dbcde7-99e2-41ec-8852-a3009ee11f58','2026-10-28 16:07:16.307386',4,'Silent Ridge',NULL,NULL,'standard'),
(456,NULL,6,'T17-Q3','Silent Ridge accepted answer 8a704d3f-b811-437c-b29f-2d47a042db5e','2026-10-28 16:08:34.512595',4,'Silent Ridge',NULL,NULL,'standard'),
(457,NULL,6,'T20-Q4','Silent Ridge accepted answer 078a3f89-fc32-4d60-85bf-08398c07b2a9','2026-10-28 16:09:32.516577',4,'Silent Ridge',NULL,NULL,'standard'),
(458,NULL,4,'T12-Q1','Silent Ridge accepted answer 917bab39-79b0-474b-8c3c-3111891c0a1c','2026-10-28 16:09:43.005726',4,'Silent Ridge',NULL,NULL,'standard'),
(459,NULL,6,'T20-Q3','Silent Ridge accepted answer 183ec4f2-3f91-4fb3-b5b0-20adbeff714c','2026-10-28 16:10:11.996429',4,'Silent Ridge',NULL,NULL,'standard'),
(460,NULL,6,'T20-Q2','Silent Ridge accepted answer 020151eb-57e8-43ae-90f5-491c28f6d770','2026-10-28 16:10:20.413306',4,'Silent Ridge',NULL,NULL,'standard'),
(461,NULL,6,'T20-Q1','Silent Ridge accepted answer c5b38485-2003-4dec-969a-d9045561c917','2026-10-28 16:10:30.859054',4,'Silent Ridge',NULL,NULL,'standard'),
(462,NULL,4,'T12-Q2','Silent Ridge accepted answer aa1860c2-6ebc-403d-a33a-c4ecdc108f4e','2026-10-28 16:12:14.807897',4,'Silent Ridge',NULL,NULL,'standard'),
(463,NULL,4,'T12-Q3','Silent Ridge accepted answer 06adcb81-5b24-41fb-9785-35685ffe3ac4','2026-10-28 16:12:25.353970',4,'Silent Ridge',NULL,NULL,'standard'),
(464,NULL,4,'T12-Q4','Silent Ridge accepted answer 690b09e7-7202-428f-bf66-ffcb66402f4b','2026-10-28 16:12:32.716426',4,'Silent Ridge',NULL,NULL,'standard'),
(465,NULL,4,'T13-Q1','Silent Ridge accepted answer 1c069f27-e385-4643-b0ba-0af33161a404','2026-10-28 16:13:31.458684',4,'Silent Ridge',NULL,NULL,'standard'),
(466,NULL,4,'T13-Q2','Silent Ridge accepted answer 1a7fe049-fc27-4e1a-ad08-11e98206d4e8','2026-10-28 16:14:12.822531',4,'Silent Ridge',NULL,NULL,'standard'),
(467,NULL,4,'T13-Q3','Silent Ridge accepted answer 1dbcd3f2-9803-4aea-9592-a183068664eb','2026-10-28 16:14:39.710361',4,'Silent Ridge',NULL,NULL,'standard'),
(468,NULL,4,'T13-Q4','Silent Ridge accepted answer bd77be3e-7908-4bbc-82c4-30175a155e24','2026-10-28 16:15:33.459473',4,'Silent Ridge',NULL,NULL,'standard'),
(469,NULL,4,'T14-Q1','Silent Ridge accepted answer 02bd1109-1413-4744-9620-15182ebec088','2026-10-28 16:16:22.821835',4,'Silent Ridge',NULL,NULL,'standard'),
(470,NULL,4,'T14-Q2','Silent Ridge accepted answer 804ccb7e-2433-45ba-ae99-e9b8cd3cb4cb','2026-10-28 16:16:55.303529',4,'Silent Ridge',NULL,NULL,'standard'),
(471,NULL,4,'T14-Q3','Silent Ridge accepted answer 04216a5f-2383-464e-ab21-0ab69ec1cacc','2026-10-28 16:17:25.582357',4,'Silent Ridge',NULL,NULL,'standard'),
(472,NULL,4,'T14-Q4','Silent Ridge accepted answer d82cfa6e-d6e3-4ca0-9f1a-e4dbff7dd01a','2026-10-28 16:17:44.551567',4,'Silent Ridge',NULL,NULL,'standard'),
(473,NULL,4,'T15-Q1','Silent Ridge accepted answer 71792b58-4cd4-4c58-bc5c-552d961b3399','2026-10-28 16:19:00.438655',4,'Silent Ridge',NULL,NULL,'standard'),
(474,NULL,4,'T15-Q2','Silent Ridge accepted answer 025bd1ea-e853-4d79-a4a9-c21b8ec61b24','2026-10-28 16:19:07.843114',4,'Silent Ridge',NULL,NULL,'standard'),
(475,NULL,4,'T15-Q3','Silent Ridge accepted answer bebf7c73-fdf0-44d0-b592-9cb5f934e606','2026-10-28 16:19:18.416805',4,'Silent Ridge',NULL,NULL,'standard'),
(476,NULL,4,'T15-Q4','Silent Ridge accepted answer 92a12336-4bef-46c7-974e-0be50d90aa19','2026-10-28 16:21:58.476897',4,'Silent Ridge',NULL,NULL,'standard'),
(477,NULL,4,'T16-Q1','Silent Ridge accepted answer 5e782125-6a3a-4526-8910-1a922d50a30d','2026-10-28 16:22:47.217520',4,'Silent Ridge',NULL,NULL,'standard'),
(478,NULL,4,'T16-Q2','Silent Ridge accepted answer 56ad1778-1417-4a0f-baf4-cc2cc5ada36f','2026-10-28 16:22:56.748793',4,'Silent Ridge',NULL,NULL,'standard'),
(479,NULL,4,'T16-Q3','Silent Ridge accepted answer dd5b7748-78ec-4371-862c-9b38049b344c','2026-10-28 16:23:04.240027',4,'Silent Ridge',NULL,NULL,'standard'),
(480,NULL,4,'T16-Q4','Silent Ridge accepted answer 90653968-13a9-4a97-8dbe-86073a6787a3','2026-10-28 16:23:13.788806',4,'Silent Ridge',NULL,NULL,'standard'),
(481,NULL,4,'T17-Q1','Silent Ridge accepted answer 67f808d3-ac17-4f94-8021-91b980e56683','2026-10-28 16:26:16.359672',4,'Silent Ridge',NULL,NULL,'standard'),
(482,NULL,3,'T11-Q3','Silent Ridge accepted answer a3e66695-3329-412c-9703-c969dc56ef1b','2026-10-28 16:29:17.970030',4,'Silent Ridge',NULL,NULL,'standard'),
(483,NULL,3,'T11-Q4','Silent Ridge accepted answer 3ca21147-ec58-4da0-93c1-41a3e7d75398','2026-10-28 16:33:47.828664',4,'Silent Ridge',NULL,NULL,'standard'),
(484,NULL,3,'T13-Q2','Silent Ridge accepted answer 7f65e673-c230-42c4-9b9e-968af1208cd0','2026-10-28 16:35:52.564361',4,'Silent Ridge',NULL,NULL,'standard'),
(485,NULL,3,'T13-Q3','Silent Ridge accepted answer 59a89393-7a84-42f3-917e-aa9fb59b954a','2026-10-28 16:36:23.627612',4,'Silent Ridge',NULL,NULL,'standard'),
(486,NULL,3,'T13-Q4','Silent Ridge accepted answer ea80a083-43fd-4a3d-8d22-dec9090fc561','2026-10-28 16:37:52.756615',4,'Silent Ridge',NULL,NULL,'standard'),
(487,NULL,3,'T16-Q2','Silent Ridge accepted answer 5baead6d-0e98-44a5-aec8-abf5eb0b904e','2026-10-28 16:40:43.944779',4,'Silent Ridge',NULL,NULL,'standard'),
(488,NULL,9,'T17-Q1','Silent Ridge accepted answer 40936f11-4329-448b-807d-4bce2acf0642','2026-10-28 16:40:59.623988',4,'Silent Ridge',NULL,NULL,'standard'),
(489,NULL,9,'T16-Q1','Silent Ridge accepted answer d390c5a7-2ac2-488f-b235-3e31b8cf5f98','2026-10-28 16:41:06.058088',4,'Silent Ridge',NULL,NULL,'standard'),
(490,NULL,3,'T16-Q3','Silent Ridge accepted answer e4f6f9bc-3b89-461d-9665-977920c67902','2026-10-28 16:41:26.950672',4,'Silent Ridge',NULL,NULL,'standard'),
(491,NULL,9,'T16-Q2','Silent Ridge accepted answer 85127186-cc3d-48c0-a6d1-a8df3e74050b','2026-10-28 16:41:34.315384',4,'Silent Ridge',NULL,NULL,'standard'),
(492,NULL,3,'T16-Q4','Silent Ridge accepted answer 7aa298a9-6b51-4845-9850-e27b3d9e835d','2026-10-28 16:41:47.980745',4,'Silent Ridge',NULL,NULL,'standard'),
(493,NULL,9,'T17-Q2','Silent Ridge accepted answer fbfcac08-cb70-4eb5-a745-7bc9dbd9d0a3','2026-10-28 16:42:07.805752',4,'Silent Ridge',NULL,NULL,'standard'),
(494,NULL,9,'T17-Q3','Silent Ridge accepted answer af086978-6c59-4623-8fc7-b5c3f749b611','2026-10-28 16:43:30.526961',4,'Silent Ridge',NULL,NULL,'standard'),
(495,NULL,9,'T17-Q4','Silent Ridge accepted answer ff2dbac2-a092-4668-8cbf-be157f1bbd27','2026-10-28 16:44:00.716990',4,'Silent Ridge',NULL,NULL,'standard'),
(496,NULL,3,'T16-Q1','Silent Ridge accepted answer 07940d1c-e58b-4b27-9b58-3782f2100e22','2026-10-28 16:44:17.335711',4,'Silent Ridge',NULL,NULL,'standard'),
(497,NULL,9,'T18-Q1','Silent Ridge accepted answer 0fed32d1-bb83-44ef-93a3-0c8c90ba71ef','2026-10-28 16:44:51.597270',4,'Silent Ridge',NULL,NULL,'standard'),
(498,NULL,9,'T18-Q2','Silent Ridge accepted answer 01ecad4d-bd1e-4ec3-9cea-8021601b7fab','2026-10-28 16:45:39.178916',4,'Silent Ridge',NULL,NULL,'standard'),
(499,NULL,3,'T17-Q4','Silent Ridge accepted answer 1348ee6e-2569-4ca9-a5e3-4c8e2bec95f7','2026-10-28 16:46:22.900837',4,'Silent Ridge',NULL,NULL,'standard'),
(500,NULL,9,'T18-Q3','Silent Ridge accepted answer d71f598a-ed4b-49e5-a888-bc89108ae651','2026-10-28 16:46:23.247378',4,'Silent Ridge',NULL,NULL,'standard'),
(501,NULL,9,'T18-Q4','Silent Ridge accepted answer b45fb6f7-2441-416b-b85f-a4333537ae51','2026-10-28 16:47:03.708217',4,'Silent Ridge',NULL,NULL,'standard'),
(502,NULL,9,'T19-Q1','Silent Ridge accepted answer 29662c97-7eed-45b1-9a5b-5ee3eb0832ee','2026-10-28 16:49:41.158439',4,'Silent Ridge',NULL,NULL,'standard'),
(503,NULL,9,'T16-Q4','Silent Ridge accepted answer f4f8b567-39ff-4df6-8eed-e9178c614dfa','2026-10-28 16:50:50.124109',4,'Silent Ridge',NULL,NULL,'standard'),
(504,NULL,9,'T19-Q2','Silent Ridge accepted answer 168d7b9e-b837-4a41-8e72-b6bab4e6c13d','2026-10-28 16:52:53.027810',4,'Silent Ridge',NULL,NULL,'standard'),
(505,NULL,9,'T19-Q3','Silent Ridge accepted answer 2823faec-7252-46ec-ba60-d27afe4ed5be','2026-10-28 16:53:54.687654',4,'Silent Ridge',NULL,NULL,'standard'),
(506,NULL,3,'T17-Q1','Silent Ridge accepted answer b4830c02-55cd-4053-8b2a-b02967a51599','2026-10-28 16:54:11.298857',4,'Silent Ridge',NULL,NULL,'standard'),
(507,NULL,9,'T19-Q4','Silent Ridge accepted answer 8965570b-cb5a-4b27-8e75-81a4c836d29c','2026-10-28 16:54:43.366555',4,'Silent Ridge',NULL,NULL,'standard'),
(508,NULL,3,'T18-Q1','Silent Ridge accepted answer 4301fb53-a221-4cbd-9041-c920295e049e','2026-10-28 16:55:01.961934',4,'Silent Ridge',NULL,NULL,'standard'),
(509,NULL,3,'T17-Q2','Silent Ridge accepted answer b0dbdf43-9d5b-445a-9aae-a63d633a6d93','2026-10-28 16:55:17.683885',4,'Silent Ridge',NULL,NULL,'standard'),
(510,NULL,9,'T16-Q3','Silent Ridge accepted answer 1173d1cd-519e-43b6-bf34-2ebbf48e23ea','2026-10-28 16:57:44.936774',4,'Silent Ridge',NULL,NULL,'standard'),
(511,NULL,9,'T20-Q1','Silent Ridge accepted answer c105de22-5b46-4e11-a140-aba83bb0bda3','2026-10-28 17:03:20.288574',4,'Silent Ridge',NULL,NULL,'standard'),
(512,NULL,3,'T17-Q3','Silent Ridge accepted answer d94ad930-083d-4e58-bf0c-3a5b7f925d21','2026-10-28 17:04:06.000969',4,'Silent Ridge',NULL,NULL,'standard'),
(513,NULL,9,'T20-Q2','Silent Ridge accepted answer 23383453-f27e-43c5-bc31-272fff9dc7fa','2026-10-28 17:04:21.666788',4,'Silent Ridge',NULL,NULL,'standard'),
(514,NULL,9,'T20-Q3','Silent Ridge accepted answer a6fbd684-fc6e-44ea-8082-08e63b6f2597','2026-10-28 17:05:37.166775',4,'Silent Ridge',NULL,NULL,'standard'),
(515,NULL,9,'T20-Q4','Silent Ridge accepted answer 68ecedfa-f7d4-4b9f-9df0-554b7ef2cad6','2026-10-28 17:05:52.704371',4,'Silent Ridge',NULL,NULL,'standard'),
(516,NULL,3,'T18-Q2','Silent Ridge accepted answer bb9e8a3e-da80-4603-bbec-fff393ef2156','2026-10-28 17:06:11.516159',4,'Silent Ridge',NULL,NULL,'standard'),
(517,NULL,3,'T18-Q3','Silent Ridge accepted answer 58599f4a-6b23-4f29-b23c-f3a0b77136e3','2026-10-28 17:06:34.295891',4,'Silent Ridge',NULL,NULL,'standard'),
(518,NULL,3,'T18-Q4','Silent Ridge accepted answer 817c7c37-c86c-4091-998b-4fa30240af5c','2026-10-28 17:06:42.684104',4,'Silent Ridge',NULL,NULL,'standard');
/*!40000 ALTER TABLE `awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brackets`
--

DROP TABLE IF EXISTS `brackets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `brackets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brackets`
--

LOCK TABLES `brackets` WRITE;
/*!40000 ALTER TABLE `brackets` DISABLE KEYS */;
/*!40000 ALTER TABLE `brackets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge_topics`
--

DROP TABLE IF EXISTS `challenge_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenge_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `topic_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `challenge_id` (`challenge_id`),
  KEY `topic_id` (`topic_id`),
  CONSTRAINT `challenge_topics_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `challenge_topics_ibfk_2` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_topics`
--

LOCK TABLES `challenge_topics` WRITE;
/*!40000 ALTER TABLE `challenge_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `challenge_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenges`
--

DROP TABLE IF EXISTS `challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `max_attempts` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `category` varchar(80) DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  `state` varchar(80) NOT NULL,
  `requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requirements`)),
  `connection_info` text DEFAULT NULL,
  `next_id` int(11) DEFAULT NULL,
  `attribution` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `next_id` (`next_id`),
  CONSTRAINT `challenges_ibfk_1` FOREIGN KEY (`next_id`) REFERENCES `challenges` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenges`
--

LOCK TABLES `challenges` WRITE;
/*!40000 ALTER TABLE `challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(80) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `challenge_id` (`challenge_id`),
  KEY `page_id` (`page_id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_4` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES
(1,'ctf_version','3.7.7'),
(2,'ctf_theme','core-beta'),
(3,'score_visibility','private'),
(4,'account_visibility','private'),
(5,'dynamic_challenges_alembic_version','eb68f277ab61'),
(6,'user_mode','teams'),
(7,'registration_visible','1'),
(8,'setup','1'),
(9,'version_latest','https://github.com/CTFd/CTFd/releases/tag/3.8.9'),
(10,'next_update_check','1793240359');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dynamic_challenge`
--

DROP TABLE IF EXISTS `dynamic_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dynamic_challenge` (
  `id` int(11) NOT NULL,
  `initial` int(11) DEFAULT NULL,
  `minimum` int(11) DEFAULT NULL,
  `decay` int(11) DEFAULT NULL,
  `function` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dynamic_challenge_ibfk_1` FOREIGN KEY (`id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamic_challenge`
--

LOCK TABLES `dynamic_challenge` WRITE;
/*!40000 ALTER TABLE `dynamic_challenge` DISABLE KEYS */;
/*!40000 ALTER TABLE `dynamic_challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_entries`
--

DROP TABLE IF EXISTS `field_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(80) DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`value`)),
  `field_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `field_entries_ibfk_1` FOREIGN KEY (`field_id`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `field_entries_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `field_entries_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_entries`
--

LOCK TABLES `field_entries` WRITE;
/*!40000 ALTER TABLE `field_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  `field_type` varchar(80) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `required` tinyint(1) DEFAULT NULL,
  `public` tinyint(1) DEFAULT NULL,
  `editable` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(80) DEFAULT NULL,
  `location` text DEFAULT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  `sha1sum` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`),
  KEY `files_ibfk_1` (`challenge_id`),
  CONSTRAINT `files_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `files_ibfk_2` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flags`
--

DROP TABLE IF EXISTS `flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `flags_ibfk_1` (`challenge_id`),
  CONSTRAINT `flags_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flags`
--

LOCK TABLES `flags` WRITE;
/*!40000 ALTER TABLE `flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hints`
--

DROP TABLE IF EXISTS `hints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(80) DEFAULT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requirements`)),
  `title` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hints_ibfk_1` (`challenge_id`),
  CONSTRAINT `hints_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hints`
--

LOCK TABLES `hints` WRITE;
/*!40000 ALTER TABLE `hints` DISABLE KEYS */;
/*!40000 ALTER TABLE `hints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(80) DEFAULT NULL,
  `route` varchar(128) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `draft` tinyint(1) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `auth_required` tinyint(1) DEFAULT NULL,
  `format` varchar(80) DEFAULT NULL,
  `link_target` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `route` (`route`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `silent_ridge_credits`
--

DROP TABLE IF EXISTS `silent_ridge_credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `silent_ridge_credits` (
  `key` varchar(200) NOT NULL,
  `award_id` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `award_id` (`award_id`),
  CONSTRAINT `silent_ridge_credits_ibfk_1` FOREIGN KEY (`award_id`) REFERENCES `awards` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `silent_ridge_credits`
--

LOCK TABLES `silent_ridge_credits` WRITE;
/*!40000 ALTER TABLE `silent_ridge_credits` DISABLE KEYS */;
INSERT INTO `silent_ridge_credits` VALUES
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T06-Q1',1),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T06-Q2',2),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T06-Q3',3),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T06-Q4',4),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T10-Q1',5),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T10-Q2',6),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T10-Q3',7),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T10-Q4',8),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T08-Q1',9),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T08-Q2',10),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T08-Q3',11),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T01-Q1',12),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T08-Q4',13),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T04-Q1',14),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T04-Q2',15),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T04-Q3',16),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T04-Q4',17),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T01-Q1',18),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T01-Q2',19),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T01-Q3',20),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T01-Q4',21),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T02-Q1',22),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T02-Q2',23),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T02-Q3',24),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T02-Q4',25),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T03-Q1',26),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T03-Q2',27),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T03-Q3',28),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T03-Q4',29),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T07-Q1',30),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T01-Q1',31),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T07-Q2',32),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T07-Q3',33),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T07-Q4',34),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T05-Q1',35),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T05-Q2',36),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T05-Q3',37),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T05-Q4',38),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T09-Q1',39),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T09-Q2',40),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T01-Q1',41),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T09-Q3',42),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T09-Q4',43),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T01-Q2',44),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T11-Q1',45),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T11-Q2',46),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T11-Q3',47),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T11-Q4',48),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T12-Q1',49),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T12-Q2',50),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T12-Q3',51),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T12-Q4',52),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T13-Q1',53),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T13-Q2',54),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T01-Q2',55),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T13-Q3',56),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T13-Q4',57),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T14-Q1',58),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T14-Q2',59),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T01-Q3',60),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T14-Q3',61),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T14-Q4',62),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T15-Q1',63),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T15-Q2',64),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T15-Q3',65),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T15-Q4',66),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T16-Q1',67),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T16-Q2',68),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T16-Q3',69),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T16-Q4',70),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T17-Q1',71),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T17-Q2',72),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T17-Q3',73),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T17-Q4',74),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T18-Q1',75),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T18-Q2',76),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T18-Q3',77),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T18-Q4',78),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T19-Q1',79),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T19-Q2',80),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T19-Q3',81),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T19-Q4',82),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T01-Q3',83),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T01-Q3',84),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T01-Q4',85),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T20-Q1',86),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T20-Q2',87),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T20-Q3',88),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-05:T20-Q4',89),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T01-Q4',90),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T01-Q2',91),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T02-Q1',92),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T02-Q2',93),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T02-Q1',94),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T02-Q2',95),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T01-Q4',96),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T02-Q1',97),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T02-Q2',98),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T02-Q3',99),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T02-Q3',100),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T02-Q4',101),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T03-Q1',102),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T03-Q2',103),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T02-Q4',104),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T03-Q3',105),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T02-Q3',106),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T03-Q4',107),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T02-Q4',108),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T01-Q1',109),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T01-Q2',110),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T02-Q1',111),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T02-Q2',112),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T03-Q1',113),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T03-Q2',114),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T01-Q1',115),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T01-Q2',116),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T02-Q3',117),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T01-Q3',118),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T06-Q1',119),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T01-Q4',120),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T06-Q2',121),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T06-Q3',122),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T04-Q1',123),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T01-Q3',124),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T01-Q4',125),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T02-Q1',126),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T06-Q4',127),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T02-Q4',128),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T02-Q2',129),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T03-Q4',130),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T02-Q3',131),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T02-Q4',132),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T04-Q2',133),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T04-Q3',134),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T10-Q3',135),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T04-Q4',136),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T04-Q1',137),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T03-Q1',138),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T04-Q2',139),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T03-Q2',140),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T03-Q1',141),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T03-Q2',142),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T10-Q1',143),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T04-Q3',144),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T05-Q1',145),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T03-Q3',146),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T05-Q2',147),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T03-Q4',148),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T05-Q3',149),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T05-Q4',150),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T03-Q4',151),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T10-Q2',152),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T01-Q1',153),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T03-Q3',154),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T04-Q4',155),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T07-Q1',156),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T06-Q1',157),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T07-Q2',158),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T01-Q2',159),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T04-Q1',160),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T05-Q1',161),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T05-Q2',162),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T07-Q3',163),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T05-Q3',164),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T05-Q4',165),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T06-Q2',166),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T01-Q3',167),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T06-Q3',168),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T10-Q4',169),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T06-Q4',170),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T06-Q1',171),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T04-Q2',172),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T07-Q4',173),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T06-Q1',174),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T04-Q1',175),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T10-Q4',176),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T04-Q2',177),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T04-Q3',178),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T01-Q4',179),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T07-Q1',180),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T10-Q1',181),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T10-Q3',182),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T04-Q3',183),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T10-Q2',184),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T04-Q4',185),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T07-Q2',186),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T08-Q4',187),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T07-Q3',188),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T05-Q1',189),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T05-Q2',190),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T08-Q3',191),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T05-Q3',192),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T05-Q4',193),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T06-Q1',194),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T08-Q2',195),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T03-Q3',196),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T08-Q1',197),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T06-Q2',198),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T09-Q4',199),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T06-Q3',200),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T06-Q4',201),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T02-Q1',202),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T07-Q1',203),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T09-Q3',204),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T07-Q4',205),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T09-Q2',206),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T09-Q1',207),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T06-Q4',208),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T06-Q2',209),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T06-Q3',210),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T07-Q3',211),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T02-Q2',212),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T06-Q4',213),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T02-Q3',214),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T08-Q1',215),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T07-Q1',216),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T02-Q4',217),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T07-Q2',218),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T06-Q3',219),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T08-Q1',220),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T05-Q1',221),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T06-Q2',222),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T07-Q3',223),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T08-Q1',224),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T03-Q1',225),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T03-Q2',226),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T05-Q2',227),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T03-Q3',228),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T05-Q3',229),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T03-Q4',230),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T08-Q2',231),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T08-Q3',232),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T08-Q4',233),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T04-Q1',234),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T05-Q4',235),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T08-Q2',236),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T04-Q2',237),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T04-Q3',238),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T08-Q3',239),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T09-Q1',240),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T08-Q4',241),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T07-Q1',242),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T09-Q2',243),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T08-Q2',244),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T09-Q3',245),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T09-Q4',246),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T08-Q3',247),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T08-Q4',248),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T09-Q1',249),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T09-Q2',250),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T09-Q3',251),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T09-Q4',252),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T07-Q2',253),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T10-Q1',254),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T04-Q4',255),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T10-Q2',256),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T10-Q3',257),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T10-Q4',258),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T05-Q1',259),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T05-Q2',260),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T07-Q3',261),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T05-Q3',262),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T05-Q4',263),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T11-Q1',264),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T11-Q2',265),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T09-Q1',266),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T09-Q2',267),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T07-Q2',268),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T09-Q3',269),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T04-Q4',270),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T07-Q4',271),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T09-Q4',272),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T07-Q4',273),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T11-Q3',274),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T11-Q4',275),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T08-Q1',276),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T10-Q1',277),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T08-Q2',278),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T11-Q2',279),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T10-Q2',280),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T07-Q4',281),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T10-Q3',282),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T08-Q3',283),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T10-Q1',284),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T08-Q4',285),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T10-Q4',286),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T10-Q2',287),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T03-Q1',288),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T10-Q3',289),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T11-Q1',290),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T12-Q1',291),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T03-Q2',292),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T10-Q4',293),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T11-Q2',294),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T11-Q3',295),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T03-Q4',296),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T09-Q1',297),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T06-Q1',298),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T09-Q2',299),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T03-Q3',300),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T09-Q3',301),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T09-Q4',302),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T12-Q1',303),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T11-Q4',304),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T06-Q2',305),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T12-Q2',306),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T12-Q3',307),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T10-Q1',308),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T12-Q2',309),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T13-Q1',310),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T06-Q3',311),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T10-Q2',312),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T12-Q4',313),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T12-Q3',314),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T10-Q3',315),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T13-Q1',316),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T10-Q4',317),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T12-Q1',318),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T13-Q2',319),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T13-Q3',320),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T13-Q4',321),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T04-Q2',322),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T14-Q1',323),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T04-Q1',324),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T14-Q2',325),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T04-Q3',326),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T15-Q1',327),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T12-Q2',328),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T06-Q4',329),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T14-Q4',330),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T12-Q3',331),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T15-Q2',332),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T05-Q1',333),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T14-Q3',334),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T15-Q3',335),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T04-Q4',336),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T05-Q2',337),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T05-Q3',338),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T12-Q4',339),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T05-Q4',340),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T07-Q1',341),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T15-Q4',342),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T07-Q2',343),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T08-Q1',344),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T07-Q3',345),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T12-Q4',346),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T08-Q4',347),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T07-Q4',348),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T14-Q1',349),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T11-Q1',350),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T13-Q1',351),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T08-Q3',352),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T14-Q2',353),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T08-Q2',354),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T13-Q2',355),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T14-Q3',356),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T09-Q1',357),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T16-Q1',358),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T14-Q4',359),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T13-Q3',360),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T09-Q2',361),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T16-Q2',362),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T16-Q3',363),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T09-Q3',364),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T09-Q4',365),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T16-Q4',366),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T13-Q4',367),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T15-Q1',368),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T19-Q1',369),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T15-Q2',370),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T14-Q1',371),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T14-Q2',372),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T14-Q3',373),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T13-Q3',374),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T14-Q4',375),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T15-Q1',376),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T17-Q1',377),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T15-Q2',378),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T15-Q3',379),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T11-Q1',380),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T17-Q2',381),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T15-Q3',382),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T11-Q2',383),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T11-Q1',384),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T12-Q1',385),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T17-Q3',386),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T13-Q1',387),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T17-Q4',388),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T18-Q1',389),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T19-Q2',390),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T12-Q2',391),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T11-Q2',392),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T11-Q3',393),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T12-Q3',394),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T11-Q4',395),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T13-Q2',396),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T11-Q3',397),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T15-Q4',398),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T12-Q4',399),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T11-Q4',400),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T13-Q4',401),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T19-Q3',402),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T14-Q4',403),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T14-Q1',404),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T15-Q1',405),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T15-Q2',406),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T14-Q2',407),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T13-Q1',408),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T15-Q3',409),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T18-Q3',410),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T18-Q2',411),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T14-Q3',412),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T18-Q4',413),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T13-Q2',414),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T19-Q4',415),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T15-Q4',416),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T15-Q4',417),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T20-Q1',418),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T16-Q1',419),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T18-Q1',420),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T12-Q1',421),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T16-Q2',422),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T16-Q3',423),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T17-Q1',424),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-02:T16-Q1',425),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T16-Q4',426),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T13-Q3',427),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T20-Q2',428),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T12-Q2',429),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T12-Q3',430),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T13-Q4',431),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T19-Q1',432),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T12-Q4',433),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T18-Q2',434),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T19-Q2',435),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T19-Q3',436),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T14-Q1',437),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T14-Q2',438),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T19-Q4',439),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T14-Q3',440),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T20-Q3',441),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T14-Q4',442),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-08:T20-Q4',443),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T15-Q1',444),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T15-Q2',445),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T11-Q1',446),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T15-Q3',447),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T15-Q4',448),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T18-Q3',449),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T11-Q2',450),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T17-Q4',451),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T11-Q3',452),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T11-Q4',453),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T18-Q4',454),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T17-Q2',455),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T17-Q3',456),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T20-Q4',457),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T12-Q1',458),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T20-Q3',459),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T20-Q2',460),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-06:T20-Q1',461),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T12-Q2',462),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T12-Q3',463),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T12-Q4',464),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T13-Q1',465),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T13-Q2',466),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T13-Q3',467),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T13-Q4',468),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T14-Q1',469),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T14-Q2',470),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T14-Q3',471),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T14-Q4',472),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T15-Q1',473),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T15-Q2',474),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T15-Q3',475),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T15-Q4',476),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T16-Q1',477),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T16-Q2',478),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T16-Q3',479),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T16-Q4',480),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-04:T17-Q1',481),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T11-Q3',482),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T11-Q4',483),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T13-Q2',484),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T13-Q3',485),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T13-Q4',486),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T16-Q2',487),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T17-Q1',488),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T16-Q1',489),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T16-Q3',490),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T16-Q2',491),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T16-Q4',492),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T17-Q2',493),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T17-Q3',494),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T17-Q4',495),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T16-Q1',496),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T18-Q1',497),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T18-Q2',498),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T17-Q4',499),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T18-Q3',500),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T18-Q4',501),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T19-Q1',502),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T16-Q4',503),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T19-Q2',504),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T19-Q3',505),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T17-Q1',506),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T19-Q4',507),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T18-Q1',508),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T17-Q2',509),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T16-Q3',510),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T20-Q1',511),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T17-Q3',512),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T20-Q2',513),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T20-Q3',514),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-09:T20-Q4',515),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T18-Q2',516),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T18-Q3',517),
('75a9d067-2529-4e19-92bb-46507fed4fb9:point:team-03:T18-Q4',518);
/*!40000 ALTER TABLE `silent_ridge_credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solves`
--

DROP TABLE IF EXISTS `solves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `solves` (
  `id` int(11) NOT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `challenge_id` (`challenge_id`,`team_id`),
  UNIQUE KEY `challenge_id_2` (`challenge_id`,`user_id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `solves_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `solves_ibfk_2` FOREIGN KEY (`id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `solves_ibfk_3` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `solves_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solves`
--

LOCK TABLES `solves` WRITE;
/*!40000 ALTER TABLE `solves` DISABLE KEYS */;
/*!40000 ALTER TABLE `solves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `ip` varchar(46) DEFAULT NULL,
  `provided` text DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `challenge_id` (`challenge_id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `submissions_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `submissions_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `submissions_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `value` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tags_ibfk_1` (`challenge_id`),
  CONSTRAINT `tags_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oauth_id` int(11) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `secret` varchar(128) DEFAULT NULL,
  `website` varchar(128) DEFAULT NULL,
  `affiliation` varchar(128) DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `captain_id` int(11) DEFAULT NULL,
  `bracket_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id` (`id`,`oauth_id`),
  UNIQUE KEY `oauth_id` (`oauth_id`),
  KEY `team_captain_id` (`captain_id`),
  KEY `bracket_id` (`bracket_id`),
  CONSTRAINT `team_captain_id` FOREIGN KEY (`captain_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`bracket_id`) REFERENCES `brackets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES
(1,NULL,'FLUFFY',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$V6.Xc.egSGXUXk2JvhnUJ.$oz/k8WUFErFUsRG/ZkUherswUfeTc6y',NULL,NULL,NULL,NULL,0,0,'2026-10-28 11:14:26.013480',NULL,NULL),
(2,NULL,'Enterprise-1',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$6O5WmHOgsqTXdBazwIqa8e$uesxZR4WDmsqbeERx5D2QaQGnQr5Q9e',NULL,NULL,NULL,NULL,0,0,'2026-10-28 12:03:36.867288',NULL,NULL),
(3,NULL,'MFKiLLG',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$CoYt7aY1xr.3iURQGzEg7e$9702cMhd9FmeFAMrWhvV5unQ6CDcGHu',NULL,NULL,NULL,NULL,0,0,'2026-10-28 12:03:54.876812',NULL,NULL),
(4,NULL,'CHUDS',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$WwGFPHu/lt9Nk2uA1ECRdO$WMqFh0kLvlevL6k1tu5PKiKFn7qLgzC',NULL,NULL,NULL,NULL,0,0,'2026-10-28 12:04:10.867701',NULL,NULL),
(5,NULL,'n0_L0g2_N0_Crim3','test@test.com','$bcrypt-sha256$v=2,t=2b,r=12$dyk7QHaS0qlpX5W5LdLJ.e$gdqAAeolij5MwGUTbapUaOJlf4VjS3S',NULL,NULL,NULL,NULL,1,0,'2026-10-28 12:04:38.373608',NULL,NULL),
(6,NULL,'westpoint graduates',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$jeOVQ4QTd02ZCV9cyKcU6e$WribwwL5i7j0.NjzgY0SLSHEmYGUOW6',NULL,NULL,NULL,NULL,0,0,'2026-10-28 12:04:56.324176',NULL,NULL),
(7,NULL,'Goopy Gremlins',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$1PM78yaMzECc3EdTjpLmsu$ClMQVI.TEDd5H7zteVzEM1hpD6NkTHG',NULL,NULL,NULL,NULL,0,0,'2026-10-28 12:11:59.264806',NULL,NULL),
(8,NULL,'BOO',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$sSY4P3i/cu5jy2Szcq1t1.$ER/8iqqjDVm2ojk6lhR1z2gglvhDd/u',NULL,NULL,NULL,NULL,0,0,'2026-10-28 13:01:34.571532',NULL,NULL),
(9,NULL,'thingthing1',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$OpVj749B1/Cz6FrL60MH4u$gisJIPvvI78LME5byv/N/wy1LRQofe2',NULL,NULL,NULL,NULL,0,0,'2026-10-28 13:02:35.402077',NULL,NULL);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `expiration` datetime(6) DEFAULT NULL,
  `value` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value` (`value`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tracking`
--

DROP TABLE IF EXISTS `tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) DEFAULT NULL,
  `ip` varchar(46) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tracking_ibfk_1` (`user_id`),
  CONSTRAINT `tracking_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracking`
--

LOCK TABLES `tracking` WRITE;
/*!40000 ALTER TABLE `tracking` DISABLE KEYS */;
INSERT INTO `tracking` VALUES
(1,NULL,'172.27.0.1',2,'2026-10-28 14:20:29.616661'),
(2,NULL,'172.27.0.1',7,'2026-10-28 15:53:32.220918'),
(3,NULL,'172.27.0.1',17,'2026-10-28 16:26:42.890757'),
(4,NULL,'172.27.0.1',28,'2026-10-28 16:10:54.299752'),
(5,NULL,'172.27.0.1',12,'2026-10-28 16:29:17.200020'),
(6,NULL,'172.27.0.1',15,'2026-10-28 17:06:42.189472'),
(7,NULL,'172.27.0.1',14,'2026-10-28 15:08:39.963946'),
(8,NULL,'172.27.0.1',13,'2026-10-28 17:04:05.622439'),
(9,NULL,'172.27.0.1',29,'2026-10-28 17:15:30.720924'),
(10,NULL,'172.27.0.1',22,'2026-10-28 17:14:37.770803'),
(11,NULL,'172.27.0.1',18,'2026-10-28 16:27:34.959717'),
(12,NULL,'172.27.0.1',27,'2026-10-28 17:13:46.727885'),
(13,NULL,'172.27.0.1',16,'2026-10-28 14:10:29.762129'),
(14,NULL,'172.27.0.1',23,'2026-10-28 13:03:58.360517'),
(15,NULL,'172.27.0.1',24,'2026-10-28 13:07:18.233999'),
(16,NULL,'172.27.0.1',32,'2026-10-28 17:03:54.422137'),
(17,NULL,'172.27.0.1',1,'2026-10-28 17:14:47.123098'),
(18,NULL,'172.27.0.1',30,'2026-10-28 16:02:00.163798'),
(19,NULL,'172.27.0.1',43,'2026-10-28 14:32:48.432985'),
(20,NULL,'172.27.0.1',37,'2026-10-28 16:02:21.044303'),
(21,NULL,'172.27.0.1',44,'2026-10-28 13:19:34.054439'),
(22,NULL,'172.27.0.1',46,'2026-10-28 17:05:52.041949'),
(23,NULL,'172.27.0.1',42,'2026-10-28 16:41:33.328526'),
(24,NULL,'172.27.0.1',41,'2026-10-28 15:49:51.111988');
/*!40000 ALTER TABLE `tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unlocks`
--

DROP TABLE IF EXISTS `unlocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `target` int(11) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unlocks_ibfk_1` (`team_id`),
  KEY `unlocks_ibfk_2` (`user_id`),
  CONSTRAINT `unlocks_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `unlocks_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unlocks`
--

LOCK TABLES `unlocks` WRITE;
/*!40000 ALTER TABLE `unlocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `unlocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oauth_id` int(11) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  `secret` varchar(128) DEFAULT NULL,
  `website` varchar(128) DEFAULT NULL,
  `affiliation` varchar(128) DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT NULL,
  `verified` tinyint(1) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `bracket_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id` (`id`,`oauth_id`),
  UNIQUE KEY `oauth_id` (`oauth_id`),
  KEY `team_id` (`team_id`),
  KEY `bracket_id` (`bracket_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`bracket_id`) REFERENCES `brackets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,'admin','$bcrypt-sha256$v=2,t=2b,r=12$fSycoFHjlPq2R.pu3QSWKO$u4iVjmfJQdzHestpNWK7cOOsVv9zLGu','facilitator@silent-ridge.invalid','admin',NULL,NULL,NULL,NULL,0,0,0,NULL,'2026-10-27 21:39:56.513346',NULL,NULL),
(2,NULL,'team-01-p01','$bcrypt-sha256$v=2,t=2b,r=12$qh93AdyAOPSJx80mkrSoU.$ZFGWKFiT0HZihJlO8Y6C0KjAxXi6/cy','team-01-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,1,'2026-10-28 11:14:26.556474',NULL,NULL),
(3,NULL,'team-01-p02','$bcrypt-sha256$v=2,t=2b,r=12$G3KAaXHNqHNxKhRNofPSmO$f71qHlqTfvL0M/IjWJqHALOUYWneyWm','team-01-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,1,'2026-10-28 11:14:27.099605',NULL,NULL),
(4,NULL,'team-01-p03','$bcrypt-sha256$v=2,t=2b,r=12$72KbuiH0D17AEJseKa9sHe$BOY2rw41WJu5T1yX1S7Ot90Eo4ejfSi','team-01-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,1,'2026-10-28 11:14:27.648873',NULL,NULL),
(5,NULL,'team-01-p04','$bcrypt-sha256$v=2,t=2b,r=12$imxNaA0Gj4/rGzI6ugZeze$MfYTSETL/uzFKhpQfJpCGGZpKpvCi2e','team-01-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,1,'2026-10-28 11:14:28.181117',NULL,NULL),
(6,NULL,'team-01-p05','$bcrypt-sha256$v=2,t=2b,r=12$BbuWRVRF.2lU99XaIZ2Ctu$8OkUY2OBeE4l9DLirKSZHMHcAdlvZxy','team-01-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,1,'2026-10-28 11:14:28.701461',NULL,NULL),
(7,NULL,'team-02-p01','$bcrypt-sha256$v=2,t=2b,r=12$3v/IlGOBiYwd06K.izHcWO$rFNJxGbL7Um8/KSp3iEcx48FVUUWXKu','team-02-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,2,'2026-10-28 12:03:37.393706',NULL,NULL),
(8,NULL,'team-02-p02','$bcrypt-sha256$v=2,t=2b,r=12$WBGfq3gcewygRjqDxI8MKO$.KPIl4Byv/rahoWgZubR/GEJRMmT1Ve','team-02-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,2,'2026-10-28 12:03:37.956189',NULL,NULL),
(9,NULL,'team-02-p03','$bcrypt-sha256$v=2,t=2b,r=12$JUTeuBgEpNUwd5cTuvO7ju$keVTckmsi/6CTkJUEwlEaMeNSSI25PW','team-02-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,2,'2026-10-28 12:03:38.504674',NULL,NULL),
(10,NULL,'team-02-p04','$bcrypt-sha256$v=2,t=2b,r=12$wQqnd7cl.H3A3OC50oXYje$YEexE3sqTWBv0706FMjtSm8LvNEk7fK','team-02-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,2,'2026-10-28 12:03:39.062349',NULL,NULL),
(11,NULL,'team-02-p05','$bcrypt-sha256$v=2,t=2b,r=12$dkKEGlGGskhGJ7iwxLzM0.$P8VNlw7DUIVTNbYrIWnyMw4XCOV/db6','team-02-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,2,'2026-10-28 12:03:39.595207',NULL,NULL),
(12,NULL,'team-03-p01','$bcrypt-sha256$v=2,t=2b,r=12$izmaicmpYhz8gjq9I.p17O$B.jEfuILDF4y4dqo8JHIRG8p5mzumQC','team-03-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,3,'2026-10-28 12:03:55.411258',NULL,NULL),
(13,NULL,'team-03-p02','$bcrypt-sha256$v=2,t=2b,r=12$tGRtynoqAu4DFU1JiWeol.$oalRF5B3f3m/yiQ./QQBK2bh0D9R2Mu','team-03-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,3,'2026-10-28 12:03:55.941889',NULL,NULL),
(14,NULL,'team-03-p03','$bcrypt-sha256$v=2,t=2b,r=12$x2QbvE.HOyxt88hhKaHMzu$/kqSFvwzmRl3l9h/vqQoLTqdo9wOD1a','team-03-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,3,'2026-10-28 12:03:56.460322',NULL,NULL),
(15,NULL,'team-03-p04','$bcrypt-sha256$v=2,t=2b,r=12$87BQBSTMiCXubNNk4mNGw.$bGp6LDwBfk1n5ymOJq5/egd/1uAwmxS','team-03-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,3,'2026-10-28 12:03:56.989860',NULL,NULL),
(16,NULL,'team-03-p05','$bcrypt-sha256$v=2,t=2b,r=12$CgdXO8H1IKjfpHUWZQixRe$VbjDM5yeokyGI49gX7Y6l9MlR9dRkyi','team-03-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,3,'2026-10-28 12:03:57.498472',NULL,NULL),
(17,NULL,'team-04-p01','$bcrypt-sha256$v=2,t=2b,r=12$WFCnN.Ly3viPjgjoO.MfqO$jv9u85hqZmjUdCBP7csnusvrjjWYBMa','team-04-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,4,'2026-10-28 12:04:11.438068',NULL,NULL),
(18,NULL,'team-04-p02','$bcrypt-sha256$v=2,t=2b,r=12$j5loVdOOBAfOYJzsgOmhDO$qZ1S36f20Vd1.D3rTa6pOnVF5848oji','team-04-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,4,'2026-10-28 12:04:11.977451',NULL,NULL),
(19,NULL,'team-04-p03','$bcrypt-sha256$v=2,t=2b,r=12$FRkt5yLIZTmS51guFJ6pvO$xD.t.fdQXRAGop84JZJAvkYfmBmdzKS','team-04-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,4,'2026-10-28 12:04:12.504281',NULL,NULL),
(20,NULL,'team-04-p04','$bcrypt-sha256$v=2,t=2b,r=12$ZDped9aF2ZWUJgM/aN1wyO$Ku4dmBCjuY.Anv4NXOEvY59vJqgMBBy','team-04-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,4,'2026-10-28 12:04:13.045139',NULL,NULL),
(21,NULL,'team-04-p05','$bcrypt-sha256$v=2,t=2b,r=12$imG.Y/fcXa8T18kzgzN8R.$p6x0n1MGrHyJWEH2E6UFtKA.zkBZ7HG','team-04-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,4,'2026-10-28 12:04:13.592430',NULL,NULL),
(22,NULL,'team-05-p01','$bcrypt-sha256$v=2,t=2b,r=12$k8oXgdrHvwvCa/NylTa5TO$oG/ZMR0vsL/AIf5s1xC5MWUcfXIgcYa','team-05-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,5,'2026-10-28 12:04:38.927435',NULL,NULL),
(23,NULL,'team-05-p02','$bcrypt-sha256$v=2,t=2b,r=12$kR02F7qmlp0zoEJ6pT6U.e$yxYjVajoO/iaRVgkiDwDSWU9fUzADve','team-05-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,5,'2026-10-28 12:04:39.456173',NULL,NULL),
(24,NULL,'team-05-p03','$bcrypt-sha256$v=2,t=2b,r=12$rDvXryCm/q/jOVPo4/jKZe$AMdIXAYWGLaZ7KMYxOGcvCrjkwEP4JK','team-05-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,5,'2026-10-28 12:04:39.977423',NULL,NULL),
(25,NULL,'team-05-p04','$bcrypt-sha256$v=2,t=2b,r=12$YK127h88JRUa9D12GiB4N.$Jit9XSiAfousKauCfWRadhqeKR8RMii','team-05-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,5,'2026-10-28 12:04:40.509682',NULL,NULL),
(26,NULL,'team-05-p05','$bcrypt-sha256$v=2,t=2b,r=12$MrWL0PowgMr.TBY4ARieoO$Qq1HS.DmJQX3t5G7ejnBpKCVKQiqcS6','team-05-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,5,'2026-10-28 12:04:41.057001',NULL,NULL),
(27,NULL,'team-06-p01','$bcrypt-sha256$v=2,t=2b,r=12$l1EKVj1iEWqle7vAJAaE1.$8bmP0W/LbXLcvtOP8n5Fb47yM53M1XK','team-06-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,6,'2026-10-28 12:04:56.873688',NULL,NULL),
(28,NULL,'team-06-p02','$bcrypt-sha256$v=2,t=2b,r=12$ziIZMmtkTJsMJFLHYOGcC.$22TNLtM6vw6GGztBy7qTQyThikV6tEq','team-06-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,6,'2026-10-28 12:04:57.395858',NULL,NULL),
(29,NULL,'team-06-p03','$bcrypt-sha256$v=2,t=2b,r=12$2003S3NnpuUQQDKWwRocU.$BGEIC49AyJHBdjwvZqRsUGmEt5WWHK2','team-06-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,6,'2026-10-28 12:04:57.937945',NULL,NULL),
(30,NULL,'team-06-p04','$bcrypt-sha256$v=2,t=2b,r=12$2f.3AvJr.OEHQnGUBXtQYe$Z/QwE5YjqDZZh/cL51zzKS6bXTB9igq','team-06-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,6,'2026-10-28 12:04:58.495836',NULL,NULL),
(31,NULL,'team-06-p05','$bcrypt-sha256$v=2,t=2b,r=12$QWxn18NPlm.rwIltCNw1h.$YP3VT7FBjdtKRbZMImpzMmuHZo4CYh2','team-06-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,6,'2026-10-28 12:04:59.035207',NULL,NULL),
(32,NULL,'team-07-p01','$bcrypt-sha256$v=2,t=2b,r=12$rRRltpugQDESHlgOgTkkme$9Qb9CJupzNRug0CKOhxqdfDoKSE84Om','team-07-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,7,'2026-10-28 12:11:59.818438',NULL,NULL),
(33,NULL,'team-07-p02','$bcrypt-sha256$v=2,t=2b,r=12$luOwp87JPN8J31.WP/Fym.$Wm7ntOKRk.ykkuIxHkNsuLKZfGkhzvC','team-07-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,7,'2026-10-28 12:12:00.351372',NULL,NULL),
(34,NULL,'team-07-p03','$bcrypt-sha256$v=2,t=2b,r=12$5BQR1dLhkuvomLcXt8j6bu$DheWbZE0jFJ1tMGzx6RsaAFA8HsxcOm','team-07-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,7,'2026-10-28 12:12:00.902639',NULL,NULL),
(35,NULL,'team-07-p04','$bcrypt-sha256$v=2,t=2b,r=12$j1QwmeZmbJ3UrYUSbBfBte$Q0UIQMbXy2rDwnzvGdf4XI17I43JIfa','team-07-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,7,'2026-10-28 12:12:01.454292',NULL,NULL),
(36,NULL,'team-07-p05','$bcrypt-sha256$v=2,t=2b,r=12$HZaWFn7UQR0GDdg6eSUXJO$oHOgGiThRqG7M/pL52/F3TTW58zr236','team-07-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,7,'2026-10-28 12:12:01.987878',NULL,NULL),
(37,NULL,'team-08-p01','$bcrypt-sha256$v=2,t=2b,r=12$LM2ixZwnzNUgGXWm72hz4e$NTui45C.M.L2mJ1zddqgjs02gx7wcNi','team-08-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,8,'2026-10-28 13:01:35.133074',NULL,NULL),
(38,NULL,'team-08-p02','$bcrypt-sha256$v=2,t=2b,r=12$sT6mcXtqX8K97a7gpNx9be$O3p//qpXivTjdA79Zx2HZ.keKrQsHq6','team-08-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,8,'2026-10-28 13:01:35.699045',NULL,NULL),
(39,NULL,'team-08-p03','$bcrypt-sha256$v=2,t=2b,r=12$hlQNXmez05PX8/JFVf2jPe$fkr/Q2tR0O3n2kpjR1.vhN63w6Cwh0m','team-08-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,8,'2026-10-28 13:01:36.267136',NULL,NULL),
(40,NULL,'team-08-p04','$bcrypt-sha256$v=2,t=2b,r=12$pwijhcnlkPV4ZHDdOZNrGu$YVpayl.enF66uWmz8xorR1trDiU9WqO','team-08-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,8,'2026-10-28 13:01:36.821473',NULL,NULL),
(41,NULL,'team-08-p05','$bcrypt-sha256$v=2,t=2b,r=12$2GQ3tkCc.SCNC0/SjqDaAe$osDHB/kDsZvIEheXZF6QHgf3PkBGdJG','team-08-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,8,'2026-10-28 13:01:37.377463',NULL,NULL),
(42,NULL,'team-09-p01','$bcrypt-sha256$v=2,t=2b,r=12$diHaNEvzy19VpzqPdD6OVO$Mo4b.mJSxzk2koBpS/Yz1DSgQXbQUTi','team-09-p01@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,9,'2026-10-28 13:02:35.965297',NULL,NULL),
(43,NULL,'team-09-p02','$bcrypt-sha256$v=2,t=2b,r=12$czhlTnONHMx/opRCv6jP/e$iRMD3bknJrKhrEmacUSFMh220bqxZn.','team-09-p02@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,9,'2026-10-28 13:02:36.519126',NULL,NULL),
(44,NULL,'team-09-p03','$bcrypt-sha256$v=2,t=2b,r=12$2xXLbLZbYhVmsnYZp4RsPu$iQRAiEnaJnxrLc0cZjFU9j6eL2t6zzu','team-09-p03@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,9,'2026-10-28 13:02:37.055380',NULL,NULL),
(45,NULL,'team-09-p04','$bcrypt-sha256$v=2,t=2b,r=12$exZRWeXdhzRXD0St685.ju$o4fpNrDpfpWSmNUJtmVqCsiLojc2NN6','team-09-p04@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,9,'2026-10-28 13:02:37.597913',NULL,NULL),
(46,NULL,'team-09-p05','$bcrypt-sha256$v=2,t=2b,r=12$zjOZWrurkAzKGnaqvpPjoe$fYbJtCGO3JkwnGTGhxNvGnhiik2q.uW','team-09-p05@silent-ridge.invalid','user',NULL,NULL,NULL,NULL,0,0,0,9,'2026-10-28 13:02:38.151506',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-28 17:34:57
