Operation Silent Ridge - event archive
Captured: 2026-10-28 13:35:16 -04:00
Event: ridge-oct26-live11-20261021

Contents:
  runtime/              private runtime (state.sqlite, registrations.sqlite, config.json, env, secrets, journal, inventories, specs)
  databases/ctfd.sql    CTFd MariaDB dump
  databases/iris.sql    IRIS PostgreSQL dump
  source-branch.txt / source-log.txt / source-status.txt / source-diffstat.txt / source-changes.patch   git state incl. uncommitted work
  test_ctfd_answer_examples.py   untracked new test
  build-receipts/       image build receipts

PRIVATE: contains participant credentials (runtime/env, runtime/secrets) and CTFd/IRIS user data. Do not commit or share.
